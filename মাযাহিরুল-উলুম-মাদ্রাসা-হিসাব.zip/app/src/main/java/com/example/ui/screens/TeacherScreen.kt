package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.entity.SalaryPayment
import com.example.data.local.entity.TeacherStaff
import com.example.ui.components.EmptyStateView
import com.example.ui.components.MetricStatCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import com.example.util.NumberFormatter
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val teachers by viewModel.filteredTeachers.collectAsState()
    val allTeachers by viewModel.allTeachers.collectAsState()
    val totalSalaryBudget by viewModel.totalMonthlySalaryBudget.collectAsState()
    val allSalaries by viewModel.allSalaryPayments.collectAsState()
    val searchQuery by viewModel.teacherSearchQuery.collectAsState()
    val selectedDesig by viewModel.selectedDesignation.collectAsState()
    val selectedTeacher by viewModel.selectedTeacher.collectAsState()
    val teacherSalaries by viewModel.selectedTeacherSalaryPayments.collectAsState()

    var selectedSubTab by remember { mutableStateOf(0) } // 0: শিক্ষক ও স্টাফ তালিকা, 1: মাসিক বেতন শিট
    var showAddTeacherDialog by remember { mutableStateOf(false) }
    var teacherToEdit by remember { mutableStateOf<TeacherStaff?>(null) }
    var teacherToDelete by remember { mutableStateOf<TeacherStaff?>(null) }
    var teacherToPaySalary by remember { mutableStateOf<TeacherStaff?>(null) }

    val designations = listOf(
        "সকল পদবী",
        "মুহতামিম",
        "নায়েবে মুহতামিম",
        "শায়খুল হাদিস",
        "হিফজ শিক্ষক",
        "কিতাব শিক্ষক",
        "নূরানী শিক্ষক",
        "খাদেম",
        "হিসাবরক্ষক",
        "বাবুর্চি"
    )

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            if (selectedSubTab == 0) {
                FloatingActionButton(
                    onClick = {
                        teacherToEdit = null
                        showAddTeacherDialog = true
                    },
                    containerColor = Emerald800,
                    contentColor = Color.White
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.PersonAdd, contentDescription = "যুক্ত করুন")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("শিক্ষক যুক্ত করুন", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Sub Tab Selector
            TabRow(
                selectedTabIndex = selectedSubTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = Emerald800
            ) {
                Tab(
                    selected = selectedSubTab == 0,
                    onClick = { selectedSubTab = 0 },
                    text = { Text("শিক্ষক ও স্টাফ তালিকা (${allTeachers.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                    icon = { Icon(Icons.Default.People, contentDescription = null, modifier = Modifier.size(18.dp)) }
                )
                Tab(
                    selected = selectedSubTab == 1,
                    onClick = { selectedSubTab = 1 },
                    text = { Text("মাসিক বেতন শিট", fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                    icon = { Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(18.dp)) }
                )
            }

            if (selectedSubTab == 0) {
                // --- TAB 1: TEACHER LIST ---
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Summary Cards
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            MetricStatCard(
                                title = "মোট শিক্ষক/স্টাফ",
                                value = "${NumberFormatter.toBanglaDigits(allTeachers.size)} জন",
                                subtitle = "সক্রিয়: ${NumberFormatter.toBanglaDigits(allTeachers.count { it.status == "সক্রিয়" })} জন",
                                icon = Icons.Default.People,
                                containerColor = Emerald50,
                                contentColor = Emerald800,
                                modifier = Modifier.weight(1f)
                            )
                            MetricStatCard(
                                title = "মাসিক বেতন বাজেট",
                                value = NumberFormatter.formatCurrency(totalSalaryBudget),
                                subtitle = "সক্রিয়দের নির্ধারিত বেতন",
                                icon = Icons.Default.AccountBalanceWallet,
                                containerColor = Gold50,
                                contentColor = Gold700,
                                modifier = Modifier.weight(1.2f)
                            )
                        }
                    }

                    // Search and Designation Filter
                    item {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { viewModel.setTeacherSearchQuery(it) },
                            placeholder = { Text("নাম, আইডি বা ফোন নম্বর দিয়ে খুঁজুন...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Emerald800) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { viewModel.setTeacherSearchQuery("") }) {
                                        Icon(Icons.Default.Clear, contentDescription = "মুছুন")
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Emerald800,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                            )
                        )
                    }

                    // Designation Chips
                    item {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            items(designations) { desig ->
                                val isSelected = if (desig == "সকল পদবী") selectedDesig.isEmpty() else selectedDesig == desig
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        viewModel.setTeacherDesignation(if (desig == "সকল পদবী") "" else desig)
                                    },
                                    label = { Text(desig, fontSize = 12.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Emerald800,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }
                    }

                    // Teacher List Items
                    if (teachers.isEmpty()) {
                        item {
                            EmptyStateView(
                                title = "কোনো শিক্ষক বা স্টাফ পাওয়া যায়নি",
                                subtitle = "নতুন শিক্ষক যুক্ত করতে নিচে 'শিক্ষক যুক্ত করুন' বাটনে চাপুন",
                                icon = Icons.Default.PersonSearch
                            )
                        }
                    } else {
                        items(teachers) { teacher ->
                            TeacherItemCard(
                                teacher = teacher,
                                onClick = { viewModel.selectTeacher(teacher) },
                                onEdit = {
                                    teacherToEdit = teacher
                                    showAddTeacherDialog = true
                                },
                                onDelete = { teacherToDelete = teacher },
                                onPaySalary = { teacherToPaySalary = teacher }
                            )
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(60.dp))
                    }
                }
            } else {
                // --- TAB 2: MONTHLY SALARY SHEET ---
                SalarySheetSection(
                    viewModel = viewModel,
                    allTeachers = allTeachers,
                    onPaySalaryForTeacher = { teacher -> teacherToPaySalary = teacher }
                )
            }
        }
    }

    // Add / Edit Teacher Dialog
    if (showAddTeacherDialog) {
        TeacherFormDialog(
            teacherToEdit = teacherToEdit,
            onDismiss = {
                showAddTeacherDialog = false
                teacherToEdit = null
            },
            onSave = { id, name, empId, phone, address, jDate, desig, salary, status, notes ->
                viewModel.saveTeacher(id, name, empId, phone, address, jDate, desig, salary, status, notes)
                showAddTeacherDialog = false
                teacherToEdit = null
            }
        )
    }

    // Pay Salary Dialog
    if (teacherToPaySalary != null) {
        PaySalaryDialog(
            teacher = teacherToPaySalary!!,
            onDismiss = { teacherToPaySalary = null },
            onPay = { teacher, month, salary, bonus, deduction, paid, pDate, pMethod, notes ->
                viewModel.paySalary(teacher, month, salary, bonus, deduction, paid, pDate, pMethod, notes)
                teacherToPaySalary = null
            }
        )
    }

    // Delete Teacher Confirmation Dialog
    if (teacherToDelete != null) {
        AlertDialog(
            onDismissRequest = { teacherToDelete = null },
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("শিক্ষক/স্টাফ মুছে ফেলতে চান?") },
            text = { Text("${teacherToDelete!!.name} (${teacherToDelete!!.designation})-এর তথ্য ও পূর্ববর্তী বেতন ডাটা মুছে যাবে।") },
            confirmButton = {
                Button(
                    onClick = {
                        teacherToDelete?.let { viewModel.deleteTeacher(it) }
                        teacherToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("হ্যাঁ, মুছুন")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { teacherToDelete = null }) {
                    Text("বাতিল")
                }
            }
        )
    }

    // Teacher Details Sheet
    if (selectedTeacher != null) {
        TeacherDetailSheet(
            teacher = selectedTeacher!!,
            salaryPayments = teacherSalaries,
            onDismiss = { viewModel.selectTeacher(null) },
            onEdit = {
                teacherToEdit = selectedTeacher
                showAddTeacherDialog = true
                viewModel.selectTeacher(null)
            },
            onPaySalary = {
                teacherToPaySalary = selectedTeacher
                viewModel.selectTeacher(null)
            }
        )
    }
}

@Composable
fun TeacherItemCard(
    teacher: TeacherStaff,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onPaySalary: () -> Unit
) {
    val context = LocalContext.current
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Emerald100),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = teacher.name.take(1),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Emerald900
                        )
                    }

                    Column {
                        Text(
                            text = teacher.name,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Emerald50
                            ) {
                                Text(
                                    text = teacher.designation,
                                    fontSize = 11.sp,
                                    color = Emerald800,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Text(
                                text = "• ${teacher.employeeId}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (teacher.status == "সক্রিয়") Emerald100 else Color(0xFFFFEBEE)
                ) {
                    Text(
                        text = teacher.status,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (teacher.status == "সক্রিয়") Emerald900 else Color(0xFFC62828),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("মাসিক বেতন", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = NumberFormatter.formatCurrency(teacher.salary),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald800
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (teacher.phone.isNotEmpty()) {
                        IconButton(
                            onClick = {
                                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${teacher.phone}"))
                                context.startActivity(intent)
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.Phone, contentDescription = "ফোন", tint = Emerald800, modifier = Modifier.size(18.dp))
                        }
                    }

                    Button(
                        onClick = onPaySalary,
                        colors = ButtonDefaults.buttonColors(containerColor = Emerald800),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("বেতন দিন", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    IconButton(onClick = onEdit, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "সম্পাদনা", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                    }

                    IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "মুছুন", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun SalarySheetSection(
    viewModel: MainViewModel,
    allTeachers: List<TeacherStaff>,
    onPaySalaryForTeacher: (TeacherStaff) -> Unit
) {
    val selectedMonth by viewModel.selectedSalaryMonth.collectAsState()
    val monthlyPayments by viewModel.monthlySalaryPayments.collectAsState()

    val totalPaid = monthlyPayments.sumOf { it.paidAmount }
    val totalDue = monthlyPayments.sumOf { it.dueAmount }

    val months = listOf(
        "জানুয়ারি ২০২৬", "ফেব্রুয়ারি ২০২৬", "মার্চ ২০২৬", "এপ্রিল ২০২৬",
        "মে ২০২৬", "জুন ২০২৬", "জুলাই ২০২৬", "আগস্ট ২০২৬",
        "সেপ্টেম্বর ২০২৬", "অক্টোবর ২০২৬", "নভেম্বর ২০২৬", "ডিসেম্বর ২০২৬"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Month Selector
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Emerald50)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "মাস নির্বাচন করুন",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald800
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(months) { m ->
                            val isSel = m == selectedMonth
                            FilterChip(
                                selected = isSel,
                                onClick = { viewModel.setSalaryMonth(m) },
                                label = { Text(m, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Emerald800,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }
            }
        }

        // Summary for Selected Month
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricStatCard(
                    title = "$selectedMonth পরিশোধ",
                    value = NumberFormatter.formatCurrency(totalPaid),
                    subtitle = "ভাউচার: ${NumberFormatter.toBanglaDigits(monthlyPayments.size)} টি",
                    icon = Icons.Default.CheckCircle,
                    containerColor = Emerald100,
                    contentColor = Emerald900,
                    modifier = Modifier.weight(1f)
                )
                MetricStatCard(
                    title = "বকেয়া বেতন",
                    value = NumberFormatter.formatCurrency(totalDue),
                    subtitle = "অবশিষ্ট প্রদেয়",
                    icon = Icons.Default.Pending,
                    containerColor = if (totalDue > 0) Color(0xFFFFEBEE) else Emerald50,
                    contentColor = if (totalDue > 0) Color(0xFFC62828) else Emerald800,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Teacher List with Pay Status for this Month
        item {
            Text(
                text = "শিক্ষক ও স্টাফ বেতন স্থিতি ($selectedMonth)",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Emerald800
            )
        }

        if (allTeachers.isEmpty()) {
            item {
                EmptyStateView(
                    title = "কোনো শিক্ষক তালিকাভুক্ত নেই",
                    subtitle = "প্রথমে শিক্ষক যুক্ত করুন",
                    icon = Icons.Default.PersonOff
                )
            }
        } else {
            items(allTeachers) { teacher ->
                val payment = monthlyPayments.firstOrNull { it.teacherStaffId == teacher.id }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = teacher.name,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${teacher.designation} • ধার্য বেতন: ${NumberFormatter.formatCurrency(teacher.salary)}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(4.dp))
                            if (payment != null) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (payment.dueAmount <= 0) Emerald100 else Gold100
                                    ) {
                                        Text(
                                            text = if (payment.dueAmount <= 0) "পরিশোধিত: ${NumberFormatter.formatCurrency(payment.paidAmount)}" else "আংশিক: ${NumberFormatter.formatCurrency(payment.paidAmount)} (বকেয়া: ${NumberFormatter.formatCurrency(payment.dueAmount)})",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (payment.dueAmount <= 0) Emerald900 else Gold900,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            } else {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = Color(0xFFFFEBEE)
                                ) {
                                    Text(
                                        text = "বেতন প্রদান করা হয়নি",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFC62828),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        Button(
                            onClick = { onPaySalaryForTeacher(teacher) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (payment != null) Gold700 else Emerald800
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Text(
                                text = if (payment != null) "আপডেট/পুনঃপ্রদান" else "বেতন দিন",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PaySalaryDialog(
    teacher: TeacherStaff,
    onDismiss: () -> Unit,
    onPay: (
        teacher: TeacherStaff,
        monthYear: String,
        salaryAmount: Double,
        bonus: Double,
        deduction: Double,
        paidAmount: Double,
        paymentDate: String,
        paymentMethod: String,
        notes: String
    ) -> Unit
) {
    val months = listOf(
        "সেপ্টেম্বর ২০২৬", "অক্টোবর ২০২৬", "নভেম্বর ২০২৬", "ডিসেম্বর ২০২৬",
        "জানুয়ারি ২০২৬", "ফেব্রুয়ারি ২০২৬", "মার্চ ২০২৬", "এপ্রিল ২০২৬",
        "মে ২০২৬", "জুন ২০২৬", "জুলাই ২০২৬", "আগস্ট ২০২৬"
    )

    var selectedMonth by remember { mutableStateOf(months[0]) }
    var baseSalaryStr by remember { mutableStateOf(teacher.salary.toInt().toString()) }
    var bonusStr by remember { mutableStateOf("0") }
    var deductionStr by remember { mutableStateOf("0") }
    var paidAmountStr by remember { mutableStateOf(teacher.salary.toInt().toString()) }
    var paymentMethod by remember { mutableStateOf("নগদ") }
    var notes by remember { mutableStateOf("") }
    val paymentDate = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }

    val baseSalary = baseSalaryStr.toDoubleOrNull() ?: 0.0
    val bonus = bonusStr.toDoubleOrNull() ?: 0.0
    val deduction = deductionStr.toDoubleOrNull() ?: 0.0
    val netPayable = (baseSalary + bonus - deduction).coerceAtLeast(0.0)
    val paidAmount = paidAmountStr.toDoubleOrNull() ?: 0.0
    val dueAmount = (netPayable - paidAmount).coerceAtLeast(0.0)

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text(
                        text = "বেতন প্রদান ভাউচার",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald800
                    )
                    Text(
                        text = "শিক্ষক: ${teacher.name} (${teacher.designation})",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Divider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(vertical = 6.dp))
                }

                item {
                    Text("বেতনের মাস নির্বাচন", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(months.take(6)) { m ->
                            FilterChip(
                                selected = selectedMonth == m,
                                onClick = { selectedMonth = m },
                                label = { Text(m, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = baseSalaryStr,
                            onValueChange = {
                                baseSalaryStr = it
                                paidAmountStr = it
                            },
                            label = { Text("মূল বেতন (৳)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )

                        OutlinedTextField(
                            value = bonusStr,
                            onValueChange = { bonusStr = it },
                            label = { Text("বোনাস (৳)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = deductionStr,
                            onValueChange = { deductionStr = it },
                            label = { Text("কর্তন / অনুপস্থিতি (৳)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )

                        OutlinedTextField(
                            value = paidAmountStr,
                            onValueChange = { paidAmountStr = it },
                            label = { Text("প্রদত্ত টাকা (৳) *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }

                // Net summary box
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Emerald50)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("সর্বমোট প্রদেয়:", fontSize = 12.sp, color = Emerald900)
                                Text(NumberFormatter.formatCurrency(netPayable), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Emerald900)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("অবশিষ্ট বকেয়া:", fontSize = 12.sp, color = if (dueAmount > 0) Color(0xFFC62828) else Emerald800)
                                Text(NumberFormatter.formatCurrency(dueAmount), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (dueAmount > 0) Color(0xFFC62828) else Emerald800)
                            }
                        }
                    }
                }

                item {
                    Text("পরিশোধের মাধ্যম", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("নগদ", "ব্যাংক", "বিকাশ").forEach { method ->
                            FilterChip(
                                selected = paymentMethod == method,
                                onClick = { paymentMethod = method },
                                label = { Text(method) }
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("মন্তব্য / নোট (ঐচ্ছিক)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("বাতিল")
                        }

                        Button(
                            onClick = {
                                onPay(teacher, selectedMonth, baseSalary, bonus, deduction, paidAmount, paymentDate, paymentMethod, notes)
                            },
                            modifier = Modifier.weight(1.3f),
                            colors = ButtonDefaults.buttonColors(containerColor = Emerald800),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("বেতন সম্পন্ন করুন")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TeacherFormDialog(
    teacherToEdit: TeacherStaff?,
    onDismiss: () -> Unit,
    onSave: (
        id: Long,
        name: String,
        employeeId: String,
        phone: String,
        address: String,
        joiningDate: String,
        designation: String,
        salary: Double,
        status: String,
        notes: String
    ) -> Unit
) {
    var name by remember { mutableStateOf(teacherToEdit?.name ?: "") }
    var employeeId by remember { mutableStateOf(teacherToEdit?.employeeId ?: "") }
    var phone by remember { mutableStateOf(teacherToEdit?.phone ?: "") }
    var address by remember { mutableStateOf(teacherToEdit?.address ?: "") }
    var joiningDate by remember {
        mutableStateOf(teacherToEdit?.joiningDate ?: SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()))
    }
    var designation by remember { mutableStateOf(teacherToEdit?.designation ?: "হিফজ শিক্ষক") }
    var salaryStr by remember { mutableStateOf(if (teacherToEdit != null) teacherToEdit.salary.toInt().toString() else "15000") }
    var status by remember { mutableStateOf(teacherToEdit?.status ?: "সক্রিয়") }
    var notes by remember { mutableStateOf(teacherToEdit?.notes ?: "") }

    val designations = listOf(
        "মুহতামিম", "নায়েবে মুহতামিম", "শায়খুল হাদিস", "হিফজ শিক্ষক",
        "কিতাব শিক্ষক", "নূরানী শিক্ষক", "খাদেম", "হিসাবরক্ষক", "বাবুর্চি"
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text(
                        text = if (teacherToEdit == null) "নতুন শিক্ষক/স্টাফ যুক্ত করুন" else "শিক্ষকের তথ্য পরিবর্তন",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald800
                    )
                    Divider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(vertical = 4.dp))
                }

                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("শিক্ষক/স্টাফের পূর্ণ নাম *") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = employeeId,
                            onValueChange = { employeeId = it },
                            label = { Text("আইডি (ঐচ্ছিক)") },
                            placeholder = { Text("যেমন: EMP-001") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = salaryStr,
                            onValueChange = { salaryStr = it },
                            label = { Text("নির্ধারিত বেতন (৳) *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1.2f),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )
                    }
                }

                item {
                    Text("পদবী নির্বাচন করুন", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(designations) { d ->
                            FilterChip(
                                selected = designation == d,
                                onClick = { designation = d },
                                label = { Text(d, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = it },
                            label = { Text("মোবাইল নম্বর") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = joiningDate,
                            onValueChange = { joiningDate = it },
                            label = { Text("যোগদানের তারিখ") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text("ঠিকানা") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )
                }

                item {
                    Text("অবস্থা (Status)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("সক্রিয়", "নিষ্ক্রিয়").forEach { st ->
                            FilterChip(
                                selected = status == st,
                                onClick = { status = st },
                                label = { Text(st) }
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("বিশেষ নোট / মন্তব্য") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("বাতিল")
                        }

                        Button(
                            onClick = {
                                val sal = salaryStr.toDoubleOrNull() ?: 0.0
                                onSave(
                                    teacherToEdit?.id ?: 0L,
                                    name,
                                    employeeId,
                                    phone,
                                    address,
                                    joiningDate,
                                    designation,
                                    sal,
                                    status,
                                    notes
                                )
                            },
                            modifier = Modifier.weight(1.3f),
                            colors = ButtonDefaults.buttonColors(containerColor = Emerald800),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(if (teacherToEdit == null) "যুক্ত করুন" else "আপডেট করুন")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherDetailSheet(
    teacher: TeacherStaff,
    salaryPayments: List<SalaryPayment>,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onPaySalary: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = teacher.name,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald800
                    )
                    Text(
                        text = "${teacher.designation} • আইডি: ${teacher.employeeId}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Default.Edit, contentDescription = "সম্পাদনা", tint = Emerald800)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Info Grid
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    DetailRow("মোবাইল নম্বর", teacher.phone.ifEmpty { "দেওয়া হয়নি" })
                    DetailRow("ঠিকানা", teacher.address.ifEmpty { "দেওয়া হয়নি" })
                    DetailRow("যোগদানের তারিখ", NumberFormatter.toBanglaDigits(teacher.joiningDate))
                    DetailRow("নির্ধারিত মাসিক বেতন", NumberFormatter.formatCurrency(teacher.salary))
                    DetailRow("অবস্থা", teacher.status)
                    if (teacher.notes.isNotEmpty()) {
                        DetailRow("নোট", teacher.notes)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Salary History Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "বেতন গ্রহণের পূর্বের ইতিহাস (${salaryPayments.size})",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Emerald800
                )
                Button(
                    onClick = onPaySalary,
                    colors = ButtonDefaults.buttonColors(containerColor = Emerald800),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Text("বেতন প্রদান", fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (salaryPayments.isEmpty()) {
                Text(
                    text = "কোনো বেতন লেনদেন ইতিহাস পাওয়া যায়নি",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 240.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(salaryPayments) { payment ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = Emerald50)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(payment.monthYear, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Emerald900)
                                    Text("ভাউচার: ${payment.voucherNo} • তারিখ: ${NumberFormatter.toBanglaDigits(payment.paymentDate)}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(NumberFormatter.formatCurrency(payment.paidAmount), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Emerald800)
                                    if (payment.dueAmount > 0) {
                                        Text("বকেয়া: ${NumberFormatter.formatCurrency(payment.dueAmount)}", fontSize = 10.sp, color = Color(0xFFC62828))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
    }
}
