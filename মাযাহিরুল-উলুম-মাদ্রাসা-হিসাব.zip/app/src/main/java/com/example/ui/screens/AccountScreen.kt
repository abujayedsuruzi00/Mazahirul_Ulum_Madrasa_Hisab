package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.entity.Loan
import com.example.data.local.entity.Transaction
import com.example.ui.components.EmptyStateView
import com.example.ui.components.MetricStatCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import com.example.util.NumberFormatter
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val summary by viewModel.dashboardSummary.collectAsState()
    val transactions by viewModel.filteredTransactions.collectAsState()
    val allTransactions by viewModel.allTransactions.collectAsState()
    val loans by viewModel.allLoans.collectAsState()
    val searchQuery by viewModel.txSearchQuery.collectAsState()
    val typeFilter by viewModel.txTypeFilter.collectAsState()
    val categoryFilter by viewModel.txCategoryFilter.collectAsState()
    val dateFilter by viewModel.txDateFilter.collectAsState()

    var selectedMainTab by remember { mutableStateOf(0) } // 0: আয়-ব্যয় লেনদেন, 1: ঋণ/করজ খাতা
    var showTxDialog by remember { mutableStateOf(false) }
    var txTypeToCreate by remember { mutableStateOf("INCOME") }
    var txToEdit by remember { mutableStateOf<Transaction?>(null) }
    var txToDelete by remember { mutableStateOf<Transaction?>(null) }

    var showLoanDialog by remember { mutableStateOf(false) }
    var loanToRepay by remember { mutableStateOf<Loan?>(null) }
    var loanToDelete by remember { mutableStateOf<Loan?>(null) }

    val incomeCategories = listOf("অনুদান", "লিল্লাহ ফান্ড", "জাকাত", "ফিতরা", "চামড়া বিক্রয়", "ছাত্র বেতন", "ভাড়া আয়", "ঋণ/করজ", "বিবিধ আয়")
    val expenseCategories = listOf("শিক্ষক বেতন", "বোর্ডিং ও খাবার", "ইউটিলিটি বিল", "মেরামত ও নির্মাণ", "অনুষ্ঠান ও মাহফিল", "মেহমানদারী", "চিকিৎসা", "ঋণ/করজ", "বিবিধ ব্যয়")
    val allCategories = listOf("সকল খাত") + (incomeCategories + expenseCategories).distinct()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            if (selectedMainTab == 0) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FloatingActionButton(
                        onClick = {
                            txToEdit = null
                            txTypeToCreate = "INCOME"
                            showTxDialog = true
                        },
                        containerColor = Emerald800,
                        contentColor = Color.White
                    ) {
                        Row(modifier = Modifier.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AddCircle, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("আয় (+)", fontWeight = FontWeight.Bold)
                        }
                    }

                    FloatingActionButton(
                        onClick = {
                            txToEdit = null
                            txTypeToCreate = "EXPENSE"
                            showTxDialog = true
                        },
                        containerColor = Color(0xFFC62828),
                        contentColor = Color.White
                    ) {
                        Row(modifier = Modifier.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.RemoveCircle, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ব্যয় (-)", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                FloatingActionButton(
                    onClick = { showLoanDialog = true },
                    containerColor = Gold700,
                    contentColor = Color.White
                ) {
                    Row(modifier = Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("নতুন ঋণ/করজ", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Main Top Tabs
            TabRow(
                selectedTabIndex = selectedMainTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = Emerald800
            ) {
                Tab(
                    selected = selectedMainTab == 0,
                    onClick = { selectedMainTab = 0 },
                    text = { Text("আয়-ব্যয় খতিয়ান", fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                    icon = { Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, modifier = Modifier.size(18.dp)) }
                )
                Tab(
                    selected = selectedMainTab == 1,
                    onClick = { selectedMainTab = 1 },
                    text = { Text("ঋণ / করজে হাসানা (${loans.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                    icon = { Icon(Icons.Default.Handshake, contentDescription = null, modifier = Modifier.size(18.dp)) }
                )
            }

            if (selectedMainTab == 0) {
                // --- TAB 1: INCOME & EXPENSE TRANSACTIONS ---
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Summary Financial Cards
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Emerald800)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "মাদ্রাসার বর্তমান নীট তহবিল ব্যালেন্স",
                                    fontSize = 12.sp,
                                    color = Color.White.copy(alpha = 0.85f)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = NumberFormatter.formatCurrency(summary.netBalance),
                                    fontSize = 26.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.height(14.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("সর্বমোট আয়", fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f))
                                        Text(NumberFormatter.formatCurrency(summary.totalIncome), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFFA5D6A7))
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("সর্বমোট ব্যয়", fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f))
                                        Text(NumberFormatter.formatCurrency(summary.totalExpense), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFCDD2))
                                    }
                                }
                            }
                        }
                    }

                    // Quick Today Summary
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            MetricStatCard(
                                title = "আজকের মোট আয়",
                                value = NumberFormatter.formatCurrency(summary.todayIncome),
                                subtitle = "দৈনিক আদায়",
                                icon = Icons.Default.TrendingUp,
                                containerColor = Emerald50,
                                contentColor = Emerald800,
                                modifier = Modifier.weight(1f)
                            )
                            MetricStatCard(
                                title = "আজকের মোট ব্যয়",
                                value = NumberFormatter.formatCurrency(summary.todayExpense),
                                subtitle = "দৈনিক খরচ",
                                icon = Icons.Default.TrendingDown,
                                containerColor = Color(0xFFFFEBEE),
                                contentColor = Color(0xFFC62828),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Search Bar
                    item {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { viewModel.setTxSearchQuery(it) },
                            placeholder = { Text("খাত, বিবরণ, রসিদ নং বা দাতা দিয়ে খুঁজুন...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Emerald800) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { viewModel.setTxSearchQuery("") }) {
                                        Icon(Icons.Default.Clear, contentDescription = "মুছুন")
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            singleLine = true
                        )
                    }

                    // Date and Type Filter Chips
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            // Date Filters (ALL, TODAY, THIS_MONTH)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = dateFilter == "ALL",
                                    onClick = { viewModel.setTxDateFilter("ALL") },
                                    label = { Text("সকল সময়") },
                                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Emerald800, selectedLabelColor = Color.White)
                                )
                                FilterChip(
                                    selected = dateFilter == "TODAY",
                                    onClick = { viewModel.setTxDateFilter("TODAY") },
                                    label = { Text("আজ") },
                                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Emerald800, selectedLabelColor = Color.White)
                                )
                                FilterChip(
                                    selected = dateFilter == "THIS_MONTH",
                                    onClick = { viewModel.setTxDateFilter("THIS_MONTH") },
                                    label = { Text("চলতি মাস") },
                                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Emerald800, selectedLabelColor = Color.White)
                                )
                            }

                            // Type Filters (ALL, INCOME, EXPENSE)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = typeFilter.isEmpty(),
                                    onClick = { viewModel.setTxTypeFilter("") },
                                    label = { Text("সকল লেনদেন (${allTransactions.size})") }
                                )
                                FilterChip(
                                    selected = typeFilter == "INCOME",
                                    onClick = { viewModel.setTxTypeFilter(if (typeFilter == "INCOME") "" else "INCOME") },
                                    label = { Text("শুধুমাত্র আয় (+)") },
                                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Emerald100, selectedLabelColor = Emerald900)
                                )
                                FilterChip(
                                    selected = typeFilter == "EXPENSE",
                                    onClick = { viewModel.setTxTypeFilter(if (typeFilter == "EXPENSE") "" else "EXPENSE") },
                                    label = { Text("শুধুমাত্র ব্যয় (-)") },
                                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFFFFCDD2), selectedLabelColor = Color(0xFFB71C1C))
                                )
                            }

                            // Category Chips
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(allCategories) { cat ->
                                    val isSel = if (cat == "সকল খাত") categoryFilter.isEmpty() else categoryFilter == cat
                                    FilterChip(
                                        selected = isSel,
                                        onClick = { viewModel.setTxCategoryFilter(if (cat == "সকল খাত") "" else cat) },
                                        label = { Text(cat, fontSize = 11.sp) }
                                    )
                                }
                            }
                        }
                    }

                    // Transactions List Header
                    item {
                        Text(
                            text = "লেনদেন তালিকা (${NumberFormatter.toBanglaDigits(transactions.size)} টি)",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Emerald800
                        )
                    }

                    if (transactions.isEmpty()) {
                        item {
                            EmptyStateView(
                                title = "কোনো লেনদেন রেকর্ড পাওয়া যায়নি",
                                subtitle = "নিচে '+' বা '-' বোতাম ব্যবহার করে নতুন আয় বা ব্যয় যুক্ত করুন",
                                icon = Icons.Default.ReceiptLong
                            )
                        }
                    } else {
                        items(transactions) { tx ->
                            TransactionCard(
                                transaction = tx,
                                onEdit = {
                                    txToEdit = tx
                                    txTypeToCreate = tx.type
                                    showTxDialog = true
                                },
                                onDelete = { txToDelete = tx }
                            )
                        }
                    }

                    item { Spacer(modifier = Modifier.height(70.dp)) }
                }
            } else {
                // --- TAB 2: LOANS / QARD HASANA ---
                LoansSection(
                    viewModel = viewModel,
                    loans = loans,
                    onRepay = { loanToRepay = it },
                    onDelete = { loanToDelete = it }
                )
            }
        }
    }

    // Add / Edit Transaction Dialog
    if (showTxDialog) {
        TransactionFormDialog(
            type = txTypeToCreate,
            transactionToEdit = txToEdit,
            onDismiss = {
                showTxDialog = false
                txToEdit = null
            },
            onSave = { id, type, title, category, amount, date, method, voucher, payee, ref, notes ->
                viewModel.saveTransaction(id, type, title, category, amount, date, method, voucher, payee, ref, notes)
                showTxDialog = false
                txToEdit = null
            }
        )
    }

    // Delete Transaction Confirmation
    if (txToDelete != null) {
        AlertDialog(
            onDismissRequest = { txToDelete = null },
            icon = { Icon(Icons.Default.DeleteForever, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("লেনদেন মুছে ফেলতে চান?") },
            text = { Text("'${txToDelete!!.title}' (${NumberFormatter.formatCurrency(txToDelete!!.amount)})-এর হিসাবটি মুছে ফেলা হবে।") },
            confirmButton = {
                Button(
                    onClick = {
                        txToDelete?.let { viewModel.deleteTransaction(it) }
                        txToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("হ্যাঁ, মুছুন")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { txToDelete = null }) {
                    Text("বাতিল")
                }
            }
        )
    }

    // Add Loan Dialog
    if (showLoanDialog) {
        LoanFormDialog(
            onDismiss = { showLoanDialog = false },
            onSave = { type, person, phone, amount, date, purpose, notes ->
                viewModel.createLoan(type, person, phone, amount, date, purpose, notes)
                showLoanDialog = false
            }
        )
    }

    // Repay Loan Dialog
    if (loanToRepay != null) {
        LoanRepaymentDialog(
            loan = loanToRepay!!,
            onDismiss = { loanToRepay = null },
            onRepay = { loanId, amount, date, method, notes ->
                viewModel.addLoanRepayment(loanId, amount, date, method, notes)
                loanToRepay = null
            }
        )
    }

    // Delete Loan Confirmation
    if (loanToDelete != null) {
        AlertDialog(
            onDismissRequest = { loanToDelete = null },
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("ঋণের খাতা মুছবেন?") },
            text = { Text("${loanToDelete!!.personName}-এর ঋণের রেকর্ড এবং সকল কিস্তি হিসাব মুছে যাবে।") },
            confirmButton = {
                Button(
                    onClick = {
                        loanToDelete?.let { viewModel.deleteLoan(it) }
                        loanToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("মুছুন")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { loanToDelete = null }) {
                    Text("বাতিল")
                }
            }
        )
    }
}

@Composable
fun TransactionCard(
    transaction: Transaction,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val isIncome = transaction.type == "INCOME"
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(if (isIncome) Emerald100 else Color(0xFFFFEBEE)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isIncome) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                            contentDescription = null,
                            tint = if (isIncome) Emerald900 else Color(0xFFC62828),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column {
                        Text(
                            text = transaction.title,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (isIncome) Emerald50 else Color(0xFFFBE9E7)
                            ) {
                                Text(
                                    text = transaction.category,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isIncome) Emerald800 else Color(0xFFD84315),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Text(
                                text = "• ${NumberFormatter.toBanglaDigits(transaction.date)}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Text(
                    text = "${if (isIncome) "+" else "-"} ${NumberFormatter.formatCurrency(transaction.amount)}",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isIncome) Emerald800 else Color(0xFFC62828)
                )
            }

            // Additional details if present
            if (transaction.payeeOrSource.isNotEmpty() || transaction.voucherNo.isNotEmpty() || transaction.description.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        if (transaction.payeeOrSource.isNotEmpty()) {
                            Text(
                                text = "${if (isIncome) "দাতা/উৎস" else "প্রাপক"}: ${transaction.payeeOrSource}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (transaction.voucherNo.isNotEmpty()) {
                            Text(
                                text = "ভাউচার: ${transaction.voucherNo} • মাধ্যম: ${transaction.paymentMethod}",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Row {
                        IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Edit, contentDescription = "সম্পাদনা", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                        }
                        IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Delete, contentDescription = "মুছুন", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LoansSection(
    viewModel: MainViewModel,
    loans: List<Loan>,
    onRepay: (Loan) -> Unit,
    onDelete: (Loan) -> Unit
) {
    val totalTaken = loans.filter { it.loanType == "TAKEN" }.sumOf { it.remainingAmount }
    val totalGiven = loans.filter { it.loanType == "GIVEN" }.sumOf { it.remainingAmount }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricStatCard(
                    title = "মাদ্রাসার দেনা (গৃহীত ঋণ)",
                    value = NumberFormatter.formatCurrency(totalTaken),
                    subtitle = "মাদ্রাসার পরিশোধযোগ্য",
                    icon = Icons.Default.CallReceived,
                    containerColor = Color(0xFFFFEBEE),
                    contentColor = Color(0xFFC62828),
                    modifier = Modifier.weight(1f)
                )
                MetricStatCard(
                    title = "মাদ্রাসার পাওনা (প্রদত্ত ঋণ)",
                    value = NumberFormatter.formatCurrency(totalGiven),
                    subtitle = "মাদ্রাসার আদায়যোগ্য",
                    icon = Icons.Default.CallMade,
                    containerColor = Emerald50,
                    contentColor = Emerald800,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Text(
                text = "চলমান ঋণ ও করজ খাতা (${loans.size})",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Emerald800
            )
        }

        if (loans.isEmpty()) {
            item {
                EmptyStateView(
                    title = "কোনো ঋণ বা করজের হিসাব নেই",
                    subtitle = "নতুন ঋণ বা করজ এন্ট্রি করতে নিচে '+' বোতাম চাপুন",
                    icon = Icons.Default.Handshake
                )
            }
        } else {
            items(loans) { loan ->
                val isTaken = loan.loanType == "TAKEN"
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (isTaken) Color(0xFFFFEBEE) else Emerald100
                                    ) {
                                        Text(
                                            text = if (isTaken) "গৃহীত ঋণ (দেনা)" else "প্রদত্ত ঋণ (পাওনা)",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isTaken) Color(0xFFC62828) else Emerald900,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (loan.status == "পরিশোধিত") Emerald50 else Gold50
                                    ) {
                                        Text(
                                            text = loan.status,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (loan.status == "পরিশোধিত") Emerald800 else Gold800,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(loan.personName, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                if (loan.phone.isNotEmpty()) {
                                    Text("মোবাইল: ${loan.phone}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text("অবশিষ্ট", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = NumberFormatter.formatCurrency(loan.remainingAmount),
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (loan.remainingAmount > 0) Color(0xFFC62828) else Emerald800
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("মোট: ${NumberFormatter.formatCurrency(loan.totalAmount)} | পরিশোধ: ${NumberFormatter.formatCurrency(loan.paidAmount)}", fontSize = 11.sp)
                                if (loan.purpose.isNotEmpty()) {
                                    Text("উদ্দেশ্য: ${loan.purpose}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                if (loan.remainingAmount > 0) {
                                    Button(
                                        onClick = { onRepay(loan) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Emerald800),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Text(if (isTaken) "পরিশোধ" else "আদায়", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                IconButton(onClick = { onDelete(loan) }, modifier = Modifier.size(32.dp)) {
                                    Icon(Icons.Default.Delete, contentDescription = "মুছুন", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(70.dp)) }
    }
}

@Composable
fun TransactionFormDialog(
    type: String,
    transactionToEdit: Transaction?,
    onDismiss: () -> Unit,
    onSave: (
        id: Long,
        type: String,
        title: String,
        category: String,
        amount: Double,
        date: String,
        paymentMethod: String,
        voucherNo: String,
        payeeOrSource: String,
        reference: String,
        notes: String
    ) -> Unit
) {
    val isIncome = (transactionToEdit?.type ?: type) == "INCOME"
    var currentType by remember { mutableStateOf(transactionToEdit?.type ?: type) }
    var title by remember { mutableStateOf(transactionToEdit?.title ?: "") }
    var category by remember { mutableStateOf(transactionToEdit?.category ?: if (isIncome) "অনুদান" else "বোর্ডিং ও খাবার") }
    var amountStr by remember { mutableStateOf(if (transactionToEdit != null) transactionToEdit.amount.toInt().toString() else "") }
    var date by remember { mutableStateOf(transactionToEdit?.date ?: SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())) }
    var paymentMethod by remember { mutableStateOf(transactionToEdit?.paymentMethod ?: "নগদ") }
    var voucherNo by remember { mutableStateOf(transactionToEdit?.voucherNo ?: "") }
    var payeeOrSource by remember { mutableStateOf(transactionToEdit?.payeeOrSource ?: "") }
    var reference by remember { mutableStateOf(transactionToEdit?.reference ?: "") }
    var notes by remember { mutableStateOf(transactionToEdit?.notes ?: "") }

    val categories = if (currentType == "INCOME") {
        listOf("অনুদান", "লিল্লাহ ফান্ড", "জাকাত", "ফিতরা", "চামড়া বিক্রয়", "ছাত্র বেতন", "ভাড়া আয়", "ঋণ/করজ", "বিবিধ আয়")
    } else {
        listOf("শিক্ষক বেতন", "বোর্ডিং ও খাবার", "ইউটিলিটি বিল", "মেরামত ও নির্মাণ", "অনুষ্ঠান ও মাহফিল", "মেহমানদারী", "চিকিৎসা", "ঋণ/করজ", "বিবিধ ব্যয়")
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text(
                        text = if (transactionToEdit == null) {
                            if (currentType == "INCOME") "নতুন আয় এন্ট্রি (+)" else "নতুন ব্যয় এন্ট্রি (-)"
                        } else "লেনদেন সম্পাদনা",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (currentType == "INCOME") Emerald800 else Color(0xFFC62828)
                    )
                    Divider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(vertical = 4.dp))
                }

                // Type Toggle (আয় vs ব্যয়)
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = currentType == "INCOME",
                            onClick = {
                                currentType = "INCOME"
                                category = "অনুদান"
                            },
                            label = { Text("আয় (+)", fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Emerald800, selectedLabelColor = Color.White),
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = currentType == "EXPENSE",
                            onClick = {
                                currentType = "EXPENSE"
                                category = "বোর্ডিং ও খাবার"
                            },
                            label = { Text("ব্যয় (-)", fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFFC62828), selectedLabelColor = Color.White),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("লেনদেনের বিবরণ / শিরোনাম *") },
                        placeholder = { Text(if (currentType == "INCOME") "যেমন: জনাব রহিম সাহেবের দান" else "যেমন: মাদ্রাসার চাউল ক্রয়") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = amountStr,
                            onValueChange = { amountStr = it },
                            label = { Text("টাকার পরিমাণ (৳) *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1.2f),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = date,
                            onValueChange = { date = it },
                            label = { Text("তারিখ") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )
                    }
                }

                item {
                    Text("খাত (Category) নির্বাচন করুন", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(categories) { c ->
                            FilterChip(
                                selected = category == c,
                                onClick = { category = c },
                                label = { Text(c, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = payeeOrSource,
                            onValueChange = { payeeOrSource = it },
                            label = { Text(if (currentType == "INCOME") "দাতা / উৎস" else "প্রাপক / দোকান") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = voucherNo,
                            onValueChange = { voucherNo = it },
                            label = { Text("ভাউচার / রসিদ নং") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )
                    }
                }

                item {
                    Text("লেনদেনের মাধ্যম", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("নগদ", "ব্যাংক", "বিকাশ/নগদ").forEach { m ->
                            FilterChip(
                                selected = paymentMethod == m,
                                onClick = { paymentMethod = m },
                                label = { Text(m) }
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("অতিরিক্ত নোট (ঐচ্ছিক)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("বাতিল")
                        }

                        Button(
                            onClick = {
                                val amt = amountStr.toDoubleOrNull() ?: 0.0
                                onSave(
                                    transactionToEdit?.id ?: 0L,
                                    currentType,
                                    title,
                                    category,
                                    amt,
                                    date,
                                    paymentMethod,
                                    voucherNo,
                                    payeeOrSource,
                                    reference,
                                    notes
                                )
                            },
                            modifier = Modifier.weight(1.3f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (currentType == "INCOME") Emerald800 else Color(0xFFC62828)
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(if (transactionToEdit == null) "সংরক্ষণ করুন" else "আপডেট করুন")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LoanFormDialog(
    onDismiss: () -> Unit,
    onSave: (
        type: String,
        person: String,
        phone: String,
        amount: Double,
        date: String,
        purpose: String,
        notes: String
    ) -> Unit
) {
    var loanType by remember { mutableStateOf("TAKEN") } // TAKEN (মাদ্রাসা ঋণ গ্রহণ করেছে), GIVEN (মাদ্রাসা ঋণ প্রদান করেছে)
    var personName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var amountStr by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())) }
    var purpose by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text(
                        text = "নতুন ঋণ / করজে হাসানা এন্ট্রি",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Gold800
                    )
                    Divider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(vertical = 4.dp))
                }

                item {
                    Text("ঋণের ধরন নির্বাচন", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = loanType == "TAKEN",
                            onClick = { loanType = "TAKEN" },
                            label = { Text("গৃহীত ঋণ (মাদ্রাসার দেনা)") },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = loanType == "GIVEN",
                            onClick = { loanType = "GIVEN" },
                            label = { Text("প্রদত্ত ঋণ (মাদ্রাসার পাওনা)") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = personName,
                        onValueChange = { personName = it },
                        label = { Text("ব্যক্তি / প্রতিষ্ঠানের নাম *") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = amountStr,
                            onValueChange = { amountStr = it },
                            label = { Text("ঋণের পরিমাণ (৳) *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1.2f),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = it },
                            label = { Text("মোবাইল নম্বর") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = date,
                        onValueChange = { date = it },
                        label = { Text("তারিখ (yyyy-MM-dd)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )
                }

                item {
                    OutlinedTextField(
                        value = purpose,
                        onValueChange = { purpose = it },
                        label = { Text("ঋণের উদ্দেশ্য") },
                        placeholder = { Text("যেমন: ভবন নির্মাণ ফান্ড ঘাটতি") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("বিশেষ শর্ত / ফেরত দেওয়ার মেয়াদ") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("বাতিল")
                        }

                        Button(
                            onClick = {
                                val amt = amountStr.toDoubleOrNull() ?: 0.0
                                onSave(loanType, personName, phone, amt, date, purpose, notes)
                            },
                            modifier = Modifier.weight(1.3f),
                            colors = ButtonDefaults.buttonColors(containerColor = Gold800),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("এন্ট্রি সম্পন্ন করুন")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LoanRepaymentDialog(
    loan: Loan,
    onDismiss: () -> Unit,
    onRepay: (loanId: Long, amount: Double, date: String, method: String, notes: String) -> Unit
) {
    var amountStr by remember { mutableStateOf(loan.remainingAmount.toInt().toString()) }
    var date by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())) }
    var paymentMethod by remember { mutableStateOf("নগদ") }
    var notes by remember { mutableStateOf("") }

    val isTaken = loan.loanType == "TAKEN"

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = if (isTaken) "গৃহীত ঋণ পরিশোধ কিস্তি" else "প্রদত্ত ঋণ আদায় কিস্তি",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Emerald800
                )
                Text(
                    text = "ব্যক্তি: ${loan.personName} • মোট বাকি: ${NumberFormatter.formatCurrency(loan.remainingAmount)}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Divider(color = MaterialTheme.colorScheme.outlineVariant)

                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = { Text("পরিশোধের পরিমাণ (৳) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = date,
                    onValueChange = { date = it },
                    label = { Text("তারিখ") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Text("পরিশোধের মাধ্যম", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("নগদ", "ব্যাংক", "বিকাশ").forEach { m ->
                        FilterChip(
                            selected = paymentMethod == m,
                            onClick = { paymentMethod = m },
                            label = { Text(m) }
                        )
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("মন্তব্য / কিস্তি বিবরণ") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("বাতিল")
                    }

                    Button(
                        onClick = {
                            val amt = amountStr.toDoubleOrNull() ?: 0.0
                            onRepay(loan.id, amt, date, paymentMethod, notes)
                        },
                        modifier = Modifier.weight(1.3f),
                        colors = ButtonDefaults.buttonColors(containerColor = Emerald800),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("কিস্তি সংরক্ষণ")
                    }
                }
            }
        }
    }
}
