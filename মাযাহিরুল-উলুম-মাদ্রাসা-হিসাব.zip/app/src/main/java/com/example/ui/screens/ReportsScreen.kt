package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.MetricStatCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import com.example.util.NumberFormatter
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ReportsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val profile by viewModel.madrasaProfile.collectAsState()
    val summary by viewModel.dashboardSummary.collectAsState()
    val transactions by viewModel.filteredTransactions.collectAsState()
    val allTransactions by viewModel.allTransactions.collectAsState()
    val students by viewModel.allStudents.collectAsState()
    val teachers by viewModel.allTeachers.collectAsState()
    val dateFilter by viewModel.txDateFilter.collectAsState()

    val currentList = if (dateFilter == "ALL") allTransactions else transactions

    val incomeByCategory = remember(currentList) {
        currentList.filter { it.type == "INCOME" }
            .groupBy { it.category }
            .mapValues { entry -> entry.value.sumOf { it.amount } }
    }

    val expenseByCategory = remember(currentList) {
        currentList.filter { it.type == "EXPENSE" }
            .groupBy { it.category }
            .mapValues { entry -> entry.value.sumOf { it.amount } }
    }

    val totalIncome = incomeByCategory.values.sum()
    val totalExpense = expenseByCategory.values.sum()
    val netBalance = totalIncome - totalExpense

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Report Title Header Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Emerald800),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(Emerald900, Emerald800, Color(0xFF047857))
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column {
                        Text(
                            text = profile.nameBn,
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "মাদ্রাসা সামগ্রিক হিসাব ও বিশ্লেষণ রিপোর্ট",
                            color = Gold300Light,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "তারিখ: ${NumberFormatter.toBanglaDigits(SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(Date()))}",
                            color = Emerald100,
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // PDF Export Button
                        Button(
                            onClick = {
                                viewModel.generateAndShareFinancialReport(
                                    context = context,
                                    reportTitle = "মাযাহিরুল উলুম মাদ্রাসা আর্থিক বিবরণী",
                                    dateFilter = dateFilter
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Gold700, contentColor = Color.White),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("পিডিএফ (PDF) রিপোর্ট ডাউনলোড ও প্রিন্ট", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 2. Filter Period
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = dateFilter == "ALL",
                    onClick = { viewModel.setTxDateFilter("ALL") },
                    label = { Text("সার্বিক হিসাব") },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Emerald800, selectedLabelColor = Color.White)
                )
                FilterChip(
                    selected = dateFilter == "THIS_MONTH",
                    onClick = { viewModel.setTxDateFilter("THIS_MONTH") },
                    label = { Text("চলতি মাস") },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Emerald800, selectedLabelColor = Color.White)
                )
                FilterChip(
                    selected = dateFilter == "TODAY",
                    onClick = { viewModel.setTxDateFilter("TODAY") },
                    label = { Text("আজকের দিন") },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Emerald800, selectedLabelColor = Color.White)
                )
            }
        }

        // 3. Core Financial Statement Box
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "আর্থিক স্থিতি বিবরণী (${when(dateFilter) { "TODAY" -> "আজকের"; "THIS_MONTH" -> "চলতি মাসের"; else -> "সার্বিক" }})",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald800
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Divider(color = MaterialTheme.colorScheme.outlineVariant)
                    Spacer(modifier = Modifier.height(8.dp))

                    StatementRow("মোট আয় (Total Income):", NumberFormatter.formatCurrency(totalIncome), valueColor = Emerald800)
                    StatementRow("মোট ব্যয় (Total Expense):", NumberFormatter.formatCurrency(totalExpense), valueColor = Color(0xFFC62828))
                    Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 4.dp))
                    StatementRow(
                        "তহবিল স্থিতি (Net Balance):",
                        NumberFormatter.formatCurrency(netBalance),
                        isBold = true,
                        valueColor = if (netBalance >= 0) Emerald800 else Color(0xFFC62828)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    StatementRow("ছাত্র ফি আদায়:", NumberFormatter.formatCurrency(summary.totalFeeCollection))
                    StatementRow("ছাত্রদের বকেয়া ফি:", NumberFormatter.formatCurrency(summary.totalFeeDue), valueColor = Gold800)
                    StatementRow("শিক্ষকদের প্রদেয় বেতন:", NumberFormatter.formatCurrency(summary.totalSalaryPaid))
                    StatementRow("শিক্ষকদের বকেয়া বেতন:", NumberFormatter.formatCurrency(summary.totalSalaryDue), valueColor = Color(0xFFC62828))
                    StatementRow("মাদ্রাসার দেনা/গৃহীত ঋণ:", NumberFormatter.formatCurrency(summary.totalLoanPayable), valueColor = Color(0xFFC62828))
                    StatementRow("মাদ্রাসার পাওনা/প্রদত্ত ঋণ:", NumberFormatter.formatCurrency(summary.totalLoanReceivable), valueColor = Emerald800)
                }
            }
        }

        // 4. Institutional Metrics Box
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricStatCard(
                    title = "মোট ছাত্র",
                    value = "${NumberFormatter.toBanglaDigits(students.size)} জন",
                    subtitle = "সক্রিয়: ${NumberFormatter.toBanglaDigits(students.count { it.status == "সক্রিয়" })} জন",
                    icon = Icons.Default.School,
                    containerColor = Emerald50,
                    contentColor = Emerald800,
                    modifier = Modifier.weight(1f)
                )
                MetricStatCard(
                    title = "মোট শিক্ষক ও স্টাফ",
                    value = "${NumberFormatter.toBanglaDigits(teachers.size)} জন",
                    subtitle = "সক্রিয়: ${NumberFormatter.toBanglaDigits(teachers.count { it.status == "সক্রিয়" })} জন",
                    icon = Icons.Default.People,
                    containerColor = Gold50,
                    contentColor = Gold800,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // 5. Income Breakdown by Category
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "আয়ের খাতভিত্তিক বিভাজন",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald800
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Divider(color = MaterialTheme.colorScheme.outlineVariant)
                    Spacer(modifier = Modifier.height(6.dp))

                    if (incomeByCategory.isEmpty()) {
                        Text("এই সময়ে কোনো আয়ের রেকর্ড নেই।", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        incomeByCategory.forEach { (cat, amount) ->
                            val pct = if (totalIncome > 0) (amount / totalIncome * 100).toInt() else 0
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "$cat (${NumberFormatter.toBanglaDigits(pct)}%)",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = NumberFormatter.formatCurrency(amount),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Emerald800
                                )
                            }
                        }
                    }
                }
            }
        }

        // 6. Expense Breakdown by Category
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "ব্যয়ের খাতভিত্তিক বিভাজন",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFC62828)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Divider(color = MaterialTheme.colorScheme.outlineVariant)
                    Spacer(modifier = Modifier.height(6.dp))

                    if (expenseByCategory.isEmpty()) {
                        Text("এই সময়ে কোনো ব্যয়ের রেকর্ড নেই।", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        expenseByCategory.forEach { (cat, amount) ->
                            val pct = if (totalExpense > 0) (amount / totalExpense * 100).toInt() else 0
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "$cat (${NumberFormatter.toBanglaDigits(pct)}%)",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = NumberFormatter.formatCurrency(amount),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFFC62828)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatementRow(
    label: String,
    value: String,
    isBold: Boolean = false,
    valueColor: Color = Color.Unspecified
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 13.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.SemiBold,
            color = if (valueColor != Color.Unspecified) valueColor else MaterialTheme.colorScheme.onSurface
        )
    }
}
