package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import com.example.data.local.entity.MadrasaProfile
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import com.example.util.BangladeshDistricts
import com.example.util.NumberFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val profile by viewModel.madrasaProfile.collectAsState()
    val liveDate by viewModel.liveDateState.collectAsState()

    var showEditProfileDialog by remember { mutableStateOf(false) }
    var showDistrictPicker by remember { mutableStateOf(false) }
    var showRestoreDialog by remember { mutableStateOf(false) }

    // GPS location launcher
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            try {
                val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                val loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                    ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                if (loc != null) {
                    viewModel.updateCustomGpsLocation(loc.latitude, loc.longitude)
                } else {
                    Toast.makeText(context, "বর্তমান জিপিএস স্থানাঙ্ক পাওয়া যায়নি, জেলা নির্বাচন করুন।", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "লোকেশন অ্যাক্সেসে সমস্যা: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "লোকেশন পারমিশন পাওয়া যায়নি।", Toast.LENGTH_SHORT).show()
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Madrasa Profile Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = profile.nameBn,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Emerald800
                            )
                            Text(
                                text = profile.nameEn,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = { showEditProfileDialog = true }) {
                            Icon(Icons.Default.Edit, contentDescription = "এডিট", tint = Emerald700)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Divider(color = MaterialTheme.colorScheme.outlineVariant)
                    Spacer(modifier = Modifier.height(8.dp))

                    SettingInfoRow("ঠিকানা:", profile.address)
                    SettingInfoRow("মোবাইল:", profile.phone)
                    SettingInfoRow("মুহতামিম:", profile.principalName)
                }
            }
        }

        // 2. Location & Prayer Time Settings
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "নামাজের সময় ও ভৌগোলিক অবস্থান",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald800
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "বর্তমান নির্ধারিত জেলা: ${profile.selectedDistrict}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showDistrictPicker = true },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.LocationCity, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("জেলা পরিবর্তন", fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                val hasFine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                                val hasCoarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                                if (hasFine || hasCoarse) {
                                    val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                                    val loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                                        ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                                    if (loc != null) {
                                        viewModel.updateCustomGpsLocation(loc.latitude, loc.longitude)
                                    } else {
                                        Toast.makeText(context, "জিপিএস লোকেশন রিড করা যায়নি", Toast.LENGTH_SHORT).show()
                                    }
                                } else {
                                    locationPermissionLauncher.launch(
                                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                                    )
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Emerald800),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.MyLocation, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("বর্তমান GPS", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Asr Madhhab Selection
                    Text("আসর নামাজের মাযহাব:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FilterChip(
                            selected = profile.asrMadhhab == "Hanafi",
                            onClick = { viewModel.updateMadhhab("Hanafi") },
                            label = { Text("হানাফি (মিছলায়ন/দ্বিগুণ ছায়া)") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Emerald800,
                                selectedLabelColor = Color.White
                            )
                        )
                        FilterChip(
                            selected = profile.asrMadhhab == "Shafi",
                            onClick = { viewModel.updateMadhhab("Shafi") },
                            label = { Text("শাফেঈ (মিছল/একগুণ ছায়া)") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Emerald800,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }
        }

        // 3. Hijri Lunar Offset Adjustment
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "চাঁদ দেখা সাপেক্ষে হিজরি তারিখ সমন্বয়",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald800
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "বর্তমান হিজরি তারিখ: ${liveDate.hijriFormatted}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf(-2, -1, 0, 1, 2).forEach { offset ->
                            val isSelected = profile.hijriOffsetDays == offset
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.updateHijriOffset(offset) },
                                label = {
                                    Text(
                                        text = if (offset == 0) "০ দিন" else if (offset > 0) "+$offset" else "$offset",
                                        fontSize = 12.sp
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Emerald800,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }
            }
        }

        // 4. Notifications & Reminders
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "স্মার্ট নোটিফিকেশন ও অ্যালার্ম",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald800
                    )

                    NotificationToggleRow(
                        title = "ওয়াক্তভিত্তিক নামাজের সতর্কবার্তা",
                        subtitle = "প্রতি ওয়াক্ত নামাজের আজানের সময় নোটিফিকেশন",
                        checked = profile.prayerNotificationEnabled,
                        onCheckedChange = {
                            viewModel.updateNotificationSettings(
                                prayer = it,
                                fee = profile.feeDueNotificationEnabled,
                                salary = profile.salaryNotificationEnabled,
                                backup = profile.backupReminderEnabled
                            )
                        }
                    )

                    NotificationToggleRow(
                        title = "ছাত্রদের বকেয়া ফি রিমাইন্ডার",
                        subtitle = "প্রতি মাসের শুরুতে বকেয়া ফি সংগ্রহের তাগাদা",
                        checked = profile.feeDueNotificationEnabled,
                        onCheckedChange = {
                            viewModel.updateNotificationSettings(
                                prayer = profile.prayerNotificationEnabled,
                                fee = it,
                                salary = profile.salaryNotificationEnabled,
                                backup = profile.backupReminderEnabled
                            )
                        }
                    )

                    NotificationToggleRow(
                        title = "শিক্ষক ও স্টাফ বেতন রিমাইন্ডার",
                        subtitle = "মাসিক বেতন দেওয়ার নির্ধারিত তারিখ নোটিফিকেশন",
                        checked = profile.salaryNotificationEnabled,
                        onCheckedChange = {
                            viewModel.updateNotificationSettings(
                                prayer = profile.prayerNotificationEnabled,
                                fee = profile.feeDueNotificationEnabled,
                                salary = it,
                                backup = profile.backupReminderEnabled
                            )
                        }
                    )

                    NotificationToggleRow(
                        title = "সাপ্তাহিক ডাটা ব্যাকআপ রিমাইন্ডার",
                        subtitle = "ডাটা সুরক্ষিত রাখতে প্রতি সপ্তাহে ব্যাকআপের তাগাদা",
                        checked = profile.backupReminderEnabled,
                        onCheckedChange = {
                            viewModel.updateNotificationSettings(
                                prayer = profile.prayerNotificationEnabled,
                                fee = profile.feeDueNotificationEnabled,
                                salary = profile.salaryNotificationEnabled,
                                backup = it
                            )
                        }
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedButton(
                        onClick = {
                            viewModel.sendTestNotification(
                                context,
                                "মাযাহিরুল উলুম মাদ্রাসা নোটিফিকেশন",
                                "সিস্টেম নোটিফিকেশন ও রিমাইন্ডার সঠিকভাবে কাজ করছে।"
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("টেস্ট নোটিফিকেশন পাঠান")
                    }
                }
            }
        }

        // 5. Full Database Backup & Restore (JSON / Offline-First)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "ডাটা ব্যাকআপ ও রিস্টোর (অফলাইন)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald800
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "মাদ্রাসার সমস্ত ছাত্র, শিক্ষক, লেনদেন, ঋণ ও হাজিরা ডাটা একটি সুরক্ষিত ফাইলে এক্সপোর্ট বা ইমপোর্ট করুন।",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { viewModel.exportBackup(context) },
                            colors = ButtonDefaults.buttonColors(containerColor = Emerald800),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ব্যাকআপ ফাইল নিন", fontSize = 12.sp)
                        }

                        OutlinedButton(
                            onClick = { showRestoreDialog = true },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ডাটা রিস্টোর", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // 6. Theme & Language
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "ডিসপ্লে ও ভাষা",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald800
                    )

                    // Theme
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("অ্যাপ থিম", fontSize = 13.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(
                                selected = profile.themeMode == "SYSTEM",
                                onClick = { viewModel.updateThemeMode("SYSTEM") },
                                label = { Text("সিস্টেম", fontSize = 11.sp) }
                            )
                            FilterChip(
                                selected = profile.themeMode == "LIGHT",
                                onClick = { viewModel.updateThemeMode("LIGHT") },
                                label = { Text("লাইট", fontSize = 11.sp) }
                            )
                            FilterChip(
                                selected = profile.themeMode == "DARK",
                                onClick = { viewModel.updateThemeMode("DARK") },
                                label = { Text("ডার্ক", fontSize = 11.sp) }
                            )
                        }
                    }

                    // Language
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("ভাষা (Language)", fontSize = 13.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(
                                selected = profile.appLanguage == "BN",
                                onClick = { viewModel.updateAppLanguage("BN") },
                                label = { Text("বাংলা", fontSize = 11.sp) }
                            )
                            FilterChip(
                                selected = profile.appLanguage == "EN",
                                onClick = { viewModel.updateAppLanguage("EN") },
                                label = { Text("English", fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }
        }

        // 7. App Info Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Emerald50)
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "মাযাহিরুল উলুম মাদ্রাসা হিসাব",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald900
                    )
                    Text(
                        text = "ভার্সন ২.০ (প্রোডাকশন সংস্করণ) • ১০০% অফলাইন",
                        fontSize = 11.sp,
                        color = Emerald800
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "মাদ্রাসার হিসাব, ছাত্র, শিক্ষক ও ওয়াক্ত ক্যালেন্ডার পরিচালনা সমাধান",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }

    // Edit Profile Dialog
    if (showEditProfileDialog) {
        EditProfileDialog(
            profile = profile,
            onDismiss = { showEditProfileDialog = false },
            onSave = { updated ->
                viewModel.updateMadrasaProfile(updated)
                showEditProfileDialog = false
            }
        )
    }

    // District Picker Dialog
    if (showDistrictPicker) {
        DistrictPickerDialog(
            currentDistrict = profile.selectedDistrict,
            onDismiss = { showDistrictPicker = false },
            onSelect = { dist ->
                viewModel.updatePrayerLocation(dist.nameBn)
                showDistrictPicker = false
            }
        )
    }

    // Restore Backup Dialog
    if (showRestoreDialog) {
        RestoreBackupDialog(
            onDismiss = { showRestoreDialog = false },
            onRestore = { jsonContent ->
                viewModel.restoreBackup(jsonContent)
                showRestoreDialog = false
            }
        )
    }
}

@Composable
fun NotificationToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text(title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Emerald800,
                checkedTrackColor = Emerald100
            )
        )
    }
}

@Composable
fun SettingInfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun EditProfileDialog(
    profile: MadrasaProfile,
    onDismiss: () -> Unit,
    onSave: (MadrasaProfile) -> Unit
) {
    var nameBn by remember { mutableStateOf(profile.nameBn) }
    var nameEn by remember { mutableStateOf(profile.nameEn) }
    var address by remember { mutableStateOf(profile.address) }
    var phone by remember { mutableStateOf(profile.phone) }
    var principalName by remember { mutableStateOf(profile.principalName) }
    var establishedYear by remember { mutableStateOf(profile.establishedYear) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text("মাদ্রাসার তথ্য পরিবর্তন", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Emerald800)
                    Divider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(vertical = 4.dp))
                }

                item {
                    OutlinedTextField(
                        value = nameBn,
                        onValueChange = { nameBn = it },
                        label = { Text("মাদ্রাসার নাম (বাংলা)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                item {
                    OutlinedTextField(
                        value = nameEn,
                        onValueChange = { nameEn = it },
                        label = { Text("মাদ্রাসার নাম (English)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                item {
                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text("ঠিকানা") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = it },
                            label = { Text("মোবাইল") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                        OutlinedTextField(
                            value = establishedYear,
                            onValueChange = { establishedYear = it },
                            label = { Text("প্রতিষ্ঠা সাল") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = principalName,
                        onValueChange = { principalName = it },
                        label = { Text("মুহতামিম / প্রধানের নাম") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                            Text("বাতিল")
                        }
                        Button(
                            onClick = {
                                onSave(
                                    profile.copy(
                                        nameBn = nameBn.trim(),
                                        nameEn = nameEn.trim(),
                                        address = address.trim(),
                                        phone = phone.trim(),
                                        principalName = principalName.trim(),
                                        establishedYear = establishedYear.trim()
                                    )
                                )
                            },
                            modifier = Modifier.weight(1.2f),
                            colors = ButtonDefaults.buttonColors(containerColor = Emerald800)
                        ) {
                            Text("সংরক্ষণ")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DistrictPickerDialog(
    currentDistrict: String,
    onDismiss: () -> Unit,
    onSelect: (com.example.util.DistrictInfo) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val districts = remember(query) {
        if (query.isEmpty()) BangladeshDistricts.districts
        else BangladeshDistricts.districts.filter {
            it.nameBn.contains(query, ignoreCase = true) || it.nameEn.contains(query, ignoreCase = true)
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(480.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("জেলা নির্বাচন করুন (${BangladeshDistricts.districts.size} টি)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Emerald800)
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("জেলার নাম দিয়ে খুঁজুন...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(districts) { d ->
                        val isSelected = d.nameBn == currentDistrict
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelect(d) },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) Emerald100 else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${d.nameBn} (${d.nameEn})",
                                    fontSize = 13.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Emerald900 else MaterialTheme.colorScheme.onSurface
                                )
                                if (isSelected) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = Emerald800, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) {
                    Text("বন্ধ করুন")
                }
            }
        }
    }
}

@Composable
fun RestoreBackupDialog(
    onDismiss: () -> Unit,
    onRestore: (String) -> Unit
) {
    var jsonText by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("ডাটাবেজ রিস্টোর (JSON Import)", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Emerald800)
                Text(
                    text = "পূর্বের সংরক্ষিত ব্যাকআপ ফাইলের সম্পূর্ণ টেক্সট নিচে পেস্ট করুন।",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Divider(color = MaterialTheme.colorScheme.outlineVariant)

                OutlinedTextField(
                    value = jsonText,
                    onValueChange = { jsonText = it },
                    placeholder = { Text("এখানে ব্যাকআপ JSON কোড পেস্ট করুন...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                    shape = RoundedCornerShape(10.dp)
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("বাতিল")
                    }
                    Button(
                        onClick = {
                            if (jsonText.isNotBlank()) {
                                onRestore(jsonText.trim())
                            }
                        },
                        enabled = jsonText.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = Emerald800),
                        modifier = Modifier.weight(1.2f)
                    ) {
                        Text("রিস্টোর করুন")
                    }
                }
            }
        }
    }
}
