package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.entity.FeePayment
import com.example.data.local.entity.Student
import com.example.ui.components.EmptyStateWidget
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import com.example.util.NumberFormatter
import java.util.*

@Composable
fun CollectFeeDialog(
    student: Student,
    onDismiss: () -> Unit,
    onCollect: (
        student: Student,
        monthYear: String,
        feeAmount: Double,
        paidAmount: Double,
        paymentMethod: String,
        notes: String
    ) -> Unit
) {
    val months = listOf(
        "জানুয়ারি ২০২৬", "ফেব্রুয়ারি ২০২৬", "মার্চ ২০২৬", "এপ্রিল ২০২৬",
        "মে ২০২৬", "জুন ২০২৬", "জুলাই ২০২৬", "আগস্ট ২০২৬",
        "সেপ্টেম্বর ২০২৬", "অক্টোবর ২০২৬", "নভেম্বর ২০২৬", "ডিসেম্বর ২০২৬"
    )

    var selectedMonth by remember { mutableStateOf("সেপ্টেম্বর ২০২৬") }
    var feeAmountStr by remember { mutableStateOf(student.monthlyFee.toInt().toString()) }
    var paidAmountStr by remember { mutableStateOf(student.monthlyFee.toInt().toString()) }
    var paymentMethod by remember { mutableStateOf("নগদ") }
    var notes by remember { mutableStateOf("") }

    val paymentMethods = listOf("নগদ", "বিকাশ", "নগদ (Nagad)", "রকেট", "ব্যাংক")

    val feeAmount = feeAmountStr.toDoubleOrNull() ?: 0.0
    val paidAmount = paidAmountStr.toDoubleOrNull() ?: 0.0
    val dueAmount = (feeAmount - paidAmount).coerceAtLeast(0.0)

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        text = "ছাত্র মাসিক ফি আদায়",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald800
                    )
                    Text(
                        text = "${student.name} (${student.studentId}) • ${student.className}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Divider(color = MaterialTheme.colorScheme.outlineVariant)
                }

                // Month Selector
                item {
                    Text("ফি আদায়ের মাস:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    MonthDropdown(
                        options = months,
                        selected = selectedMonth,
                        onSelect = { selectedMonth = it }
                    )
                }

                // Fee Amount & Paid Amount
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = feeAmountStr,
                            onValueChange = { feeAmountStr = it },
                            label = { Text("নির্ধারিত ফি (৳)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = paidAmountStr,
                            onValueChange = { paidAmountStr = it },
                            label = { Text("আদায়কৃত টাকা (৳)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )
                    }
                }

                // Due calculation info banner
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (dueAmount > 0) Color(0xFFFEF2F2) else Color(0xFFF0FDF4)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "অবশিষ্ট বকেয়া থাকবে:",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = NumberFormatter.formatCurrency(dueAmount),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (dueAmount > 0) ErrorRed else SuccessGreen
                            )
                        }
                    }
                }

                // Payment Method
                item {
                    Text("পরিশোধের মাধ্যম:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(paymentMethods) { method ->
                            FilterChip(
                                selected = paymentMethod == method,
                                onClick = { paymentMethod = method },
                                label = { Text(method, fontSize = 12.sp) }
                            )
                        }
                    }
                }

                // Notes
                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("মন্তব্য (ঐচ্ছিক)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        maxLines = 2
                    )
                }

                // Action Buttons
                item {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("বাতিল")
                        }

                        Button(
                            onClick = {
                                onCollect(
                                    student,
                                    selectedMonth,
                                    feeAmount,
                                    paidAmount,
                                    paymentMethod,
                                    notes
                                )
                                onDismiss()
                            },
                            modifier = Modifier.weight(1.3f),
                            colors = ButtonDefaults.buttonColors(containerColor = Emerald800),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("আদায় নিশ্চিত করুন")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MonthDropdown(
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded },
        modifier = Modifier.fillMaxWidth()
    ) {
        OutlinedTextField(
            value = selected,
            onValueChange = {},
            readOnly = true,
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = {
                        onSelect(option)
                        expanded = false
                    }
                )
            }
        }
    }
}
