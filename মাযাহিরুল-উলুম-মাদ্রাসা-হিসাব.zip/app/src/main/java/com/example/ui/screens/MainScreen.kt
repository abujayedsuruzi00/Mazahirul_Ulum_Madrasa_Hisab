package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.FeePayment
import com.example.data.local.entity.Student
import com.example.ui.components.DigitalReceiptDialog
import com.example.ui.theme.Emerald800
import com.example.ui.viewmodel.BottomTab
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val currentTab by viewModel.currentTab.collectAsState()
    val uiMessage by viewModel.uiMessage.collectAsState()
    val activeReceipt by viewModel.activeReceiptPayment.collectAsState()
    val profile by viewModel.madrasaProfile.collectAsState()

    // Dialog & Subscreen states
    var showAddStudentDialog by remember { mutableStateOf(false) }
    var studentForFeeCollection by remember { mutableStateOf<Student?>(null) }
    var showAddIncomeDialog by remember { mutableStateOf(false) }
    var showAddExpenseDialog by remember { mutableStateOf(false) }

    // Display toast when uiMessage emits
    LaunchedEffect(uiMessage) {
        uiMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.clearUiMessage()
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                val tabs = listOf(
                    Triple(BottomTab.HOME, Icons.Default.Home, Icons.Outlined.Home),
                    Triple(BottomTab.STUDENTS, Icons.Default.School, Icons.Outlined.School),
                    Triple(BottomTab.TEACHERS, Icons.Default.People, Icons.Outlined.People),
                    Triple(BottomTab.ACCOUNTS, Icons.Default.AccountBalanceWallet, Icons.Outlined.AccountBalanceWallet),
                    Triple(BottomTab.ATTENDANCE, Icons.Default.FactCheck, Icons.Outlined.FactCheck),
                    Triple(BottomTab.REPORTS, Icons.Default.Assessment, Icons.Outlined.Assessment),
                    Triple(BottomTab.SETTINGS, Icons.Default.Settings, Icons.Outlined.Settings)
                )

                tabs.forEach { (tab, filledIcon, outlinedIcon) ->
                    val isSelected = currentTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.setTab(tab) },
                        icon = {
                            Icon(
                                imageVector = if (isSelected) filledIcon else outlinedIcon,
                                contentDescription = tab.titleBn,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        label = {
                            Text(
                                text = when (tab) {
                                    BottomTab.HOME -> "হোম"
                                    BottomTab.STUDENTS -> "ছাত্র"
                                    BottomTab.TEACHERS -> "শিক্ষক"
                                    BottomTab.ACCOUNTS -> "হিসাব"
                                    BottomTab.ATTENDANCE -> "হাজিরা"
                                    BottomTab.REPORTS -> "রিপোর্ট"
                                    BottomTab.SETTINGS -> "সেটিংস"
                                },
                                fontSize = 9.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                maxLines = 1
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Emerald800,
                            selectedTextColor = Emerald800,
                            indicatorColor = Emerald800.copy(alpha = 0.12f)
                        )
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (currentTab) {
                BottomTab.HOME -> HomeScreen(
                    viewModel = viewModel,
                    onNavigateToTab = { viewModel.setTab(it) },
                    onQuickAddStudent = { showAddStudentDialog = true },
                    onQuickCollectFee = {
                        val first = viewModel.allStudents.value.firstOrNull()
                        if (first != null) {
                            studentForFeeCollection = first
                        } else {
                            Toast.makeText(context, "প্রথমে ছাত্র ভর্তি করুন", Toast.LENGTH_SHORT).show()
                            showAddStudentDialog = true
                        }
                    },
                    onQuickAddIncome = { showAddIncomeDialog = true },
                    onQuickAddExpense = { showAddExpenseDialog = true },
                    onQuickOpenLoan = { viewModel.setTab(BottomTab.ACCOUNTS) },
                    onQuickOpenAttendance = { viewModel.setTab(BottomTab.ATTENDANCE) },
                    onViewReceipt = { viewModel.showReceiptDialog(it) }
                )

                BottomTab.STUDENTS -> StudentScreen(
                    viewModel = viewModel,
                    onAddStudentClick = { showAddStudentDialog = true },
                    onCollectFeeForStudent = { studentForFeeCollection = it },
                    onViewReceipt = { viewModel.showReceiptDialog(it) }
                )

                BottomTab.TEACHERS -> TeacherScreen(
                    viewModel = viewModel
                )

                BottomTab.ACCOUNTS -> AccountScreen(
                    viewModel = viewModel
                )

                BottomTab.ATTENDANCE -> AttendanceScreen(
                    viewModel = viewModel
                )

                BottomTab.REPORTS -> ReportsScreen(
                    viewModel = viewModel
                )

                BottomTab.SETTINGS -> SettingsScreen(
                    viewModel = viewModel
                )
            }
        }
    }

    // Global Add Student Dialog
    if (showAddStudentDialog) {
        StudentFormDialog(
            student = null,
            onDismiss = { showAddStudentDialog = false },
            onSave = { id, studentId, name, father, mother, dob, phone, address, admDate, cls, dept, fee, status, notes ->
                viewModel.saveStudent(
                    id = id,
                    studentId = studentId,
                    name = name,
                    fatherName = father,
                    motherName = mother,
                    dob = dob,
                    phone = phone,
                    address = address,
                    admissionDate = admDate,
                    className = cls,
                    department = dept,
                    monthlyFee = fee,
                    status = status,
                    notes = notes
                )
                showAddStudentDialog = false
            }
        )
    }

    // Global Fee Collection Dialog
    if (studentForFeeCollection != null) {
        CollectFeeDialog(
            student = studentForFeeCollection!!,
            onDismiss = { studentForFeeCollection = null },
            onCollect = { student, month, fee, paid, method, notes ->
                viewModel.collectFee(student, month, fee, paid, method, notes)
                studentForFeeCollection = null
            }
        )
    }

    // Global Add Income Dialog
    if (showAddIncomeDialog) {
        TransactionFormDialog(
            type = "INCOME",
            transactionToEdit = null,
            onDismiss = { showAddIncomeDialog = false },
            onSave = { id, type, title, category, amount, date, method, voucher, payee, ref, notes ->
                viewModel.saveTransaction(id, type, title, category, amount, date, method, voucher, payee, ref, notes)
                showAddIncomeDialog = false
            }
        )
    }

    // Global Add Expense Dialog
    if (showAddExpenseDialog) {
        TransactionFormDialog(
            type = "EXPENSE",
            transactionToEdit = null,
            onDismiss = { showAddExpenseDialog = false },
            onSave = { id, type, title, category, amount, date, method, voucher, payee, ref, notes ->
                viewModel.saveTransaction(id, type, title, category, amount, date, method, voucher, payee, ref, notes)
                showAddExpenseDialog = false
            }
        )
    }

    // Global Digital Money Receipt Dialog
    if (activeReceipt != null) {
        DigitalReceiptDialog(
            payment = activeReceipt!!,
            profile = profile,
            onDismiss = { viewModel.showReceiptDialog(null) },
            onShare = {
                viewModel.sharePdfReceipt(context, activeReceipt!!)
            }
        )
    }
}
