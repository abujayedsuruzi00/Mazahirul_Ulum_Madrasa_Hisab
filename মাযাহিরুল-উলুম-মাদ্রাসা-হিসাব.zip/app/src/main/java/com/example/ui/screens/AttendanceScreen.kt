package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.AttendanceRecord
import com.example.data.local.entity.Student
import com.example.ui.components.EmptyStateView
import com.example.ui.components.MetricStatCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import com.example.util.NumberFormatter
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttendanceScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val students by viewModel.filteredStudents.collectAsState()
    val allStudents by viewModel.allStudents.collectAsState()
    val attendanceDate by viewModel.attendanceDate.collectAsState()
    val attendanceList by viewModel.currentAttendanceList.collectAsState()
    val monthlyAttendanceList by viewModel.monthlyAttendanceList.collectAsState()
    val selectedClass by viewModel.selectedClass.collectAsState()

    var selectedSubTab by remember { mutableStateOf(0) } // 0: দৈনিক হাজিরা, 1: মাসিক হাজিরা বিশ্লেষণ

    val attendanceMap = remember(attendanceList) {
        attendanceList.associateBy { it.studentDbId }
    }

    val presentCount = attendanceList.count { it.status == "PRESENT" }
    val absentCount = attendanceList.count { it.status == "ABSENT" }
    val lateCount = attendanceList.count { it.status == "LATE" }
    val leaveCount = attendanceList.count { it.status == "LEAVE" }

    val classes = listOf("সকল শ্রেণি", "নূরানী ১ম", "নূরানী ২য়", "হিফজ বিভাগ", "মিযান", "নাহবেমীর", "হেদায়াতুন্নাহু", "কাফিয়া", "শরহে বেকায়া", "জালালাইন", "মেশকাত", "দাওরায়ে হাদিস")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Sub Tabs (দৈনিক vs মাসিক)
        TabRow(
            selectedTabIndex = selectedSubTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = Emerald800
        ) {
            Tab(
                selected = selectedSubTab == 0,
                onClick = { selectedSubTab = 0 },
                text = { Text("দৈনিক হাজিরা গ্রহণ", fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                icon = { Icon(Icons.Default.FactCheck, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
            Tab(
                selected = selectedSubTab == 1,
                onClick = { selectedSubTab = 1 },
                text = { Text("মাসিক হাজিরা রেজিস্টার", fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                icon = { Icon(Icons.Default.Assessment, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
        }

        if (selectedSubTab == 0) {
            // --- TAB 1: DAILY ATTENDANCE ---
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Date Selector & "Mark All Present" Action
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "হাজিরার তারিখ:",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = NumberFormatter.toBanglaDigits(attendanceDate),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Emerald800
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Button(
                                    onClick = { viewModel.markAllStudentsPresent() },
                                    colors = ButtonDefaults.buttonColors(containerColor = Emerald800),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.height(34.dp)
                                ) {
                                    Icon(Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("সবাই উপস্থিত", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // Attendance Stats Row
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        MetricStatCard(
                            title = "উপস্থিত",
                            value = "${NumberFormatter.toBanglaDigits(presentCount)}",
                            icon = Icons.Default.CheckCircle,
                            containerColor = Emerald50,
                            contentColor = Emerald800,
                            modifier = Modifier.weight(1f)
                        )
                        MetricStatCard(
                            title = "অনুপস্থিত",
                            value = "${NumberFormatter.toBanglaDigits(absentCount)}",
                            icon = Icons.Default.Cancel,
                            containerColor = Color(0xFFFFEBEE),
                            contentColor = Color(0xFFC62828),
                            modifier = Modifier.weight(1f)
                        )
                        MetricStatCard(
                            title = "দেরি",
                            value = "${NumberFormatter.toBanglaDigits(lateCount)}",
                            icon = Icons.Default.Schedule,
                            containerColor = Gold50,
                            contentColor = Gold800,
                            modifier = Modifier.weight(1f)
                        )
                        MetricStatCard(
                            title = "ছুটি",
                            value = "${NumberFormatter.toBanglaDigits(leaveCount)}",
                            icon = Icons.Default.EventBusy,
                            containerColor = Color(0xFFE3F2FD),
                            contentColor = Color(0xFF1565C0),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Class Filter Chips
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(classes) { cls ->
                            val isSel = if (cls == "সকল শ্রেণি") selectedClass.isEmpty() else selectedClass == cls
                            FilterChip(
                                selected = isSel,
                                onClick = { viewModel.setStudentClass(if (cls == "সকল শ্রেণি") "" else cls) },
                                label = { Text(cls, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                // Students Attendance List
                if (students.isEmpty()) {
                    item {
                        EmptyStateView(
                            title = "কোনো ছাত্র পাওয়া যায়নি",
                            subtitle = "প্রথমে ছাত্র-ছাত্রী সেকশনে গিয়ে ছাত্র ভর্তি করুন",
                            icon = Icons.Default.School
                        )
                    }
                } else {
                    items(students) { student ->
                        val record = attendanceMap[student.id]
                        val currentStatus = record?.status ?: "NONE"

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = student.name,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = "${student.className} • রোল/আইডি: ${student.studentId}",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    // Status Badge
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = when (currentStatus) {
                                            "PRESENT" -> Emerald100
                                            "ABSENT" -> Color(0xFFFFCDD2)
                                            "LATE" -> Gold100
                                            "LEAVE" -> Color(0xFFBBDEFB)
                                            else -> MaterialTheme.colorScheme.surfaceVariant
                                        }
                                    ) {
                                        Text(
                                            text = when (currentStatus) {
                                                "PRESENT" -> "উপস্থিত"
                                                "ABSENT" -> "অনুপস্থিত"
                                                "LATE" -> "দেরি"
                                                "LEAVE" -> "ছুটি"
                                                else -> "অনির্ধারিত"
                                            },
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = when (currentStatus) {
                                                "PRESENT" -> Emerald900
                                                "ABSENT" -> Color(0xFFB71C1C)
                                                "LATE" -> Gold900
                                                "LEAVE" -> Color(0xFF0D47A1)
                                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                                            },
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Status Action Buttons
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    AttendanceStatusButton(
                                        text = "উপস্থিত",
                                        isSelected = currentStatus == "PRESENT",
                                        activeColor = Emerald800,
                                        modifier = Modifier.weight(1f),
                                        onClick = { viewModel.markAttendance(student.id, "PRESENT") }
                                    )
                                    AttendanceStatusButton(
                                        text = "অনুপস্থিত",
                                        isSelected = currentStatus == "ABSENT",
                                        activeColor = Color(0xFFC62828),
                                        modifier = Modifier.weight(1f),
                                        onClick = { viewModel.markAttendance(student.id, "ABSENT") }
                                    )
                                    AttendanceStatusButton(
                                        text = "দেরি",
                                        isSelected = currentStatus == "LATE",
                                        activeColor = Gold800,
                                        modifier = Modifier.weight(1f),
                                        onClick = { viewModel.markAttendance(student.id, "LATE") }
                                    )
                                    AttendanceStatusButton(
                                        text = "ছুটি",
                                        isSelected = currentStatus == "LEAVE",
                                        activeColor = Color(0xFF1565C0),
                                        modifier = Modifier.weight(1f),
                                        onClick = { viewModel.markAttendance(student.id, "LEAVE") }
                                    )
                                }
                            }
                        }
                    }
                }

                item { Spacer(modifier = Modifier.height(70.dp)) }
            }
        } else {
            // --- TAB 2: MONTHLY ATTENDANCE REGISTER ---
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        text = "চলতি মাসের ছাত্র হাজিরা পরিসংখ্যান ও অগ্রগতি",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald800
                    )
                }

                if (allStudents.isEmpty()) {
                    item {
                        EmptyStateView(
                            title = "কোনো ছাত্র তালিকাভুক্ত নেই",
                            subtitle = "ছাত্র যুক্ত করার পর মাসিক হাজিরা হার দেখা যাবে",
                            icon = Icons.Default.Assessment
                        )
                    }
                } else {
                    items(allStudents) { student ->
                        val studentRecords = monthlyAttendanceList.filter { it.studentDbId == student.id }
                        val totalRecorded = studentRecords.size
                        val pCount = studentRecords.count { it.status == "PRESENT" }
                        val aCount = studentRecords.count { it.status == "ABSENT" }
                        val lCount = studentRecords.count { it.status == "LATE" }
                        val leaveC = studentRecords.count { it.status == "LEAVE" }

                        val rate = if (totalRecorded > 0) (pCount.toDouble() / totalRecorded * 100).toInt() else 0

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(student.name, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                        Text("${student.className} • ${student.studentId}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = "${NumberFormatter.toBanglaDigits(rate)}% উপস্থিতি",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (rate >= 80) Emerald800 else if (rate >= 60) Gold800 else Color(0xFFC62828)
                                        )
                                        Text(
                                            text = "মোট দিন: ${NumberFormatter.toBanglaDigits(totalRecorded)}",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                // Progress Bar
                                LinearProgressIndicator(
                                    progress = { (rate / 100f).coerceIn(0f, 1f) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(3.dp)),
                                    color = if (rate >= 80) Emerald800 else if (rate >= 60) Gold700 else Color(0xFFC62828),
                                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("উপস্থিত: ${NumberFormatter.toBanglaDigits(pCount)} দিন", fontSize = 11.sp, color = Emerald800)
                                    Text("অনুপস্থিত: ${NumberFormatter.toBanglaDigits(aCount)} দিন", fontSize = 11.sp, color = Color(0xFFC62828))
                                    Text("দেরি: ${NumberFormatter.toBanglaDigits(lCount)}", fontSize = 11.sp, color = Gold800)
                                    Text("ছুটি: ${NumberFormatter.toBanglaDigits(leaveC)}", fontSize = 11.sp, color = Color(0xFF1565C0))
                                }
                            }
                        }
                    }
                }

                item { Spacer(modifier = Modifier.height(70.dp)) }
            }
        }
    }
}

@Composable
fun AttendanceStatusButton(
    text: String,
    isSelected: Boolean,
    activeColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = modifier.height(32.dp),
        shape = RoundedCornerShape(8.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) activeColor else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            contentColor = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
        ),
        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
    ) {
        Text(text = text, fontSize = 10.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
    }
}
