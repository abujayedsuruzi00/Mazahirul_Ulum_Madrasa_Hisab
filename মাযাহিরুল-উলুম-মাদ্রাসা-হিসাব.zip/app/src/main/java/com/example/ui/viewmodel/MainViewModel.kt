package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.MadrasaApplication
import com.example.data.local.entity.*
import com.example.util.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

enum class BottomTab(val titleBn: String, val titleEn: String, val iconName: String) {
    HOME("হোম", "Home", "home"),
    STUDENTS("ছাত্র-ছাত্রী", "Students", "school"),
    ACCOUNTS("আয়-ব্যয়", "Accounts", "account_balance_wallet"),
    TEACHERS("শিক্ষক ও বেতন", "Teachers & Salary", "people"),
    ATTENDANCE("হাজিরা", "Attendance", "fact_check"),
    REPORTS("রিপোর্ট", "Reports", "analytics"),
    SETTINGS("সেটিংস", "Settings", "settings")
}

data class DashboardSummary(
    val totalStudents: Int = 0,
    val activeStudents: Int = 0,
    val totalTeachers: Int = 0,
    val activeTeachers: Int = 0,
    val presentCountToday: Int = 0,
    val todayIncome: Double = 0.0,
    val todayExpense: Double = 0.0,
    val totalIncome: Double = 0.0,
    val totalExpense: Double = 0.0,
    val netBalance: Double = 0.0,
    val totalFeeCollection: Double = 0.0,
    val totalFeeDue: Double = 0.0,
    val totalSalaryPaid: Double = 0.0,
    val totalSalaryDue: Double = 0.0,
    val totalLoanPayable: Double = 0.0,
    val totalLoanReceivable: Double = 0.0
)

data class LiveDateState(
    val timeFormatted: String = "",
    val gregorianFormatted: String = "",
    val banglaFormatted: String = "",
    val hijriFormatted: String = "",
    val hijriOffset: Int = 0
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as MadrasaApplication).repository

    // Current Bottom Tab
    private val _currentTab = MutableStateFlow(BottomTab.HOME)
    val currentTab: StateFlow<BottomTab> = _currentTab.asStateFlow()

    fun setTab(tab: BottomTab) {
        _currentTab.value = tab
    }

    // Live Clock & Date State
    private val _liveDateState = MutableStateFlow(LiveDateState())
    val liveDateState: StateFlow<LiveDateState> = _liveDateState.asStateFlow()

    // Prayer Schedule State
    private val _prayerSchedule = MutableStateFlow<PrayerSchedule?>(null)
    val prayerSchedule: StateFlow<PrayerSchedule?> = _prayerSchedule.asStateFlow()

    // Madrasa Profile State
    val madrasaProfile: StateFlow<MadrasaProfile> = repository.madrasaProfile
        .map { it ?: MadrasaProfile() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, MadrasaProfile())

    // --- Students ---
    val allStudents: StateFlow<List<Student>> = repository.allStudents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _studentSearchQuery = MutableStateFlow("")
    val studentSearchQuery: StateFlow<String> = _studentSearchQuery.asStateFlow()

    private val _selectedDepartment = MutableStateFlow("")
    val selectedDepartment: StateFlow<String> = _selectedDepartment.asStateFlow()

    private val _selectedClass = MutableStateFlow("")
    val selectedClass: StateFlow<String> = _selectedClass.asStateFlow()

    val filteredStudents: StateFlow<List<Student>> = combine(
        allStudents,
        _studentSearchQuery,
        _selectedDepartment,
        _selectedClass
    ) { list, query, dept, cls ->
        list.filter { student ->
            val matchQuery = query.isEmpty() ||
                    student.name.contains(query, ignoreCase = true) ||
                    student.studentId.contains(query, ignoreCase = true) ||
                    student.phone.contains(query, ignoreCase = true)
            val matchDept = dept.isEmpty() || student.department == dept
            val matchClass = cls.isEmpty() || student.className == cls
            matchQuery && matchDept && matchClass
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Selected Student for Details / Edit
    private val _selectedStudent = MutableStateFlow<Student?>(null)
    val selectedStudent: StateFlow<Student?> = _selectedStudent.asStateFlow()

    fun selectStudent(student: Student?) {
        _selectedStudent.value = student
    }

    val selectedStudentPayments: StateFlow<List<FeePayment>> = _selectedStudent.flatMapLatest { student ->
        if (student == null) flowOf(emptyList())
        else repository.getPaymentsForStudent(student.id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Fee Payments
    val allFeePayments: StateFlow<List<FeePayment>> = repository.allPayments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Teachers & Staff ---
    val allTeachers: StateFlow<List<TeacherStaff>> = repository.allTeachers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalMonthlySalaryBudget: StateFlow<Double> = repository.totalMonthlySalaryBudget
        .map { it ?: 0.0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    private val _teacherSearchQuery = MutableStateFlow("")
    val teacherSearchQuery: StateFlow<String> = _teacherSearchQuery.asStateFlow()

    private val _selectedDesignation = MutableStateFlow("")
    val selectedDesignation: StateFlow<String> = _selectedDesignation.asStateFlow()

    val filteredTeachers: StateFlow<List<TeacherStaff>> = combine(
        allTeachers,
        _teacherSearchQuery,
        _selectedDesignation
    ) { list, query, designation ->
        list.filter { teacher ->
            val matchQuery = query.isEmpty() ||
                    teacher.name.contains(query, ignoreCase = true) ||
                    teacher.employeeId.contains(query, ignoreCase = true) ||
                    teacher.phone.contains(query, ignoreCase = true)
            val matchDesig = designation.isEmpty() || teacher.designation == designation
            matchQuery && matchDesig
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedTeacher = MutableStateFlow<TeacherStaff?>(null)
    val selectedTeacher: StateFlow<TeacherStaff?> = _selectedTeacher.asStateFlow()

    fun selectTeacher(teacher: TeacherStaff?) {
        _selectedTeacher.value = teacher
    }

    val selectedTeacherSalaryPayments: StateFlow<List<SalaryPayment>> = _selectedTeacher.flatMapLatest { teacher ->
        if (teacher == null) flowOf(emptyList())
        else repository.getSalaryPaymentsForTeacher(teacher.id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Salary Payments ---
    val allSalaryPayments: StateFlow<List<SalaryPayment>> = repository.allSalaryPayments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedSalaryMonth = MutableStateFlow(
        NumberFormatter.getMonthNameBn(Calendar.getInstance().get(Calendar.MONTH)) + " " +
                NumberFormatter.toBanglaDigits(Calendar.getInstance().get(Calendar.YEAR))
    )
    val selectedSalaryMonth: StateFlow<String> = _selectedSalaryMonth.asStateFlow()

    fun setSalaryMonth(monthYear: String) {
        _selectedSalaryMonth.value = monthYear
    }

    val monthlySalaryPayments: StateFlow<List<SalaryPayment>> = _selectedSalaryMonth.flatMapLatest { month ->
        repository.getSalaryPaymentsForMonth(month)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Transactions & Filter State ---
    val allTransactions: StateFlow<List<Transaction>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _txSearchQuery = MutableStateFlow("")
    val txSearchQuery: StateFlow<String> = _txSearchQuery.asStateFlow()

    private val _txTypeFilter = MutableStateFlow("") // "", "INCOME", "EXPENSE"
    val txTypeFilter: StateFlow<String> = _txTypeFilter.asStateFlow()

    private val _txCategoryFilter = MutableStateFlow("")
    val txCategoryFilter: StateFlow<String> = _txCategoryFilter.asStateFlow()

    private val _txDateFilter = MutableStateFlow("ALL") // "TODAY", "THIS_MONTH", "ALL", "CUSTOM"
    val txDateFilter: StateFlow<String> = _txDateFilter.asStateFlow()

    val filteredTransactions: StateFlow<List<Transaction>> = combine(
        allTransactions,
        _txSearchQuery,
        _txTypeFilter,
        _txCategoryFilter,
        _txDateFilter
    ) { list, query, type, cat, dateFilter ->
        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val monthPrefix = todayStr.substring(0, 7) // YYYY-MM

        list.filter { tx ->
            val matchType = type.isEmpty() || tx.type.equals(type, ignoreCase = true)
            val matchCat = cat.isEmpty() || tx.category.equals(cat, ignoreCase = true)
            val matchQuery = query.isEmpty() ||
                    tx.title.contains(query, ignoreCase = true) ||
                    tx.payeeOrSource.contains(query, ignoreCase = true) ||
                    tx.reference.contains(query, ignoreCase = true) ||
                    tx.voucherNo.contains(query, ignoreCase = true) ||
                    tx.description.contains(query, ignoreCase = true)

            val matchDate = when (dateFilter) {
                "TODAY" -> tx.date == todayStr
                "THIS_MONTH" -> tx.date.startsWith(monthPrefix)
                else -> true
            }

            matchType && matchCat && matchQuery && matchDate
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Loans
    val allLoans: StateFlow<List<Loan>> = repository.allLoans
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedLoan = MutableStateFlow<Loan?>(null)
    val selectedLoan: StateFlow<Loan?> = _selectedLoan.asStateFlow()

    fun selectLoan(loan: Loan?) {
        _selectedLoan.value = loan
    }

    val selectedLoanRepayments: StateFlow<List<LoanRepayment>> = _selectedLoan.flatMapLatest { loan ->
        if (loan == null) flowOf(emptyList())
        else repository.getRepaymentsForLoan(loan.id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Attendance
    private val _attendanceDate = MutableStateFlow(
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    )
    val attendanceDate: StateFlow<String> = _attendanceDate.asStateFlow()

    fun setAttendanceDate(date: String) {
        _attendanceDate.value = date
    }

    val currentAttendanceList: StateFlow<List<AttendanceRecord>> = _attendanceDate.flatMapLatest { date ->
        repository.getAttendanceForDate(date)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Monthly attendance list
    private val _attendanceMonthPrefix = MutableStateFlow(
        SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date())
    )
    val attendanceMonthPrefix: StateFlow<String> = _attendanceMonthPrefix.asStateFlow()

    val monthlyAttendanceList: StateFlow<List<AttendanceRecord>> = _attendanceMonthPrefix.flatMapLatest { prefix ->
        repository.getAttendanceForMonth(prefix)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Dashboard aggregated stats
    private val studentStatsFlow = combine(repository.totalStudentCount, repository.activeStudentCount) { total, active ->
        Pair(total, active)
    }
    private val teacherStatsFlow = combine(repository.totalTeacherCount, repository.activeTeacherCount) { total, active ->
        Pair(total, active)
    }
    private val todayFinanceFlow = combine(
        repository.getTodayIncome(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())),
        repository.getTodayExpense(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()))
    ) { inc, exp -> Pair(inc, exp) }

    private val totalFinanceFlow = combine(repository.totalIncome, repository.totalExpense) { inc, exp ->
        Pair(inc, exp)
    }
    private val feeStatsFlow = combine(repository.totalFeeCollection, repository.totalFeeDue) { col, due ->
        Pair(col, due)
    }
    private val salaryStatsFlow = combine(repository.totalSalaryPaid, repository.totalSalaryDue) { paid, due ->
        Pair(paid, due)
    }
    private val loanStatsFlow = combine(repository.totalLoanPayable, repository.totalLoanReceivable) { pay, rec ->
        Pair(pay, rec)
    }
    private val presentTodayCountFlow = repository.getPresentCountForDate(
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    )

    val dashboardSummary: StateFlow<DashboardSummary> = combine(
        combine(studentStatsFlow, teacherStatsFlow) { st, t -> Pair(st, t) },
        combine(todayFinanceFlow, totalFinanceFlow) { td, tot -> Pair(td, tot) },
        combine(feeStatsFlow, salaryStatsFlow, loanStatsFlow) { f, s, l -> Triple(f, s, l) }
    ) { (stStats, tStats), (todayFin, totalFin), (feeStats, salStats, loanStats) ->
        DashboardSummary(
            totalStudents = stStats.first,
            activeStudents = stStats.second,
            totalTeachers = tStats.first,
            activeTeachers = tStats.second,
            presentCountToday = 0,
            todayIncome = todayFin.first,
            todayExpense = todayFin.second,
            totalIncome = totalFin.first,
            totalExpense = totalFin.second,
            netBalance = totalFin.first - totalFin.second,
            totalFeeCollection = feeStats.first,
            totalFeeDue = feeStats.second,
            totalSalaryPaid = salStats.first,
            totalSalaryDue = salStats.second,
            totalLoanPayable = loanStats.first,
            totalLoanReceivable = loanStats.second
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardSummary())

    // Feedback Toast / Alert Message
    private val _uiMessage = MutableStateFlow<String?>(null)
    val uiMessage: StateFlow<String?> = _uiMessage.asStateFlow()

    fun clearUiMessage() {
        _uiMessage.value = null
    }

    // Active Receipt for Digital Receipt Dialog
    private val _activeReceiptPayment = MutableStateFlow<FeePayment?>(null)
    val activeReceiptPayment: StateFlow<FeePayment?> = _activeReceiptPayment.asStateFlow()

    fun showReceiptDialog(payment: FeePayment?) {
        _activeReceiptPayment.value = payment
    }

    init {
        // Start 1-second dynamic ticker for live clock, 3-date engine, and prayer countdown
        viewModelScope.launch {
            while (isActive) {
                val now = Date()
                val profile = madrasaProfile.value
                val offset = profile.hijriOffsetDays

                // 1. Live Time
                val timeStr = NumberFormatter.formatTimeBn(now)

                // 2. Gregorian Formatted
                val gregSdf = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.ENGLISH)
                val engDate = gregSdf.format(now)
                val gregorianBn = formatGregorianToBn(engDate)

                // 3. Bangla Date
                val banglaRes = BanglaDateHelper.getBanglaDate(now)

                // 4. Hijri Date
                val hijriRes = HijriDateHelper.getHijriDate(now, offset)

                _liveDateState.value = LiveDateState(
                    timeFormatted = timeStr,
                    gregorianFormatted = gregorianBn,
                    banglaFormatted = banglaRes.formattedString,
                    hijriFormatted = hijriRes.formattedString,
                    hijriOffset = offset
                )

                // 5. Prayer Times
                val isHanafi = profile.asrMadhhab.equals("Hanafi", ignoreCase = true)
                val lat = profile.latitude
                val lng = profile.longitude
                _prayerSchedule.value = PrayerTimeCalculator.calculatePrayerTimes(
                    latitude = lat,
                    longitude = lng,
                    date = now,
                    isHanafi = isHanafi
                )

                delay(1000)
            }
        }
    }

    private fun formatGregorianToBn(engDateStr: String): String {
        return NumberFormatter.toBanglaDigits(
            engDateStr
                .replace("Sunday", "রবিবার")
                .replace("Monday", "সোমবার")
                .replace("Tuesday", "মঙ্গলবার")
                .replace("Wednesday", "বুধবার")
                .replace("Thursday", "বৃহস্পতিবার")
                .replace("Friday", "শুক্রবার")
                .replace("Saturday", "শনিবার")
                .replace("January", "জানুয়ারি")
                .replace("February", "ফেব্রুয়ারি")
                .replace("March", "মার্চ")
                .replace("April", "এপ্রিল")
                .replace("May", "মে")
                .replace("June", "জুন")
                .replace("July", "জুলাই")
                .replace("August", "আগস্ট")
                .replace("September", "সেপ্টেম্বর")
                .replace("October", "অক্টোবর")
                .replace("November", "নভেম্বর")
                .replace("December", "ডিসেম্বর")
        )
    }

    // --- Search & Filter Actions ---
    fun setStudentSearchQuery(query: String) {
        _studentSearchQuery.value = query
    }

    fun setStudentDepartment(dept: String) {
        _selectedDepartment.value = if (_selectedDepartment.value == dept) "" else dept
    }

    fun setStudentClass(cls: String) {
        _selectedClass.value = if (_selectedClass.value == cls) "" else cls
    }

    fun setTeacherSearchQuery(query: String) {
        _teacherSearchQuery.value = query
    }

    fun setTeacherDesignation(desig: String) {
        _selectedDesignation.value = if (_selectedDesignation.value == desig) "" else desig
    }

    fun setTxSearchQuery(query: String) {
        _txSearchQuery.value = query
    }

    fun setTxTypeFilter(type: String) {
        _txTypeFilter.value = type
    }

    fun setTxCategoryFilter(cat: String) {
        _txCategoryFilter.value = if (_txCategoryFilter.value == cat) "" else cat
    }

    fun setTxDateFilter(dateFilter: String) {
        _txDateFilter.value = dateFilter
    }

    // --- Student Actions ---
    fun saveStudent(
        id: Long,
        studentId: String,
        name: String,
        fatherName: String,
        motherName: String,
        dob: String,
        phone: String,
        address: String,
        admissionDate: String,
        className: String,
        department: String,
        monthlyFee: Double,
        status: String,
        notes: String
    ) {
        if (name.isBlank()) {
            _uiMessage.value = "অনুগ্রহ করে ছাত্রের নাম লিখুন"
            return
        }

        viewModelScope.launch {
            try {
                val customId = if (studentId.isBlank()) {
                    val count = repository.totalStudentCount.first() + 1
                    "MU-${Calendar.getInstance().get(Calendar.YEAR)}-${String.format(Locale.ENGLISH, "%03d", count)}"
                } else studentId

                val student = Student(
                    id = id,
                    studentId = customId,
                    name = name.trim(),
                    fatherName = fatherName.trim(),
                    motherName = motherName.trim(),
                    dateOfBirth = dob.trim(),
                    phone = phone.trim(),
                    address = address.trim(),
                    admissionDate = if (admissionDate.isBlank()) SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) else admissionDate,
                    className = className,
                    department = department,
                    monthlyFee = monthlyFee.coerceAtLeast(0.0),
                    status = status,
                    notes = notes.trim()
                )

                if (id == 0L) {
                    repository.insertStudent(student)
                    _uiMessage.value = "নতুন ছাত্র সফলভাবে যুক্ত হয়েছে"
                } else {
                    repository.updateStudent(student)
                    _uiMessage.value = "ছাত্রের তথ্য আপডেট হয়েছে"
                }
            } catch (e: Exception) {
                _uiMessage.value = "ত্রুটি: ${e.message}"
            }
        }
    }

    fun deleteStudent(student: Student) {
        viewModelScope.launch {
            try {
                repository.deleteStudent(student)
                if (_selectedStudent.value?.id == student.id) {
                    _selectedStudent.value = null
                }
                _uiMessage.value = "${student.name}-এর তথ্য ডিলিট করা হয়েছে"
            } catch (e: Exception) {
                _uiMessage.value = "ত্রুটি: ${e.message}"
            }
        }
    }

    // --- Teacher Actions ---
    fun saveTeacher(
        id: Long,
        name: String,
        employeeId: String,
        phone: String,
        address: String,
        joiningDate: String,
        designation: String,
        salary: Double,
        status: String,
        notes: String
    ) {
        if (name.isBlank()) {
            _uiMessage.value = "অনুগ্রহ করে শিক্ষকের নাম লিখুন"
            return
        }

        viewModelScope.launch {
            try {
                val customEmpId = if (employeeId.isBlank()) {
                    val count = repository.totalTeacherCount.first() + 1
                    "EMP-${String.format(Locale.ENGLISH, "%03d", count)}"
                } else employeeId

                val teacher = TeacherStaff(
                    id = id,
                    name = name.trim(),
                    employeeId = customEmpId,
                    phone = phone.trim(),
                    address = address.trim(),
                    joiningDate = if (joiningDate.isBlank()) SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) else joiningDate,
                    designation = designation.ifBlank { "হিফজ শিক্ষক" },
                    salary = salary.coerceAtLeast(0.0),
                    status = status.ifBlank { "সক্রিয়" },
                    notes = notes.trim()
                )

                if (id == 0L) {
                    repository.insertTeacher(teacher)
                    _uiMessage.value = "নতুন শিক্ষক/স্টাফ সফলভাবে যুক্ত হয়েছে"
                } else {
                    repository.updateTeacher(teacher)
                    _uiMessage.value = "শিক্ষক/স্টাফের তথ্য আপডেট হয়েছে"
                }
            } catch (e: Exception) {
                _uiMessage.value = "ত্রুটি: ${e.message}"
            }
        }
    }

    fun deleteTeacher(teacher: TeacherStaff) {
        viewModelScope.launch {
            try {
                repository.deleteTeacher(teacher)
                if (_selectedTeacher.value?.id == teacher.id) {
                    _selectedTeacher.value = null
                }
                _uiMessage.value = "${teacher.name}-এর তথ্য ডিলিট করা হয়েছে"
            } catch (e: Exception) {
                _uiMessage.value = "ত্রুটি: ${e.message}"
            }
        }
    }

    // --- Salary Actions ---
    fun paySalary(
        teacher: TeacherStaff,
        monthYear: String,
        salaryAmount: Double,
        bonus: Double,
        deduction: Double,
        paidAmount: Double,
        paymentDate: String,
        paymentMethod: String,
        notes: String
    ) {
        if (salaryAmount <= 0 && bonus <= 0) {
            _uiMessage.value = "বেতনের পরিমাণ ০ এর বেশি হতে হবে"
            return
        }
        val netPayable = (salaryAmount + bonus - deduction).coerceAtLeast(0.0)
        if (paidAmount < 0) {
            _uiMessage.value = "পরিশোধের পরিমাণ ঋণাত্মক হতে পারবে না"
            return
        }
        if (paidAmount > netPayable) {
            _uiMessage.value = "পরিশোধের পরিমাণ সর্বমোট প্রদেয় বেতনের (${NumberFormatter.formatCurrency(netPayable)}) চেয়ে বেশি হতে পারবে না"
            return
        }

        viewModelScope.launch {
            try {
                val finalDate = if (paymentDate.isBlank()) SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) else paymentDate
                repository.paySalary(
                    teacher = teacher,
                    monthYear = monthYear,
                    salaryAmount = salaryAmount,
                    bonus = bonus,
                    deduction = deduction,
                    paidAmount = paidAmount,
                    paymentDate = finalDate,
                    paymentMethod = paymentMethod,
                    notes = notes
                )
                _uiMessage.value = "${teacher.name}-এর ${monthYear} মাসের বেতন সফলভাবে প্রদান করা হয়েছে"
            } catch (e: Exception) {
                _uiMessage.value = "বেতন প্রদানে ত্রুটি: ${e.message}"
            }
        }
    }

    fun deleteSalaryPayment(payment: SalaryPayment) {
        viewModelScope.launch {
            try {
                repository.deleteSalaryPayment(payment)
                _uiMessage.value = "বেতন ভাউচারটি ডিলিট করা হয়েছে"
            } catch (e: Exception) {
                _uiMessage.value = "ত্রুটি: ${e.message}"
            }
        }
    }

    // --- Fee Actions ---
    fun collectFee(
        student: Student,
        monthYear: String,
        feeAmount: Double,
        paidAmount: Double,
        paymentMethod: String,
        notes: String
    ) {
        if (feeAmount <= 0) {
            _uiMessage.value = "নির্ধারিত ফি ০ বা তার চেয়ে বেশি হতে হবে"
            return
        }
        if (paidAmount < 0) {
            _uiMessage.value = "আদায়কৃত পরিমাণ ঋণাত্মক হতে পারবে না"
            return
        }
        if (paidAmount > feeAmount) {
            _uiMessage.value = "আদায়কৃত টাকা ধার্যকৃত ফি এর চেয়ে বেশি হতে পারে না"
            return
        }

        viewModelScope.launch {
            try {
                val payment = repository.collectFee(
                    student = student,
                    monthYear = monthYear,
                    feeAmount = feeAmount,
                    paidAmount = paidAmount,
                    paymentMethod = paymentMethod,
                    notes = notes
                )
                _uiMessage.value = "ফি সফলভাবে আদায় হয়েছে। রসিদ তৈরি সম্পন্ন।"
                _activeReceiptPayment.value = payment
            } catch (e: Exception) {
                _uiMessage.value = "ফি আদায়ে ত্রুটি: ${e.message}"
            }
        }
    }

    fun sharePdfReceipt(context: Context, payment: FeePayment) {
        PdfReceiptGenerator.generateAndShareReceipt(context, payment, madrasaProfile.value)
    }

    // --- Transaction Actions (Income / Expense) ---
    fun saveTransaction(
        id: Long = 0,
        type: String, // "INCOME" or "EXPENSE"
        title: String,
        category: String,
        amount: Double,
        date: String,
        paymentMethod: String,
        voucherNo: String,
        payeeOrSource: String,
        reference: String,
        notes: String
    ) {
        if (title.isBlank()) {
            _uiMessage.value = "অনুগ্রহ করে শিরোনাম/খাত লিখুন"
            return
        }
        if (amount <= 0) {
            _uiMessage.value = "টাকার পরিমাণ ০ এর চেয়ে বেশি হতে হবে"
            return
        }

        viewModelScope.launch {
            try {
                val finalDate = if (date.isBlank()) SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) else date
                val finalVoucher = if (voucherNo.isBlank()) "VOC-${System.currentTimeMillis() % 100000}" else voucherNo

                if (id == 0L) {
                    repository.addTransaction(
                        type = type,
                        title = title.trim(),
                        category = category,
                        amount = amount,
                        date = finalDate,
                        paymentMethod = paymentMethod,
                        voucherNo = finalVoucher,
                        description = notes.trim(),
                        payeeOrSource = payeeOrSource.trim(),
                        reference = reference.trim(),
                        notes = notes.trim()
                    )
                    _uiMessage.value = if (type == "INCOME") "আয় এন্ট্রি সফল হয়েছে" else "ব্যয় এন্ট্রি সফল হয়েছে"
                } else {
                    val tx = Transaction(
                        id = id,
                        type = type,
                        title = title.trim(),
                        category = category,
                        amount = amount,
                        date = finalDate,
                        paymentMethod = paymentMethod,
                        voucherNo = finalVoucher,
                        description = notes.trim(),
                        payeeOrSource = payeeOrSource.trim(),
                        reference = reference.trim(),
                        notes = notes.trim()
                    )
                    repository.updateTransaction(tx)
                    _uiMessage.value = "লেনদেন তথ্য সফলভাবে আপডেট হয়েছে"
                }
            } catch (e: Exception) {
                _uiMessage.value = "ত্রুটি: ${e.message}"
            }
        }
    }

    fun deleteTransaction(transaction: Transaction) {
        viewModelScope.launch {
            try {
                repository.deleteTransaction(transaction)
                _uiMessage.value = "লেনদেনটি মুছে ফেলা হয়েছে"
            } catch (e: Exception) {
                _uiMessage.value = "ত্রুটি: ${e.message}"
            }
        }
    }

    // --- Loan Actions ---
    fun createLoan(
        loanType: String,
        personName: String,
        phone: String,
        amount: Double,
        date: String,
        purpose: String,
        notes: String
    ) {
        if (personName.isBlank()) {
            _uiMessage.value = "অনুগ্রহ করে ব্যক্তির নাম লিখুন"
            return
        }
        if (amount <= 0) {
            _uiMessage.value = "ঋণের পরিমাণ ০ এর চেয়ে বেশি হতে হবে"
            return
        }

        viewModelScope.launch {
            try {
                val finalDate = if (date.isBlank()) SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) else date
                repository.createLoan(
                    loanType = loanType,
                    personName = personName.trim(),
                    phone = phone.trim(),
                    totalAmount = amount,
                    date = finalDate,
                    purpose = purpose.trim(),
                    notes = notes.trim()
                )
                _uiMessage.value = "ঋণ এন্ট্রি সফলভাবে সম্পন্ন হয়েছে"
            } catch (e: Exception) {
                _uiMessage.value = "ত্রুটি: ${e.message}"
            }
        }
    }

    fun addLoanRepayment(
        loanId: Long,
        amount: Double,
        date: String,
        paymentMethod: String,
        notes: String
    ) {
        if (amount <= 0) {
            _uiMessage.value = "পরিশোধের পরিমাণ ০ এর বেশি হতে হবে"
            return
        }
        viewModelScope.launch {
            try {
                val finalDate = if (date.isBlank()) SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) else date
                repository.addLoanRepayment(
                    loanId = loanId,
                    amount = amount,
                    date = finalDate,
                    paymentMethod = paymentMethod,
                    notes = notes.trim()
                )
                _uiMessage.value = "ঋণের কিস্তি সফলভাবে সংরক্ষিত হয়েছে"
            } catch (e: Exception) {
                _uiMessage.value = "ত্রুটি: ${e.message}"
            }
        }
    }

    fun deleteLoan(loan: Loan) {
        viewModelScope.launch {
            try {
                repository.deleteLoan(loan)
                if (_selectedLoan.value?.id == loan.id) {
                    _selectedLoan.value = null
                }
                _uiMessage.value = "ঋণের রেকর্ডটি ডিলিট করা হয়েছে"
            } catch (e: Exception) {
                _uiMessage.value = "ত্রুটি: ${e.message}"
            }
        }
    }

    // --- Attendance Actions ---
    fun markAttendance(studentId: Long, status: String, remarks: String = "") {
        viewModelScope.launch {
            try {
                val date = _attendanceDate.value
                repository.markAttendance(studentId, date, status, remarks)
            } catch (e: Exception) {
                _uiMessage.value = "হাজিরা সংরক্ষণে ত্রুটি: ${e.message}"
            }
        }
    }

    fun markAllStudentsPresent() {
        viewModelScope.launch {
            try {
                val date = _attendanceDate.value
                val students = allStudents.value.filter { it.status == "সক্রিয়" }
                repository.markAllStudentsPresent(students, date)
                _uiMessage.value = "সকল সক্রিয় ছাত্রের উপস্থিতি মার্ক করা হয়েছে (${students.size} জন)"
            } catch (e: Exception) {
                _uiMessage.value = "ত্রুটি: ${e.message}"
            }
        }
    }

    // --- Reports Generation & Export ---
    fun generateAndShareFinancialReport(context: Context, reportTitle: String, dateFilter: String) {
        val transactions = filteredTransactions.value
        val summary = dashboardSummary.value
        val totalInc = transactions.filter { it.type == "INCOME" }.sumOf { it.amount }
        val totalExp = transactions.filter { it.type == "EXPENSE" }.sumOf { it.amount }
        val net = totalInc - totalExp

        PdfReportGenerator.generateAndShareFinancialReport(
            context = context,
            profile = madrasaProfile.value,
            reportTitle = reportTitle,
            dateRangeStr = when (dateFilter) {
                "TODAY" -> "আজকের (${SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())})"
                "THIS_MONTH" -> "চলতি মাসের হিসাব"
                else -> "সার্বিক পূর্ণাঙ্গ হিসাব"
            },
            totalIncome = totalInc,
            totalExpense = totalExp,
            netBalance = net,
            transactions = transactions
        )
    }

    // --- Backup & Restore Actions ---
    fun exportBackup(context: Context) {
        viewModelScope.launch {
            try {
                repository.exportAndShareBackup()
                _uiMessage.value = "ব্যাকআপ সফলভাবে প্রস্তুত হয়েছে"
            } catch (e: Exception) {
                _uiMessage.value = "ব্যাকআপে ত্রুটি: ${e.message}"
            }
        }
    }

    fun restoreBackup(jsonString: String) {
        viewModelScope.launch {
            try {
                val (success, message) = repository.restoreBackupJson(jsonString)
                _uiMessage.value = message
            } catch (e: Exception) {
                _uiMessage.value = "রিস্টোরে ত্রুটি: ${e.message}"
            }
        }
    }

    // --- Settings Actions ---
    fun updateMadrasaProfile(profile: MadrasaProfile) {
        viewModelScope.launch {
            try {
                repository.updateProfile(profile)
                _uiMessage.value = "মাদ্রাসার তথ্য আপডেট হয়েছে"
            } catch (e: Exception) {
                _uiMessage.value = "ত্রুটি: ${e.message}"
            }
        }
    }

    fun updateHijriOffset(offset: Int) {
        viewModelScope.launch {
            try {
                repository.updateHijriOffset(offset)
                _uiMessage.value = "হিজরি তারিখ সমন্বয় করা হয়েছে ($offset দিন)"
            } catch (e: Exception) {
                _uiMessage.value = "ত্রুটি: ${e.message}"
            }
        }
    }

    fun updatePrayerLocation(districtName: String) {
        val dist = BangladeshDistricts.findDistrict(districtName)
        viewModelScope.launch {
            try {
                repository.updateLocation(dist.nameBn, dist.latitude, dist.longitude)
                _uiMessage.value = "নামাজের অবস্থান পরিবর্তন: ${dist.nameBn}"
            } catch (e: Exception) {
                _uiMessage.value = "ত্রুটি: ${e.message}"
            }
        }
    }

    fun updateCustomGpsLocation(lat: Double, lng: Double) {
        viewModelScope.launch {
            try {
                repository.updateLocation("বর্তমান জিপিএস লোকেশন", lat, lng)
                _uiMessage.value = "জিপিএস লোকেশন আপডেট হয়েছে"
            } catch (e: Exception) {
                _uiMessage.value = "ত্রুটি: ${e.message}"
            }
        }
    }

    fun updateMadhhab(madhhab: String) {
        viewModelScope.launch {
            try {
                repository.updateMadhhab(madhhab, madrasaProfile.value.calculationMethod)
                _uiMessage.value = "মাযহাব সেটিং আপডেট হয়েছে: ${if (madhhab == "Hanafi") "হানাফি" else "শাফেঈ"}"
            } catch (e: Exception) {
                _uiMessage.value = "ত্রুটি: ${e.message}"
            }
        }
    }

    fun updateThemeMode(theme: String) {
        viewModelScope.launch {
            try {
                repository.updateThemeMode(theme)
                _uiMessage.value = "থিম পরিবর্তন করা হয়েছে: ${when(theme) { "LIGHT" -> "লাইট মোড"; "DARK" -> "ডার্ক মোড"; else -> "সিস্টেম ডিফল্ট" }}"
            } catch (e: Exception) {
                _uiMessage.value = "ত্রুটি: ${e.message}"
            }
        }
    }

    fun updateAppLanguage(lang: String) {
        viewModelScope.launch {
            try {
                repository.updateAppLanguage(lang)
                _uiMessage.value = "ভাষা পরিবর্তন করা হয়েছে: ${if (lang == "BN") "বাংলা" else "English"}"
            } catch (e: Exception) {
                _uiMessage.value = "ত্রুটি: ${e.message}"
            }
        }
    }

    fun updateNotificationSettings(prayer: Boolean, fee: Boolean, salary: Boolean, backup: Boolean) {
        viewModelScope.launch {
            try {
                repository.updateNotificationSettings(prayer, fee, salary, backup)
                _uiMessage.value = "নোটিফিকেশন সেটিংস সংরক্ষিত হয়েছে"
            } catch (e: Exception) {
                _uiMessage.value = "ত্রুটি: ${e.message}"
            }
        }
    }

    fun sendTestNotification(context: Context, title: String, message: String) {
        NotificationHelper.showNotification(
            context = context,
            title = title,
            message = message,
            channelId = NotificationHelper.MANAGEMENT_CHANNEL_ID
        )
        _uiMessage.value = "টেস্ট নোটিফিকেশন পাঠানো হয়েছে"
    }
}
