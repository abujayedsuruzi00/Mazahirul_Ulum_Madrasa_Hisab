package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.FeePayment
import com.example.data.local.entity.Transaction
import com.example.ui.components.IslamicHeaderBanner
import com.example.ui.components.MetricStatCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.BottomTab
import com.example.ui.viewmodel.MainViewModel
import com.example.util.NumberFormatter
import com.example.util.PrayerItem

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onNavigateToTab: (BottomTab) -> Unit,
    onQuickAddStudent: () -> Unit,
    onQuickCollectFee: () -> Unit,
    onQuickAddIncome: () -> Unit,
    onQuickAddExpense: () -> Unit,
    onQuickOpenLoan: () -> Unit,
    onQuickOpenAttendance: () -> Unit,
    onViewReceipt: (FeePayment) -> Unit
) {
    val profile by viewModel.madrasaProfile.collectAsState()
    val liveDate by viewModel.liveDateState.collectAsState()
    val prayerSchedule by viewModel.prayerSchedule.collectAsState()
    val summary by viewModel.dashboardSummary.collectAsState()
    val recentTransactions by viewModel.allTransactions.collectAsState()
    val recentPayments by viewModel.allFeePayments.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // 1. Madrasa Header Banner
        item {
            IslamicHeaderBanner(
                madrasaName = profile.nameBn,
                slogan = profile.slogan,
                principalName = profile.principalName
            )
        }

        // 2. Live Time & Three Date System Cards
        item {
            ThreeDateSection(
                liveTime = liveDate.timeFormatted,
                gregorianDate = liveDate.gregorianFormatted,
                banglaDate = liveDate.banglaFormatted,
                hijriDate = liveDate.hijriFormatted,
                hijriOffset = liveDate.hijriOffset
            )
        }

        // 3. Dynamic Solar Prayer Times Widget
        item {
            if (prayerSchedule != null) {
                PrayerTimesCard(
                    prayerSchedule = prayerSchedule!!,
                    districtName = profile.selectedDistrict,
                    madhhabName = if (profile.asrMadhhab.equals("Hanafi", ignoreCase = true)) "হানাফি" else "শাফেঈ",
                    onLocationClick = { onNavigateToTab(BottomTab.SETTINGS) }
                )
            }
        }

        // 4. Quick Actions Grid
        item {
            SectionTitle(title = "কুইক অ্যাকশন (Quick Actions)", subtitle = "দ্রুত সেবা ও লেনদেন")
            QuickActionsGrid(
                onAddStudent = onQuickAddStudent,
                onCollectFee = onQuickCollectFee,
                onAddIncome = onQuickAddIncome,
                onAddExpense = onQuickAddExpense,
                onOpenLoan = onQuickOpenLoan,
                onOpenAttendance = onQuickOpenAttendance,
                onOpenReports = { onNavigateToTab(BottomTab.REPORTS) }
            )
        }

        // 5. Financial & Madrasa Summary Stats
        item {
            SectionTitle(title = "মাদ্রাসা ও হিসাব সারসংক্ষেপ", subtitle = "রিয়েল-টাইম ডাটাবেজ তথ্য")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Row 1: Today Income & Today Expense
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricStatCard(
                        title = "আজকের আয়",
                        value = NumberFormatter.formatCurrency(summary.todayIncome),
                        subtitle = "দৈনিক প্রাপ্তি",
                        icon = Icons.Default.TrendingUp,
                        accentColor = SuccessGreen,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateToTab(BottomTab.ACCOUNTS) }
                    )
                    MetricStatCard(
                        title = "আজকের ব্যয়",
                        value = NumberFormatter.formatCurrency(summary.todayExpense),
                        subtitle = "দৈনিক খরচ",
                        icon = Icons.Default.TrendingDown,
                        accentColor = ErrorRed,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateToTab(BottomTab.ACCOUNTS) }
                    )
                }

                // Row 2: Net Cash Balance & Total Students
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricStatCard(
                        title = "বর্তমান ব্যালেন্স",
                        value = NumberFormatter.formatCurrency(summary.netBalance),
                        subtitle = "ক্যাশ ইন হ্যান্ড",
                        icon = Icons.Default.AccountBalanceWallet,
                        accentColor = Emerald800,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateToTab(BottomTab.ACCOUNTS) }
                    )
                    MetricStatCard(
                        title = "মোট ছাত্র",
                        value = "${NumberFormatter.toBanglaDigits(summary.totalStudents)} জন",
                        subtitle = "সক্রিয়: ${NumberFormatter.toBanglaDigits(summary.activeStudents)} জন",
                        icon = Icons.Default.School,
                        accentColor = Gold600,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateToTab(BottomTab.STUDENTS) }
                    )
                }

                // Row 3: Fee Collection & Fee Due
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricStatCard(
                        title = "মোট ফি আদায়",
                        value = NumberFormatter.formatCurrency(summary.totalFeeCollection),
                        subtitle = "ছাত্রদের বেতন",
                        icon = Icons.Default.ReceiptLong,
                        accentColor = Emerald700,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateToTab(BottomTab.STUDENTS) }
                    )
                    MetricStatCard(
                        title = "মোট ফি বকেয়া",
                        value = NumberFormatter.formatCurrency(summary.totalFeeDue),
                        subtitle = "বাকি আছে",
                        icon = Icons.Default.PendingActions,
                        accentColor = WarningOrange,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateToTab(BottomTab.STUDENTS) }
                    )
                }

                // Row 4: Loans (Payable vs Receivable)
                if (summary.totalLoanPayable > 0 || summary.totalLoanReceivable > 0) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricStatCard(
                            title = "গৃহীত ঋণ (দেয়)",
                            value = NumberFormatter.formatCurrency(summary.totalLoanPayable),
                            subtitle = "মাদ্রাসার ঋণ",
                            icon = Icons.Default.CreditCard,
                            accentColor = ErrorRed,
                            modifier = Modifier.weight(1f),
                            onClick = onQuickOpenLoan
                        )
                        MetricStatCard(
                            title = "প্রদত্ত ঋণ (পাওনা)",
                            value = NumberFormatter.formatCurrency(summary.totalLoanReceivable),
                            subtitle = "ফেরতযোগ্য",
                            icon = Icons.Default.Handshake,
                            accentColor = InfoBlue,
                            modifier = Modifier.weight(1f),
                            onClick = onQuickOpenLoan
                        )
                    }
                }
            }
        }

        // 6. Recent Transactions
        item {
            Spacer(modifier = Modifier.height(8.dp))
            SectionTitle(
                title = "সর্বশেষ লেনদেন (Recent Transactions)",
                subtitle = "আয় ও ব্যয়ের বিবরণ",
                trailingActionText = "সব দেখুন",
                onTrailingClick = { onNavigateToTab(BottomTab.ACCOUNTS) }
            )
        }

        if (recentTransactions.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "এখনো কোনো লেনদেন যোগ করা হয়নি।",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        } else {
            items(recentTransactions.take(4)) { transaction ->
                TransactionMiniItem(transaction = transaction)
            }
        }

        // 7. Recent Fee Collections
        item {
            Spacer(modifier = Modifier.height(8.dp))
            SectionTitle(
                title = "সর্বশেষ ফি আদায় ও রসিদ",
                subtitle = "মানি রসিদ দেখুন ও প্রিন্ট করুন",
                trailingActionText = "সব দেখুন",
                onTrailingClick = { onNavigateToTab(BottomTab.STUDENTS) }
            )
        }

        if (recentPayments.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "এখনো কোনো ফি আদায়ের রেকর্ড নেই।",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        } else {
            items(recentPayments.take(3)) { payment ->
                FeePaymentMiniItem(
                    payment = payment,
                    onViewReceipt = { onViewReceipt(payment) }
                )
            }
        }
    }
}

@Composable
private fun SectionTitle(
    title: String,
    subtitle: String? = null,
    trailingActionText: String? = null,
    onTrailingClick: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        if (trailingActionText != null && onTrailingClick != null) {
            TextButton(onClick = onTrailingClick) {
                Text(
                    text = trailingActionText,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Emerald700
                )
            }
        }
    }
}

@Composable
fun ThreeDateSection(
    liveTime: String,
    gregorianDate: String,
    banglaDate: String,
    hijriDate: String,
    hijriOffset: Int
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Live Digital Time Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(Emerald600)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "লাইভ সময় ও ত্রি-তারিখ সিস্টেম",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald800
                    )
                }
                Text(
                    text = liveTime,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 3 Date Rows
            DateItemRow(
                badgeLabel = "হিজরি",
                badgeColor = Color(0xFF065F46),
                badgeTextColor = Color.White,
                dateText = hijriDate,
                extraBadge = if (hijriOffset != 0) "চাঁদ ${if (hijriOffset > 0) "+$hijriOffset" else "$hijriOffset"}" else null
            )
            Spacer(modifier = Modifier.height(6.dp))
            DateItemRow(
                badgeLabel = "বাংলা",
                badgeColor = Color(0xFFD97706),
                badgeTextColor = Color.White,
                dateText = banglaDate
            )
            Spacer(modifier = Modifier.height(6.dp))
            DateItemRow(
                badgeLabel = "ইংরেজি",
                badgeColor = Color(0xFF0284C7),
                badgeTextColor = Color.White,
                dateText = gregorianDate
            )
        }
    }
}

@Composable
private fun DateItemRow(
    badgeLabel: String,
    badgeColor: Color,
    badgeTextColor: Color,
    dateText: String,
    extraBadge: String? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(badgeColor)
                .padding(horizontal = 8.dp, vertical = 2.dp)
        ) {
            Text(
                text = badgeLabel,
                color = badgeTextColor,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = dateText,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
        if (extraBadge != null) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Gold100)
                    .padding(horizontal = 6.dp, vertical = 1.dp)
            ) {
                Text(
                    text = extraBadge,
                    fontSize = 9.sp,
                    color = Gold700,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun PrayerTimesCard(
    prayerSchedule: com.example.util.PrayerSchedule,
    districtName: String,
    madhhabName: String,
    onLocationClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header with Location & Next Prayer Countdown
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.clickable { onLocationClick() },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = Emerald700,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "$districtName ($madhhabName)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald800
                    )
                    Icon(
                        imageVector = Icons.Default.ArrowDropDown,
                        contentDescription = null,
                        tint = Emerald700,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Emerald100)
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "পরবর্তী: ${prayerSchedule.nextPrayerName} (${prayerSchedule.formattedCountdown})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald900
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 6 Prayers Grid
            val prayers = listOf(
                PrayerItem("fajr", "ফজর", "Fajr", prayerSchedule.fajr, prayerSchedule.fajrTime, prayerSchedule.currentPrayerName == "ফজর", prayerSchedule.nextPrayerName == "ফজর"),
                PrayerItem("sunrise", "সূর্যোদয়", "Sunrise", prayerSchedule.sunrise, prayerSchedule.sunriseTime, prayerSchedule.currentPrayerName == "সূর্যোদয়", prayerSchedule.nextPrayerName == "সূর্যোদয়"),
                PrayerItem("dhuhr", "যোহর", "Dhuhr", prayerSchedule.dhuhr, prayerSchedule.dhuhrTime, prayerSchedule.currentPrayerName == "যোহর", prayerSchedule.nextPrayerName == "যোহর"),
                PrayerItem("asr", "আসর", "Asr", prayerSchedule.asr, prayerSchedule.asrTime, prayerSchedule.currentPrayerName == "আসর", prayerSchedule.nextPrayerName == "আসর"),
                PrayerItem("maghrib", "মাগরিব", "Maghrib", prayerSchedule.maghrib, prayerSchedule.maghribTime, prayerSchedule.currentPrayerName == "মাগরিব", prayerSchedule.nextPrayerName == "মাগরিব"),
                PrayerItem("isha", "ইশা", "Isha", prayerSchedule.isha, prayerSchedule.ishaTime, prayerSchedule.currentPrayerName == "ইশা", prayerSchedule.nextPrayerName == "ইশা")
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                prayers.forEach { item ->
                    PrayerPill(item = item, modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun PrayerPill(
    item: PrayerItem,
    modifier: Modifier = Modifier
) {
    val isHighlighted = item.isCurrent || item.isNext
    val bgColor = when {
        item.isCurrent -> Emerald800
        item.isNext -> Gold100
        else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
    }
    val textColor = when {
        item.isCurrent -> Color.White
        item.isNext -> Gold700
        else -> MaterialTheme.colorScheme.onSurface
    }

    Column(
        modifier = modifier
            .padding(horizontal = 2.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(bgColor)
            .padding(vertical = 6.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = item.nameBn,
            fontSize = 11.sp,
            fontWeight = if (isHighlighted) FontWeight.Bold else FontWeight.Medium,
            color = textColor,
            maxLines = 1
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = item.timeFormatted,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (item.isCurrent) Gold300Light else textColor,
            maxLines = 1
        )
    }
}

@Composable
fun QuickActionsGrid(
    onAddStudent: () -> Unit,
    onCollectFee: () -> Unit,
    onAddIncome: () -> Unit,
    onAddExpense: () -> Unit,
    onOpenLoan: () -> Unit,
    onOpenAttendance: () -> Unit,
    onOpenReports: () -> Unit
) {
    val actions = listOf(
        QuickActionItem("ছাত্র ভর্তি", Icons.Default.PersonAdd, Emerald800, onAddStudent),
        QuickActionItem("ফি আদায়", Icons.Default.Receipt, Emerald700, onCollectFee),
        QuickActionItem("আয় যোগ", Icons.Default.AddCircle, SuccessGreen, onAddIncome),
        QuickActionItem("ব্যয় যোগ", Icons.Default.RemoveCircle, ErrorRed, onAddExpense),
        QuickActionItem("ঋণ/করজ", Icons.Default.Handshake, Gold600, onOpenLoan),
        QuickActionItem("হাজিরা", Icons.Default.CheckCircle, InfoBlue, onOpenAttendance),
        QuickActionItem("হিসাব রিপোর্ট", Icons.Default.Assessment, Color(0xFF6B21A8), onOpenReports)
    )

    LazyRow(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(actions) { action ->
            Card(
                modifier = Modifier
                    .width(85.dp)
                    .clickable { action.onClick() },
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp, horizontal = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(action.color.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = action.icon,
                            contentDescription = null,
                            tint = action.color,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = action.title,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

data class QuickActionItem(
    val title: String,
    val icon: ImageVector,
    val color: Color,
    val onClick: () -> Unit
)

@Composable
fun TransactionMiniItem(transaction: Transaction) {
    val isIncome = transaction.type == "INCOME"
    val amountColor = if (isIncome) SuccessGreen else ErrorRed
    val sign = if (isIncome) "+" else "-"

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(if (isIncome) Color(0xFFDCFCE7) else Color(0xFFFEE2E2)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isIncome) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                        contentDescription = null,
                        tint = amountColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = transaction.title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${transaction.category} • ${NumberFormatter.toBanglaDigits(transaction.date)}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Text(
                text = "$sign ${NumberFormatter.formatCurrency(transaction.amount)}",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = amountColor
            )
        }
    }
}

@Composable
fun FeePaymentMiniItem(
    payment: FeePayment,
    onViewReceipt: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clickable { onViewReceipt() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Emerald100),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Receipt,
                        contentDescription = null,
                        tint = Emerald800,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "${payment.studentName} (${payment.studentCustomId})",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${payment.monthYear} • রসিদ: ${payment.receiptNo}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = NumberFormatter.formatCurrency(payment.paidAmount),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Emerald800
                )
                if (payment.dueAmount > 0) {
                    Text(
                        text = "বকেয়া: ${NumberFormatter.formatCurrency(payment.dueAmount)}",
                        fontSize = 10.sp,
                        color = ErrorRed
                    )
                } else {
                    Text(
                        text = "পরিশোধিত",
                        fontSize = 10.sp,
                        color = SuccessGreen,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}
