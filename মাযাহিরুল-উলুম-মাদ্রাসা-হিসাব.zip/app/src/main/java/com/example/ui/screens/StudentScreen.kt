package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.entity.FeePayment
import com.example.data.local.entity.Student
import com.example.ui.components.EmptyStateWidget
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import com.example.util.NumberFormatter
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun StudentScreen(
    viewModel: MainViewModel,
    onAddStudentClick: () -> Unit,
    onCollectFeeForStudent: (Student) -> Unit,
    onViewReceipt: (FeePayment) -> Unit
) {
    val students by viewModel.filteredStudents.collectAsState()
    val searchQuery by viewModel.studentSearchQuery.collectAsState()
    val selectedDept by viewModel.selectedDepartment.collectAsState()
    val selectedClass by viewModel.selectedClass.collectAsState()

    val selectedStudent by viewModel.selectedStudent.collectAsState()
    val studentPayments by viewModel.selectedStudentPayments.collectAsState()

    var studentToEdit by remember { mutableStateOf<Student?>(null) }
    var studentToDelete by remember { mutableStateOf<Student?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }

    val departments = listOf("হিফজ বিভাগ", "নূরানী বিভাগ", "কিতাব বিভাগ", "জেনারেল")
    val classes = listOf("নূরানী ১ম", "নূরানী ২য়", "নাজেরা", "হিফজুল কুরআন", "কিতাব ১ম বর্ষ", "কিতাব ২য় বর্ষ", "দাওরায়ে হাদিস")

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // 1. Search Bar
            SearchBar(
                query = searchQuery,
                onQueryChange = { viewModel.setStudentSearchQuery(it) }
            )

            // 2. Department & Class Filters
            FilterChipsRow(
                departments = departments,
                selectedDept = selectedDept,
                onDeptSelect = { viewModel.setStudentDepartment(it) },
                classes = classes,
                selectedClass = selectedClass,
                onClassSelect = { viewModel.setStudentClass(it) }
            )

            // 3. Student List or Empty State
            if (students.isEmpty()) {
                EmptyStateWidget(
                    title = "কোনো ছাত্র পাওয়া যায়নি",
                    description = if (searchQuery.isNotEmpty()) "অনুসন্ধানের সাথে মিল পাওয়া যায়নি" else "এখনো কোনো ছাত্র যুক্ত করা হয়নি। নতুন ছাত্র ভর্তি করুন।",
                    icon = Icons.Default.School,
                    actionButtonText = "নতুন ছাত্র ভর্তি",
                    onActionClick = { showAddDialog = true }
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 90.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text(
                            text = "মোট ছাত্র: ${NumberFormatter.toBanglaDigits(students.size)} জন",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }

                    items(students, key = { it.id }) { student ->
                        StudentCardItem(
                            student = student,
                            onClick = { viewModel.selectStudent(student) },
                            onCollectFee = { onCollectFeeForStudent(student) },
                            onEdit = { studentToEdit = student },
                            onDelete = { studentToDelete = student }
                        )
                    }
                }
            }
        }

        // Floating Action Button
        FloatingActionButton(
            onClick = { showAddDialog = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 85.dp, end = 20.dp),
            containerColor = Emerald800,
            contentColor = Color.White
        ) {
            Icon(Icons.Default.PersonAdd, contentDescription = "ছাত্র যোগ")
        }
    }

    // Add / Edit Student Dialog
    if (showAddDialog || studentToEdit != null) {
        StudentFormDialog(
            student = studentToEdit,
            onDismiss = {
                showAddDialog = false
                studentToEdit = null
            },
            onSave = { id, studentId, name, father, mother, dob, phone, address, admDate, cls, dept, fee, status, notes ->
                viewModel.saveStudent(
                    id = id,
                    studentId = studentId,
                    name = name,
                    fatherName = father,
                    motherName = mother,
                    dob = dob,
                    phone = phone,
                    address = address,
                    admissionDate = admDate,
                    className = cls,
                    department = dept,
                    monthlyFee = fee,
                    status = status,
                    notes = notes
                )
                showAddDialog = false
                studentToEdit = null
            }
        )
    }

    // Student Details Dialog / Sheet
    if (selectedStudent != null) {
        StudentDetailsDialog(
            student = selectedStudent!!,
            payments = studentPayments,
            onDismiss = { viewModel.selectStudent(null) },
            onCollectFee = {
                val s = selectedStudent!!
                viewModel.selectStudent(null)
                onCollectFeeForStudent(s)
            },
            onEdit = {
                val s = selectedStudent!!
                viewModel.selectStudent(null)
                studentToEdit = s
            },
            onDelete = {
                val s = selectedStudent!!
                viewModel.selectStudent(null)
                studentToDelete = s
            },
            onViewReceipt = onViewReceipt
        )
    }

    // Delete Confirmation Dialog
    if (studentToDelete != null) {
        AlertDialog(
            onDismissRequest = { studentToDelete = null },
            icon = { Icon(Icons.Default.DeleteForever, contentDescription = null, tint = ErrorRed) },
            title = { Text("ছাত্রের তথ্য মুছে ফেলুন") },
            text = { Text("আপনি কি নিশ্চিতভাবে ${studentToDelete!!.name} (${studentToDelete!!.studentId})-এর তথ্য ডাটাবেজ থেকে মুছে ফেলতে চান?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteStudent(studentToDelete!!)
                        studentToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                ) {
                    Text("হ্যাঁ, ডিলিট করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { studentToDelete = null }) {
                    Text("বাতিল")
                }
            }
        )
    }
}

@Composable
private fun SearchBar(
    query: String,
    onQueryChange: (String) -> Unit
) {
    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        placeholder = { Text("নাম, আইডি বা মোবাইল নম্বর দিয়ে খুঁজুন...") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Emerald700) },
        trailingIcon = {
            if (query.isNotEmpty()) {
                IconButton(onClick = { onQueryChange("") }) {
                    Icon(Icons.Default.Clear, contentDescription = "Clear")
                }
            }
        },
        singleLine = true,
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Emerald700,
            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
        )
    )
}

@Composable
private fun FilterChipsRow(
    departments: List<String>,
    selectedDept: String,
    onDeptSelect: (String) -> Unit,
    classes: List<String>,
    selectedClass: String,
    onClassSelect: (String) -> Unit
) {
    Column(modifier = Modifier.padding(bottom = 6.dp)) {
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            item {
                FilterChip(
                    selected = selectedDept.isEmpty() && selectedClass.isEmpty(),
                    onClick = {
                        onDeptSelect("")
                        onClassSelect("")
                    },
                    label = { Text("সকল") }
                )
            }
            items(departments) { dept ->
                FilterChip(
                    selected = selectedDept == dept,
                    onClick = { onDeptSelect(dept) },
                    label = { Text(dept) }
                )
            }
            items(classes) { cls ->
                FilterChip(
                    selected = selectedClass == cls,
                    onClick = { onClassSelect(cls) },
                    label = { Text(cls) }
                )
            }
        }
    }
}

@Composable
fun StudentCardItem(
    student: Student,
    onClick: () -> Unit,
    onCollectFee: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    var showMenu by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Avatar + Name + Class
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Emerald100),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = student.name.take(1),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Emerald800
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = student.name,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            StatusBadge(status = student.status)
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "আইডি: ${student.studentId} • ${student.className}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Action Menu
                Box {
                    IconButton(onClick = { showMenu = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "মেনু")
                    }
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("বিস্তারিত দেখুন") },
                            leadingIcon = { Icon(Icons.Default.Visibility, contentDescription = null) },
                            onClick = {
                                showMenu = false
                                onClick()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("ফি আদায় করুন") },
                            leadingIcon = { Icon(Icons.Default.Receipt, contentDescription = null) },
                            onClick = {
                                showMenu = false
                                onCollectFee()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("এডিট করুন") },
                            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                            onClick = {
                                showMenu = false
                                onEdit()
                            }
                        )
                        Divider()
                        DropdownMenuItem(
                            text = { Text("মুছে ফেলুন", color = ErrorRed) },
                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = ErrorRed) },
                            onClick = {
                                showMenu = false
                                onDelete()
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(10.dp))

            // Footer info: Monthly fee & Phone dial action
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "মাসিক ফি: ",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = NumberFormatter.formatCurrency(student.monthlyFee),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald800
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (student.phone.isNotEmpty()) {
                        FilledTonalIconButton(
                            onClick = {
                                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${student.phone}"))
                                context.startActivity(intent)
                            },
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Phone,
                                contentDescription = "কল",
                                modifier = Modifier.size(16.dp),
                                tint = Emerald800
                            )
                        }
                    }

                    Button(
                        onClick = onCollectFee,
                        colors = ButtonDefaults.buttonColors(containerColor = Emerald800),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Receipt,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ফি আদায়", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun StudentFormDialog(
    student: Student?,
    onDismiss: () -> Unit,
    onSave: (
        id: Long,
        studentId: String,
        name: String,
        father: String,
        mother: String,
        dob: String,
        phone: String,
        address: String,
        admissionDate: String,
        className: String,
        department: String,
        monthlyFee: Double,
        status: String,
        notes: String
    ) -> Unit
) {
    val isEdit = student != null
    var name by remember { mutableStateOf(student?.name ?: "") }
    var studentId by remember { mutableStateOf(student?.studentId ?: "") }
    var fatherName by remember { mutableStateOf(student?.fatherName ?: "") }
    var motherName by remember { mutableStateOf(student?.motherName ?: "") }
    var dob by remember { mutableStateOf(student?.dateOfBirth ?: "") }
    var phone by remember { mutableStateOf(student?.phone ?: "") }
    var address by remember { mutableStateOf(student?.address ?: "") }
    var admissionDate by remember {
        mutableStateOf(student?.admissionDate ?: SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()))
    }
    var className by remember { mutableStateOf(student?.className ?: "নূরানী ১ম") }
    var department by remember { mutableStateOf(student?.department ?: "হিফজ বিভাগ") }
    var monthlyFeeStr by remember { mutableStateOf(student?.monthlyFee?.let { if (it > 0) it.toInt().toString() else "1000" } ?: "1000") }
    var status by remember { mutableStateOf(student?.status ?: "সক্রিয়") }
    var notes by remember { mutableStateOf(student?.notes ?: "") }

    val classOptions = listOf("নূরানী ১ম", "নূরানী ২য়", "নাজেরা", "হিফজুল কুরআন", "কিতাব ১ম বর্ষ", "কিতাব ২য় বর্ষ", "দাওরায়ে হাদিস")
    val deptOptions = listOf("হিফজ বিভাগ", "নূরানী বিভাগ", "কিতাব বিভাগ", "জেনারেল")

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        text = if (isEdit) "ছাত্রের তথ্য পরিবর্তন" else "নতুন ছাত্র ভর্তি",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald800
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Divider(color = MaterialTheme.colorScheme.outlineVariant)
                }

                // Name & Custom ID
                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("ছাত্রের পূর্ণ নাম *") },
                        placeholder = { Text("মুহাম্মাদ আবদুল্লাহ") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }

                item {
                    OutlinedTextField(
                        value = studentId,
                        onValueChange = { studentId = it },
                        label = { Text("ছাত্র আইডি (ঐচ্ছিক)") },
                        placeholder = { Text("MU-2026-001") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }

                // Parents
                item {
                    OutlinedTextField(
                        value = fatherName,
                        onValueChange = { fatherName = it },
                        label = { Text("পিতার নাম") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }

                item {
                    OutlinedTextField(
                        value = motherName,
                        onValueChange = { motherName = it },
                        label = { Text("মাতার নাম") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }

                // Phone & Address
                item {
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("অভিভাবকের মোবাইল নম্বর *") },
                        placeholder = { Text("017XXXXXXXX") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }

                item {
                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text("ঠিকানা") },
                        placeholder = { Text("গ্রাম, থানা, জেলা") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }

                // Department & Class Dropdown
                item {
                    Text("বিভাগ ও শ্রেণি নির্বাচন:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ClassDropdown(
                            label = "বিভাগ",
                            options = deptOptions,
                            selected = department,
                            onSelect = { department = it },
                            modifier = Modifier.weight(1f)
                        )
                        ClassDropdown(
                            label = "শ্রেণি",
                            options = classOptions,
                            selected = className,
                            onSelect = { className = it },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Monthly Fee
                item {
                    OutlinedTextField(
                        value = monthlyFeeStr,
                        onValueChange = { monthlyFeeStr = it },
                        label = { Text("নির্ধারিত মাসিক ফি (টাকা) *") },
                        placeholder = { Text("1500") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }

                // Admission Date & Status
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = admissionDate,
                            onValueChange = { admissionDate = it },
                            label = { Text("ভর্তির তারিখ") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )
                        ClassDropdown(
                            label = "অবস্থা",
                            options = listOf("সক্রিয়", "নিষ্ক্রিয়"),
                            selected = status,
                            onSelect = { status = it },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Notes
                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("মন্তব্য / বিশেষ তথ্য") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        maxLines = 3
                    )
                }

                // Action Buttons
                item {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("বাতিল")
                        }

                        Button(
                            onClick = {
                                val fee = monthlyFeeStr.toDoubleOrNull() ?: 0.0
                                onSave(
                                    student?.id ?: 0L,
                                    studentId,
                                    name,
                                    fatherName,
                                    motherName,
                                    dob,
                                    phone,
                                    address,
                                    admissionDate,
                                    className,
                                    department,
                                    fee,
                                    status,
                                    notes
                                )
                            },
                            modifier = Modifier.weight(1.3f),
                            colors = ButtonDefaults.buttonColors(containerColor = Emerald800),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(if (isEdit) "আপডেট করুন" else "সংরক্ষণ করুন")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ClassDropdown(
    label: String,
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded },
        modifier = modifier
    ) {
        OutlinedTextField(
            value = selected,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = {
                        onSelect(option)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
fun StudentDetailsDialog(
    student: Student,
    payments: List<FeePayment>,
    onDismiss: () -> Unit,
    onCollectFee: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onViewReceipt: (FeePayment) -> Unit
) {
    val context = LocalContext.current

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Header
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = student.name,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Emerald800
                            )
                            Text(
                                text = "আইডি: ${student.studentId} • ${student.className}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        StatusBadge(status = student.status)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Divider(color = MaterialTheme.colorScheme.outlineVariant)
                }

                // Info Rows
                item {
                    DetailRow("পিতার নাম:", student.fatherName)
                    DetailRow("মাতার নাম:", student.motherName)
                    DetailRow("মোবাইল নম্বর:", student.phone)
                    DetailRow("ঠিকানা:", student.address)
                    DetailRow("বিভাগ:", student.department)
                    DetailRow("শ্রেণি:", student.className)
                    DetailRow("নির্ধারিত মাসিক ফি:", NumberFormatter.formatCurrency(student.monthlyFee))
                    DetailRow("ভর্তির তারিখ:", NumberFormatter.toBanglaDigits(student.admissionDate))
                    if (student.notes.isNotEmpty()) {
                        DetailRow("মন্তব্য:", student.notes)
                    }
                }

                // Fee Payment History Section
                item {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "ফি আদায়ের ইতিহাস (${NumberFormatter.toBanglaDigits(payments.size)}টি রসিদ)",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Emerald800
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }

                if (payments.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(14.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "এই ছাত্রের কোনো ফি আদায়ের রেকর্ড পাওয়া যায়নি।",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    items(payments) { payment ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onViewReceipt(payment) },
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = payment.monthYear,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "রসিদ: ${payment.receiptNo} • ${NumberFormatter.toBanglaDigits(payment.paymentDate)}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = NumberFormatter.formatCurrency(payment.paidAmount),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Emerald800
                                    )
                                    Text(
                                        text = if (payment.dueAmount > 0) "বকেয়া: ${NumberFormatter.formatCurrency(payment.dueAmount)}" else "পরিশোধিত",
                                        fontSize = 10.sp,
                                        color = if (payment.dueAmount > 0) ErrorRed else SuccessGreen
                                    )
                                }
                            }
                        }
                    }
                }

                // Action Buttons
                item {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onCollectFee,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Emerald800),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ফি আদায়")
                        }

                        OutlinedButton(
                            onClick = onEdit,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                        }

                        OutlinedButton(
                            onClick = onDelete,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("বন্ধ করুন")
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    if (value.isBlank()) return
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
