package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Islamic Emerald & Forest Green Palette
val Emerald900 = Color(0xFF042F24)
val Emerald800 = Color(0xFF064E3B)
val Emerald700 = Color(0xFF065F46)
val Emerald600 = Color(0xFF059669)
val Emerald500 = Color(0xFF10B981)
val Emerald100 = Color(0xFFD1FAE5)
val Emerald50 = Color(0xFFECFDF5)

// Luxury Islamic Gold & Amber Palette
val Gold900 = Color(0xFF78350F)
val Gold800 = Color(0xFF92400E)
val Gold700 = Color(0xFFB45309)
val Gold600 = Color(0xFFD97706)
val Gold500 = Color(0xFFF59E0B)
val Gold400 = Color(0xFFFBBF24)
val Gold300Light = Color(0xFFFDE68A)
val Gold100 = Color(0xFFFEF3C7)
val Gold50 = Color(0xFFFFFBEB)

// Neutral & Background Tones
val IvoryBackground = Color(0xFFF8FAF7)
val WarmSurface = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF0F4F1)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
val BorderLight = Color(0xFFE2E8F0)

// Dark Theme Colors
val DarkBackground = Color(0xFF0B1411)
val DarkSurface = Color(0xFF12201C)
val DarkSurfaceVariant = Color(0xFF1A2E28)
val TextPrimaryDark = Color(0xFFF1F5F9)
val TextSecondaryDark = Color(0xFF94A3B8)
val BorderDark = Color(0xFF233A33)

// Status & Semantic Colors
val SuccessGreen = Color(0xFF16A34A)
val ErrorRed = Color(0xFFDC2626)
val InfoBlue = Color(0xFF0284C7)
val WarningOrange = Color(0xFFEA580C)
