package com.example.util

import java.util.Calendar
import java.util.Date

object BanglaDateHelper {

    private val banglaMonths = arrayOf(
        "বৈশাখ", "জ্যৈষ্ঠ", "আষাঢ়", "শ্রাবণ", "ভাদ্র", "আশ্বিন",
        "কার্তিক", "অগ্রহায়ণ", "পৌষ", "মাঘ", "ফাল্গুন", "চৈত্র"
    )

    private val banglaDays = arrayOf(
        "রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার"
    )

    private val banglaSeasons = arrayOf(
        "গ্রীষ্ম", "বর্ষা", "শরৎ", "হেমন্ত", "শীত", "বসন্ত"
    )

    fun getBanglaDate(date: Date = Date()): BanglaDateResult {
        val cal = Calendar.getInstance()
        cal.time = date

        val year = cal.get(Calendar.YEAR)
        val month = cal.get(Calendar.MONTH) // 0-indexed (0 = Jan, 8 = Sep)
        val day = cal.get(Calendar.DAY_OF_MONTH)
        val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK) // 1 = Sunday

        val isLeapYear = (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)

        // Revised Bengali Calendar (Bangladesh Standard):
        // Boishakh to Ashwin (1-6): 31 days each
        // Kartik to Magh (7-10): 30 days each
        // Falgun (11): 29 days (30 days in leap year)
        // Choitra (12): 30 days

        var bYear = year - 593
        val bMonth: Int
        val bDay: Int

        // Approximate day of Gregorian year to Bengali calendar
        val dayOfYear = cal.get(Calendar.DAY_OF_YEAR)
        val pohelaBoishakhDayOfYear = if (isLeapYear) 105 else 104 // April 14 is day 104/105

        if (dayOfYear >= pohelaBoishakhDayOfYear) {
            val daysPassed = dayOfYear - pohelaBoishakhDayOfYear
            if (daysPassed < 31 * 6) { // Boishakh to Ashwin
                bMonth = daysPassed / 31
                bDay = (daysPassed % 31) + 1
            } else {
                val remaining = daysPassed - (31 * 6)
                if (remaining < 30 * 4) { // Kartik to Magh
                    bMonth = 6 + (remaining / 30)
                    bDay = (remaining % 30) + 1
                } else {
                    val falgunDays = if (isLeapYear) 30 else 29
                    val remFalgun = remaining - (30 * 4)
                    if (remFalgun < falgunDays) {
                        bMonth = 10 // Falgun
                        bDay = remFalgun + 1
                    } else {
                        bMonth = 11 // Choitra
                        bDay = (remFalgun - falgunDays) + 1
                    }
                }
            }
        } else {
            // Before April 14 (part of previous Bengali year)
            bYear -= 1
            val prevYearLeap = ((year - 1) % 4 == 0 && (year - 1) % 100 != 0) || ((year - 1) % 400 == 0)
            val falgunDays = if (prevYearLeap) 30 else 29
            // Days since April 14 of previous year
            val prevPohelaBoishakhDay = if (prevYearLeap) 105 else 104
            val totalPrevDays = if (prevYearLeap) 366 else 365
            val daysPassed = (totalPrevDays - prevPohelaBoishakhDay) + dayOfYear

            val remKartikToMagh = daysPassed - (31 * 6)
            if (remKartikToMagh < 30 * 4) {
                bMonth = 6 + (remKartikToMagh / 30)
                bDay = (remKartikToMagh % 30) + 1
            } else {
                val remFalgun = remKartikToMagh - (30 * 4)
                if (remFalgun < falgunDays) {
                    bMonth = 10
                    bDay = remFalgun + 1
                } else {
                    bMonth = 11
                    bDay = (remFalgun - falgunDays) + 1
                }
            }
        }

        val clampedMonth = bMonth.coerceIn(0, 11)
        val monthName = banglaMonths[clampedMonth]
        val dayName = banglaDays[dayOfWeek - 1]
        val seasonName = banglaSeasons[clampedMonth / 2]

        val dayBn = NumberFormatter.toBanglaDigits(bDay)
        val yearBn = NumberFormatter.toBanglaDigits(bYear)

        return BanglaDateResult(
            day = bDay,
            monthIndex = clampedMonth,
            monthName = monthName,
            year = bYear,
            dayName = dayName,
            seasonName = seasonName,
            formattedString = "$dayBn $monthName $yearBn বঙ্গাব্দ"
        )
    }
}

data class BanglaDateResult(
    val day: Int,
    val monthIndex: Int,
    val monthName: String,
    val year: Int,
    val dayName: String,
    val seasonName: String,
    val formattedString: String
)
