package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.*

data class PrayerSchedule(
    val fajr: String,
    val sunrise: String,
    val dhuhr: String,
    val asr: String,
    val maghrib: String,
    val isha: String,
    val fajrTime: Long,
    val sunriseTime: Long,
    val dhuhrTime: Long,
    val asrTime: Long,
    val maghribTime: Long,
    val ishaTime: Long,
    val currentPrayerName: String,
    val nextPrayerName: String,
    val remainingMillis: Long,
    val formattedCountdown: String
)

data class PrayerItem(
    val id: String,
    val nameBn: String,
    val nameEn: String,
    val timeFormatted: String,
    val timestamp: Long,
    val isCurrent: Boolean,
    val isNext: Boolean
)

object PrayerTimeCalculator {

    fun calculatePrayerTimes(
        latitude: Double = 23.8103,
        longitude: Double = 90.4125,
        date: Date = Date(),
        isHanafi: Boolean = true,
        fajrAngle: Double = 18.0,
        ishaAngle: Double = 18.0
    ): PrayerSchedule {
        val cal = Calendar.getInstance()
        cal.time = date

        val year = cal.get(Calendar.YEAR)
        val month = cal.get(Calendar.MONTH) + 1
        val day = cal.get(Calendar.DAY_OF_MONTH)

        // Julian Date
        val julianDay = getJulianDay(year, month, day)
        val d = julianDay - 2451545.0

        // Sun's coordinates
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * sin(degToRad(g)) + 0.020 * sin(degToRad(2 * g)))

        val e = 23.439 - 0.00000036 * d
        val ra = fixAngle(radToDeg(atan2(cos(degToRad(e)) * sin(degToRad(l)), cos(degToRad(l))))) / 15.0
        val declination = radToDeg(asin(sin(degToRad(e)) * sin(degToRad(l))))
        val eqOfTime = q / 15.0 - ra

        // Timezone in hours for Bangladesh is UTC+6
        val timeZone = 6.0

        // Solar Noon (Dhuhr)
        val noon = fixHour(12 + timeZone - longitude / 15.0 - eqOfTime)

        // Sun angle for Fajr & Isha
        val fajrDiff = sunAngleTime(fajrAngle, latitude, declination)
        val ishaDiff = sunAngleTime(ishaAngle, latitude, declination)
        val sunriseDiff = sunAngleTime(0.8333, latitude, declination)

        val fajrDec = noon - fajrDiff
        val sunriseDec = noon - sunriseDiff
        val dhuhrDec = noon + (2.0 / 60.0) // 2 min precaution after zawaal
        val maghribDec = noon + sunriseDiff + (3.0 / 60.0) // 3 min precaution
        val ishaDec = noon + ishaDiff

        // Asr Calculation
        val asrFactor = if (isHanafi) 2.0 else 1.0
        val asrAngle = -radToDeg(atan(1.0 / (asrFactor + tan(degToRad(abs(latitude - declination))))))
        val asrDiff = sunAngleTime(-asrAngle, latitude, declination)
        val asrDec = noon + asrDiff

        // Convert decimal hours to Timestamps for today
        val fajrTime = decimalToTimestamp(cal, fajrDec)
        val sunriseTime = decimalToTimestamp(cal, sunriseDiffTime = false, dec = sunriseDec)
        val dhuhrTime = decimalToTimestamp(cal, dhuhrDec)
        val asrTime = decimalToTimestamp(cal, asrDec)
        val maghribTime = decimalToTimestamp(cal, maghribDec)
        val ishaTime = decimalToTimestamp(cal, ishaDec)

        val now = System.currentTimeMillis()

        // Determine current & next prayer
        val (currentName, nextName, remainingMs) = determinePrayerStatus(
            now, fajrTime, sunriseTime, dhuhrTime, asrTime, maghribTime, ishaTime, cal, fajrDec
        )

        val countdownStr = formatCountdown(remainingMs)

        return PrayerSchedule(
            fajr = formatTime(fajrTime),
            sunrise = formatTime(sunriseTime),
            dhuhr = formatTime(dhuhrTime),
            asr = formatTime(asrTime),
            maghrib = formatTime(maghribTime),
            isha = formatTime(ishaTime),
            fajrTime = fajrTime,
            sunriseTime = sunriseTime,
            dhuhrTime = dhuhrTime,
            asrTime = asrTime,
            maghribTime = maghribTime,
            ishaTime = ishaTime,
            currentPrayerName = currentName,
            nextPrayerName = nextName,
            remainingMillis = remainingMs,
            formattedCountdown = countdownStr
        )
    }

    private fun determinePrayerStatus(
        now: Long,
        fajr: Long,
        sunrise: Long,
        dhuhr: Long,
        asr: Long,
        maghrib: Long,
        isha: Long,
        cal: Calendar,
        fajrDec: Double
    ): Triple<String, String, Long> {
        return when {
            now < fajr -> {
                Triple("তাহাজ্জুদ / সাহরি", "ফজর", fajr - now)
            }
            now in fajr..<sunrise -> {
                Triple("ফজর", "সূর্যোদয়", sunrise - now)
            }
            now in sunrise..<dhuhr -> {
                Triple("ইশরাক / চাশত", "যোহর", dhuhr - now)
            }
            now in dhuhr..<asr -> {
                Triple("যোহর", "আসর", asr - now)
            }
            now in asr..<maghrib -> {
                Triple("আসর", "মাগরিব", maghrib - now)
            }
            now in maghrib..<isha -> {
                Triple("মাগরিব", "ইশা", isha - now)
            }
            else -> {
                // After Isha, next prayer is Tomorrow's Fajr
                val nextCal = cal.clone() as Calendar
                nextCal.add(Calendar.DAY_OF_MONTH, 1)
                val nextFajr = decimalToTimestamp(nextCal, fajrDec)
                val diff = (nextFajr - now).coerceAtLeast(0L)
                Triple("ইশা", "ফজর", diff)
            }
        }
    }

    private fun formatCountdown(ms: Long): String {
        if (ms <= 0) return "সময় হয়েছে"
        val seconds = (ms / 1000) % 60
        val minutes = (ms / (1000 * 60)) % 60
        val hours = (ms / (1000 * 60 * 60))

        val hBn = NumberFormatter.toBanglaDigits(hours)
        val mBn = NumberFormatter.toBanglaDigits(String.format(Locale.ENGLISH, "%02d", minutes))
        val sBn = NumberFormatter.toBanglaDigits(String.format(Locale.ENGLISH, "%02d", seconds))

        return if (hours > 0) {
            "$hBn ঘণ্টা $mBn মি. $sBn সে."
        } else {
            "$mBn মিনিট $sBn সেকেন্ড"
        }
    }

    private fun sunAngleTime(angle: Double, lat: Double, dec: Double): Double {
        val cosH = (sin(degToRad(-angle)) - sin(degToRad(lat)) * sin(degToRad(dec))) /
                (cos(degToRad(lat)) * cos(degToRad(dec)))
        return if (cosH < -1.0) 0.0 else if (cosH > 1.0) 0.0 else radToDeg(acos(cosH)) / 15.0
    }

    private fun decimalToTimestamp(cal: Calendar, dec: Double, sunriseDiffTime: Boolean = false): Long {
        val c = cal.clone() as Calendar
        var hour = dec.toInt()
        var minutes = ((dec - hour) * 60.0).toInt()
        val seconds = ((((dec - hour) * 60.0) - minutes) * 60.0).toInt()

        if (hour >= 24) hour -= 24
        if (hour < 0) hour += 24

        c.set(Calendar.HOUR_OF_DAY, hour)
        c.set(Calendar.MINUTE, minutes)
        c.set(Calendar.SECOND, seconds)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    private fun formatTime(millis: Long): String {
        val sdf = SimpleDateFormat("hh:mm a", Locale.ENGLISH)
        val timeStr = sdf.format(Date(millis))
        return NumberFormatter.toBanglaDigits(timeStr)
    }

    private fun getJulianDay(year: Int, month: Int, day: Int): Double {
        var y = year
        var m = month
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    private fun fixAngle(a: Double): Double {
        var res = a - 360.0 * floor(a / 360.0)
        if (res < 0) res += 360.0
        return res
    }

    private fun fixHour(h: Double): Double {
        var res = h - 24.0 * floor(h / 24.0)
        if (res < 0) res += 24.0
        return res
    }

    private fun degToRad(d: Double): Double = d * PI / 180.0
    private fun radToDeg(r: Double): Double = r * 180.0 / PI
}
