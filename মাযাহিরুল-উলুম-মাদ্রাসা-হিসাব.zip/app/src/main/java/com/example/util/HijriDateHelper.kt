package com.example.util

import java.util.Calendar
import java.util.Date
import kotlin.math.floor

object HijriDateHelper {

    private val hijriMonthsBn = arrayOf(
        "মুহাররম", "সফর", "রবিউল আউয়াল", "রবিউস সানি",
        "জমাদিউল আউয়াল", "জমাদিউস সানি", "রজব", "শাবান",
        "রমজান", "শাওয়াল", "জিলকদ", "জিলহজ্ব"
    )

    fun getHijriDate(date: Date = Date(), offsetDays: Int = 0): HijriDateResult {
        val cal = Calendar.getInstance()
        cal.time = date
        cal.add(Calendar.DAY_OF_MONTH, offsetDays)

        val y = cal.get(Calendar.YEAR)
        val m = cal.get(Calendar.MONTH) + 1 // 1-12
        val d = cal.get(Calendar.DAY_OF_MONTH)

        // Convert Gregorian to Julian Day Number (JDN)
        val a = floor((14 - m) / 12.0).toInt()
        val yPrime = y + 4800 - a
        val mPrime = m + 12 * a - 3

        val jdn = d + floor((153 * mPrime + 2) / 5.0).toInt() +
                365 * yPrime + floor(yPrime / 4.0).toInt() -
                floor(yPrime / 100.0).toInt() + floor(yPrime / 400.0).toInt() - 32045

        // Convert JDN to Hijri Date (Kuwaiti / Tabular Islamic algorithm)
        val l = jdn - 1948440 + 10632
        val n = floor((l - 1) / 10631.0).toInt()
        val lPrime = l - 10631 * n + 354
        val j = (floor((10985 - lPrime) / 5316.0) * floor((50 * lPrime) / 17719.0) +
                floor(lPrime / 5670.0) * floor((43 * lPrime) / 15238.0)).toInt()
        val lDoublePrime = lPrime - floor((30 - j) / 15.0).toInt() * floor((17719 * j) / 50.0).toInt() -
                floor(j / 16.0).toInt() * floor((15238 * j) / 43.0).toInt() + 29

        val hijriMonth = floor((24 * lDoublePrime) / 709.0).toInt()
        val hijriDay = lDoublePrime - floor((709 * hijriMonth) / 24.0).toInt()
        val hijriYear = 30 * n + j - 30

        val clampedMonth = (hijriMonth - 1).coerceIn(0, 11)
        val clampedDay = hijriDay.coerceIn(1, 30)

        val monthName = hijriMonthsBn[clampedMonth]
        val dayBn = NumberFormatter.toBanglaDigits(clampedDay)
        val yearBn = NumberFormatter.toBanglaDigits(hijriYear)

        return HijriDateResult(
            day = clampedDay,
            monthIndex = clampedMonth,
            monthName = monthName,
            year = hijriYear,
            offsetApplied = offsetDays,
            formattedString = "$dayBn $monthName $yearBn হিজরি"
        )
    }
}

data class HijriDateResult(
    val day: Int,
    val monthIndex: Int,
    val monthName: String,
    val year: Int,
    val offsetApplied: Int,
    val formattedString: String
)
