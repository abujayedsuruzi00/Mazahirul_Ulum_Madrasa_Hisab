package com.example.util

import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object NumberFormatter {

    private val banglaDigits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')

    private val banglaMonthNames = arrayOf(
        "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
        "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
    )

    fun toBanglaDigits(number: Any?): String {
        if (number == null) return "০"
        val engStr = number.toString()
        val sb = StringBuilder()
        for (ch in engStr) {
            if (ch in '0'..'9') {
                sb.append(banglaDigits[ch - '0'])
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun formatCurrency(amount: Double): String {
        val formatter = DecimalFormat("#,##,##0.##")
        val formatted = formatter.format(amount)
        return "৳ " + toBanglaDigits(formatted)
    }

    fun formatTimeBn(date: Date = Date()): String {
        val sdf = SimpleDateFormat("hh:mm:ss a", Locale.ENGLISH)
        val formatted = sdf.format(date)
            .replace("AM", "সকাল")
            .replace("PM", "বিকাল/রাত")
        return toBanglaDigits(formatted)
    }

    fun formatTimeShortBn(date: Date = Date()): String {
        val sdf = SimpleDateFormat("hh:mm a", Locale.ENGLISH)
        val formatted = sdf.format(date)
            .replace("AM", "AM")
            .replace("PM", "PM")
        return toBanglaDigits(formatted)
    }

    fun getMonthNameBn(monthIndex: Int): String {
        val idx = if (monthIndex in 0..11) monthIndex else (monthIndex % 12 + 12) % 12
        return banglaMonthNames[idx]
    }
}
