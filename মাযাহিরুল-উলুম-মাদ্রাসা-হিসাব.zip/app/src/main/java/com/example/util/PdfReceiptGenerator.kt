package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.local.entity.FeePayment
import com.example.data.local.entity.MadrasaProfile
import java.io.File
import java.io.FileOutputStream

object PdfReceiptGenerator {

    fun generateAndShareReceipt(
        context: Context,
        payment: FeePayment,
        profile: MadrasaProfile
    ): Uri? {
        try {
            val pdfDoc = PdfDocument()
            val pageWidth = 595 // A4 standard width (pt)
            val pageHeight = 842 // A4 standard height (pt)
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
            val page = pdfDoc.startPage(pageInfo)
            val canvas = page.canvas

            // Paints
            val bgPaint = Paint().apply {
                color = Color.parseColor("#FDFDFD")
                style = Paint.Style.FILL
            }
            canvas.drawRect(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), bgPaint)

            // Header Emerald Banner
            val headerPaint = Paint().apply {
                color = Color.parseColor("#064E3B") // Deep Emerald
                style = Paint.Style.FILL
            }
            canvas.drawRect(0f, 0f, pageWidth.toFloat(), 130f, headerPaint)

            // Gold Stripe
            val goldPaint = Paint().apply {
                color = Color.parseColor("#D97706") // Rich Gold
                style = Paint.Style.FILL
            }
            canvas.drawRect(0f, 130f, pageWidth.toFloat(), 136f, goldPaint)

            // Outer Border
            val borderPaint = Paint().apply {
                color = Color.parseColor("#064E3B")
                style = Paint.Style.STROKE
                strokeWidth = 3f
            }
            canvas.drawRect(20f, 20f, pageWidth - 20f, pageHeight - 20f, borderPaint)

            val innerBorderPaint = Paint().apply {
                color = Color.parseColor("#E5E7EB")
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }
            canvas.drawRect(26f, 26f, pageWidth - 26f, pageHeight - 26f, innerBorderPaint)

            // Header Titles
            val bismillahPaint = Paint().apply {
                color = Color.parseColor("#FEF3C7")
                textSize = 14f
                typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", pageWidth / 2f, 40f, bismillahPaint)

            val titlePaint = Paint().apply {
                color = Color.WHITE
                textSize = 22f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(profile.nameBn, pageWidth / 2f, 72f, titlePaint)

            val subTitlePaint = Paint().apply {
                color = Color.parseColor("#D1FAE5")
                textSize = 12f
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("${profile.address} | মোবাইল: ${profile.phone}", pageWidth / 2f, 96f, subTitlePaint)

            val engNamePaint = Paint().apply {
                color = Color.parseColor("#93C5FD")
                textSize = 10f
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(profile.nameEn, pageWidth / 2f, 114f, engNamePaint)

            // Receipt Title Badge
            val badgeBgPaint = Paint().apply {
                color = Color.parseColor("#ECFDF5")
                style = Paint.Style.FILL
            }
            val badgeStrokePaint = Paint().apply {
                color = Color.parseColor("#059669")
                style = Paint.Style.STROKE
                strokeWidth = 1.5f
            }
            val badgeRect = RectF(pageWidth / 2f - 110f, 150f, pageWidth / 2f + 110f, 185f)
            canvas.drawRoundRect(badgeRect, 10f, 10f, badgeBgPaint)
            canvas.drawRoundRect(badgeRect, 10f, 10f, badgeStrokePaint)

            val badgeTextPaint = Paint().apply {
                color = Color.parseColor("#064E3B")
                textSize = 15f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("মাসিক ফি আদায়ের মানি রসিদ", pageWidth / 2f, 173f, badgeTextPaint)

            // Metadata Row (Receipt No & Date)
            val metaKeyPaint = Paint().apply {
                color = Color.parseColor("#475569")
                textSize = 12f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val metaValPaint = Paint().apply {
                color = Color.parseColor("#0F172A")
                textSize = 12f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            }

            var startY = 220f
            canvas.drawText("রসিদ নং (Receipt No):", 45f, startY, metaKeyPaint)
            canvas.drawText(payment.receiptNo, 195f, startY, metaValPaint)

            canvas.drawText("তারিখ (Date):", 380f, startY, metaKeyPaint)
            canvas.drawText(NumberFormatter.toBanglaDigits(payment.paymentDate), 465f, startY, metaValPaint)

            // Student Info Card Box
            startY += 25f
            val cardPaint = Paint().apply {
                color = Color.parseColor("#F8FAFC")
                style = Paint.Style.FILL
            }
            val cardBorder = Paint().apply {
                color = Color.parseColor("#CBD5E1")
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }
            canvas.drawRoundRect(RectF(45f, startY, pageWidth - 45f, startY + 95f), 8f, 8f, cardPaint)
            canvas.drawRoundRect(RectF(45f, startY, pageWidth - 45f, startY + 95f), 8f, 8f, cardBorder)

            val textY = startY + 25f
            canvas.drawText("ছাত্রের নাম:", 60f, textY, metaKeyPaint)
            canvas.drawText(payment.studentName, 145f, textY, metaValPaint)

            canvas.drawText("ছাত্র আইডি:", 380f, textY, metaKeyPaint)
            canvas.drawText(payment.studentCustomId, 455f, textY, metaValPaint)

            val textY2 = startY + 52f
            canvas.drawText("শ্রেণি/বিভাগ:", 60f, textY2, metaKeyPaint)
            canvas.drawText(if (payment.className.isNotEmpty()) payment.className else "সাধারণ", 145f, textY2, metaValPaint)

            canvas.drawText("আদায়ের মাস:", 380f, textY2, metaKeyPaint)
            canvas.drawText(payment.monthYear, 455f, textY2, metaValPaint)

            val textY3 = startY + 78f
            canvas.drawText("পরিশোধের মাধ্যম:", 60f, textY3, metaKeyPaint)
            canvas.drawText(payment.paymentMethod, 175f, textY3, metaValPaint)

            // Table Header for Fee Details
            val tableY = startY + 120f
            val thBg = Paint().apply {
                color = Color.parseColor("#065F46")
                style = Paint.Style.FILL
            }
            canvas.drawRect(45f, tableY, pageWidth - 45f, tableY + 30f, thBg)

            val thTextPaint = Paint().apply {
                color = Color.WHITE
                textSize = 12f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            canvas.drawText("ক্র.নং", 60f, tableY + 20f, thTextPaint)
            canvas.drawText("বিবরণ / ফিসের খাত", 120f, tableY + 20f, thTextPaint)
            canvas.drawText("নির্ধারিত ফি", 320f, tableY + 20f, thTextPaint)
            canvas.drawText("আদায়কৃত টাকা", 440f, tableY + 20f, thTextPaint)

            // Table Row 1
            val trY = tableY + 30f
            val trPaint = Paint().apply {
                color = Color.parseColor("#E2E8F0")
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }
            canvas.drawRect(45f, trY, pageWidth - 45f, trY + 45f, trPaint)

            val tdTextPaint = Paint().apply {
                color = Color.parseColor("#1E293B")
                textSize = 13f
            }
            canvas.drawText("১", 65f, trY + 28f, tdTextPaint)
            canvas.drawText("মাসিক টিউশন ও বোর্ডিং ফি (${payment.monthYear})", 120f, trY + 28f, tdTextPaint)
            canvas.drawText(NumberFormatter.formatCurrency(payment.feeAmount), 320f, trY + 28f, tdTextPaint)
            canvas.drawText(NumberFormatter.formatCurrency(payment.paidAmount), 440f, trY + 28f, tdTextPaint)

            // Summary Breakdown Box
            val sumY = trY + 70f
            val sumBg = Paint().apply {
                color = Color.parseColor("#F1F5F9")
                style = Paint.Style.FILL
            }
            canvas.drawRoundRect(RectF(280f, sumY, pageWidth - 45f, sumY + 95f), 8f, 8f, sumBg)
            canvas.drawRoundRect(RectF(280f, sumY, pageWidth - 45f, sumY + 95f), 8f, 8f, cardBorder)

            val sumKeyPaint = Paint().apply {
                color = Color.parseColor("#334155")
                textSize = 13f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val sumValPaint = Paint().apply {
                color = Color.parseColor("#0F172A")
                textSize = 13f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }

            canvas.drawText("মোট ধার্যকৃত ফি:", 300f, sumY + 26f, sumKeyPaint)
            canvas.drawText(NumberFormatter.formatCurrency(payment.feeAmount), 450f, sumY + 26f, sumValPaint)

            val paidValPaint = Paint().apply {
                color = Color.parseColor("#16A34A") // Green
                textSize = 13f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            canvas.drawText("মোট আদায়:", 300f, sumY + 54f, sumKeyPaint)
            canvas.drawText(NumberFormatter.formatCurrency(payment.paidAmount), 450f, sumY + 54f, paidValPaint)

            val dueValPaint = Paint().apply {
                color = if (payment.dueAmount > 0) Color.parseColor("#DC2626") else Color.parseColor("#059669")
                textSize = 13f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            canvas.drawText("অবশিষ্ট বকেয়া:", 300f, sumY + 82f, sumKeyPaint)
            canvas.drawText(NumberFormatter.formatCurrency(payment.dueAmount), 450f, sumY + 82f, dueValPaint)

            // Status Badge
            val statusColor = if (payment.dueAmount <= 0) "#059669" else if (payment.paidAmount > 0) "#D97706" else "#DC2626"
            val statusText = if (payment.dueAmount <= 0) "পরিশোধিত (PAID)" else if (payment.paidAmount > 0) "আংশিক আদায় (PARTIAL)" else "বকেয়া (DUE)"

            val statusPaint = Paint().apply {
                color = Color.parseColor(statusColor)
                textSize = 14f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            canvas.drawText("অবস্থা: $statusText", 60f, sumY + 35f, statusPaint)

            if (payment.notes.isNotEmpty()) {
                val notePaint = Paint().apply {
                    color = Color.parseColor("#64748B")
                    textSize = 11f
                }
                canvas.drawText("মন্তব্য: ${payment.notes}", 60f, sumY + 65f, notePaint)
            }

            // Signatures
            val sigY = pageHeight - 110f
            val sigLine = Paint().apply {
                color = Color.parseColor("#94A3B8")
                strokeWidth = 1f
            }
            canvas.drawLine(60f, sigY, 200f, sigY, sigLine)
            canvas.drawLine(pageWidth - 200f, sigY, pageWidth - 60f, sigY, sigLine)

            val sigText = Paint().apply {
                color = Color.parseColor("#475569")
                textSize = 11f
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("গ্রহীতার স্বাক্ষর", 130f, sigY + 18f, sigText)
            canvas.drawText("মুহতামিম / হিসাবরক্ষক", pageWidth - 130f, sigY + 18f, sigText)

            // Footer Note
            val footerPaint = Paint().apply {
                color = Color.parseColor("#94A3B8")
                textSize = 10f
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("মাযাহিরুল উলুম মাদ্রাসা হিসাব ম্যানেজমেন্ট সিস্টেম দ্বারা প্রস্তুতকৃত।", pageWidth / 2f, pageHeight - 40f, footerPaint)

            pdfDoc.finishPage(page)

            // Save PDF to cache/receipts/
            val receiptsDir = File(context.cacheDir, "receipts")
            if (!receiptsDir.exists()) {
                receiptsDir.mkdirs()
            }
            val fileName = "Receipt_${payment.receiptNo}.pdf"
            val file = File(receiptsDir, fileName)
            val fos = FileOutputStream(file)
            pdfDoc.writeTo(fos)
            fos.close()
            pdfDoc.close()

            // Generate content URI with FileProvider
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            // Launch share sheet
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "মানি রসিদ - ${payment.studentName} (${payment.receiptNo})")
                putExtra(Intent.EXTRA_TEXT, "মাযাহিরুল উলুম মাদ্রাসা - মানি রসিদ নং: ${payment.receiptNo}\nছাত্র: ${payment.studentName}\nমাস: ${payment.monthYear}\nআদায়কৃত: ${NumberFormatter.formatCurrency(payment.paidAmount)}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(shareIntent, "রসিদ শেয়ার বা প্রিন্ট করুন")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)

            return uri
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "রসিদ তৈরিতে ত্রুটি: ${e.message}", Toast.LENGTH_LONG).show()
            return null
        }
    }
}
