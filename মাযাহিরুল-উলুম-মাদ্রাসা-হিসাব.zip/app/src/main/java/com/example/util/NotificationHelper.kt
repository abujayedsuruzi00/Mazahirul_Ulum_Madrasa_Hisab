package com.example.util

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity

object NotificationHelper {
    const val PRAYER_CHANNEL_ID = "madrasa_prayer_channel"
    const val MANAGEMENT_CHANNEL_ID = "madrasa_management_channel"

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // Prayer channel
            val prayerChannel = NotificationChannel(
                PRAYER_CHANNEL_ID,
                "নামাজের ওয়াক্ত নোটিফিকেশন",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "প্রতিদিনের পাঁচ ওয়াক্ত নামাজের সময় নোটিফিকেশন"
                enableVibration(true)
            }

            // Management channel
            val mgmtChannel = NotificationChannel(
                MANAGEMENT_CHANNEL_ID,
                "মাদ্রাসা হিসাব ও রিমাইন্ডার",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "ছাত্র বেতন, শিক্ষক বেতন এবং ব্যাকআপ সংক্রান্ত নোটিফিকেশন"
                enableVibration(true)
            }

            notificationManager.createNotificationChannel(prayerChannel)
            notificationManager.createNotificationChannel(mgmtChannel)
        }
    }

    fun showNotification(
        context: Context,
        title: String,
        message: String,
        channelId: String = MANAGEMENT_CHANNEL_ID,
        targetTab: String = "HOME",
        notificationId: Int = System.currentTimeMillis().toInt()
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                return
            }
        }

        createNotificationChannels(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("NAVIGATE_TAB", targetTab)
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(if (channelId == PRAYER_CHANNEL_ID) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(notificationId, builder.build())
    }

    fun schedulePrayerReminder(
        context: Context,
        prayerName: String,
        triggerTimeMillis: Long,
        requestCode: Int
    ) {
        if (triggerTimeMillis <= System.currentTimeMillis()) return

        val intent = Intent(context, MadrasaNotificationReceiver::class.java).apply {
            putExtra("EXTRA_TITLE", "নামাজের ওয়াক্ত হয়েছে: $prayerName")
            putExtra("EXTRA_MESSAGE", "মাযাহিরুল উলুম মাদ্রাসা - $prayerName নামাজের ওয়াক্ত শুরু হয়েছে। জামাতের প্রস্তুতি নিন।")
            putExtra("EXTRA_CHANNEL_ID", PRAYER_CHANNEL_ID)
            putExtra("EXTRA_TARGET_TAB", "HOME")
            putExtra("EXTRA_NOTIFICATION_ID", requestCode)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
        try {
            alarmManager?.set(
                AlarmManager.RTC_WAKEUP,
                triggerTimeMillis,
                pendingIntent
            )
        } catch (e: SecurityException) {
            // In case exact alarm permission is restricted
            alarmManager?.set(
                AlarmManager.RTC,
                triggerTimeMillis,
                pendingIntent
            )
        }
    }
}
