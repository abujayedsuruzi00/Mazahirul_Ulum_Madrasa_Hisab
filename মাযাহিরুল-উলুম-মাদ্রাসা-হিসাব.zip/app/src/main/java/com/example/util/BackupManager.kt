package com.example.util

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.example.data.local.AppDatabase
import com.example.data.local.entity.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class BackupManager(
    private val context: Context,
    private val database: AppDatabase
) {

    suspend fun createBackupJson(): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
        root.put("version", 2)
        root.put("appName", "Mazahirul Ulum Madrasa Hisab")
        root.put("exportedAt", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()))
        root.put("timestamp", System.currentTimeMillis())

        // 1. Madrasa Profile
        val profile = database.madrasaProfileDao().getProfileDirect()
        if (profile != null) {
            val pObj = JSONObject().apply {
                put("nameBn", profile.nameBn)
                put("nameEn", profile.nameEn)
                put("address", profile.address)
                put("phone", profile.phone)
                put("email", profile.email)
                put("principalName", profile.principalName)
                put("establishedYear", profile.establishedYear)
                put("slogan", profile.slogan)
                put("hijriOffsetDays", profile.hijriOffsetDays)
                put("selectedDistrict", profile.selectedDistrict)
                put("latitude", profile.latitude)
                put("longitude", profile.longitude)
                put("asrMadhhab", profile.asrMadhhab)
                put("themeMode", profile.themeMode)
                put("appLanguage", profile.appLanguage)
            }
            root.put("madrasaProfile", pObj)
        }

        // 2. Students
        val students = database.studentDao().getAllStudentsDirect()
        val stArray = JSONArray()
        students.forEach { s ->
            stArray.put(JSONObject().apply {
                put("id", s.id)
                put("studentId", s.studentId)
                put("name", s.name)
                put("fatherName", s.fatherName)
                put("motherName", s.motherName)
                put("dateOfBirth", s.dateOfBirth)
                put("phone", s.phone)
                put("address", s.address)
                put("admissionDate", s.admissionDate)
                put("className", s.className)
                put("department", s.department)
                put("monthlyFee", s.monthlyFee)
                put("status", s.status)
                put("notes", s.notes)
                put("createdAt", s.createdAt)
            })
        }
        root.put("students", stArray)

        // 3. Teachers & Staff
        val teachers = database.teacherStaffDao().getAllTeachersDirect()
        val teacherArray = JSONArray()
        teachers.forEach { t ->
            teacherArray.put(JSONObject().apply {
                put("id", t.id)
                put("name", t.name)
                put("employeeId", t.employeeId)
                put("phone", t.phone)
                put("address", t.address)
                put("joiningDate", t.joiningDate)
                put("designation", t.designation)
                put("salary", t.salary)
                put("status", t.status)
                put("notes", t.notes)
                put("createdAt", t.createdAt)
            })
        }
        root.put("teachers", teacherArray)

        // 4. Fee Payments
        val fees = database.feePaymentDao().getAllPaymentsDirect()
        val feeArray = JSONArray()
        fees.forEach { f ->
            feeArray.put(JSONObject().apply {
                put("id", f.id)
                put("receiptNo", f.receiptNo)
                put("studentDbId", f.studentDbId)
                put("studentCustomId", f.studentCustomId)
                put("studentName", f.studentName)
                put("className", f.className)
                put("monthYear", f.monthYear)
                put("feeAmount", f.feeAmount)
                put("paidAmount", f.paidAmount)
                put("dueAmount", f.dueAmount)
                put("paymentDate", f.paymentDate)
                put("paymentMethod", f.paymentMethod)
                put("notes", f.notes)
                put("collectedBy", f.collectedBy)
                put("timestamp", f.timestamp)
            })
        }
        root.put("feePayments", feeArray)

        // 5. Salary Payments
        val salaries = database.salaryPaymentDao().getAllSalaryPaymentsDirect()
        val salaryArray = JSONArray()
        salaries.forEach { sp ->
            salaryArray.put(JSONObject().apply {
                put("id", sp.id)
                put("voucherNo", sp.voucherNo)
                put("teacherStaffId", sp.teacherStaffId)
                put("teacherName", sp.teacherName)
                put("employeeId", sp.employeeId)
                put("designation", sp.designation)
                put("monthYear", sp.monthYear)
                put("salaryAmount", sp.salaryAmount)
                put("bonus", sp.bonus)
                put("deduction", sp.deduction)
                put("netPayable", sp.netPayable)
                put("paidAmount", sp.paidAmount)
                put("dueAmount", sp.dueAmount)
                put("paymentDate", sp.paymentDate)
                put("paymentMethod", sp.paymentMethod)
                put("notes", sp.notes)
                put("timestamp", sp.timestamp)
            })
        }
        root.put("salaryPayments", salaryArray)

        // 6. Transactions
        val txs = database.transactionDao().getAllTransactionsDirect()
        val txArray = JSONArray()
        txs.forEach { t ->
            txArray.put(JSONObject().apply {
                put("id", t.id)
                put("type", t.type)
                put("title", t.title)
                put("category", t.category)
                put("amount", t.amount)
                put("date", t.date)
                put("paymentMethod", t.paymentMethod)
                put("voucherNo", t.voucherNo)
                put("description", t.description)
                put("payeeOrSource", t.payeeOrSource)
                put("reference", t.reference)
                put("notes", t.notes)
                put("timestamp", t.timestamp)
            })
        }
        root.put("transactions", txArray)

        // 7. Loans
        val loans = database.loanDao().getAllLoansDirect()
        val loanArray = JSONArray()
        loans.forEach { l ->
            loanArray.put(JSONObject().apply {
                put("id", l.id)
                put("loanType", l.loanType)
                put("personName", l.personName)
                put("phone", l.phone)
                put("totalAmount", l.totalAmount)
                put("paidAmount", l.paidAmount)
                put("remainingAmount", l.remainingAmount)
                put("date", l.date)
                put("purpose", l.purpose)
                put("status", l.status)
                put("notes", l.notes)
                put("timestamp", l.timestamp)
            })
        }
        root.put("loans", loanArray)

        // 8. Loan Repayments
        val reps = database.loanDao().getAllRepaymentsDirect()
        val repArray = JSONArray()
        reps.forEach { r ->
            repArray.put(JSONObject().apply {
                put("id", r.id)
                put("loanId", r.loanId)
                put("amount", r.amount)
                put("date", r.date)
                put("paymentMethod", r.paymentMethod)
                put("notes", r.notes)
                put("timestamp", r.timestamp)
            })
        }
        root.put("loanRepayments", repArray)

        // 9. Attendance
        val atts = database.attendanceDao().getAllAttendanceDirect()
        val attArray = JSONArray()
        atts.forEach { a ->
            attArray.put(JSONObject().apply {
                put("id", a.id)
                put("studentDbId", a.studentDbId)
                put("date", a.date)
                put("status", a.status)
                put("remarks", a.remarks)
                put("timestamp", a.timestamp)
            })
        }
        root.put("attendanceRecords", attArray)

        root.toString(2)
    }

    suspend fun exportAndShareBackup(context: Context): File = withContext(Dispatchers.IO) {
        val jsonString = createBackupJson()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = "Mazahirul_Ulum_Madrasa_Backup_$timeStamp.json"

        val backupDir = File(context.cacheDir, "backups")
        if (!backupDir.exists()) backupDir.mkdirs()

        val file = File(backupDir, fileName)
        file.writeText(jsonString)

        withContext(Dispatchers.Main) {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "মাযাহিরুল উলুম মাদ্রাসা ডাটাবেজ ব্যাকআপ")
                putExtra(Intent.EXTRA_TEXT, "মাযাহিরুল উলুম মাদ্রাসা হিসাবের সম্পূর্ণ ডাটাবেজ ব্যাকআপ ফাইল ($fileName)")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "ব্যাকআপ ফাইল সংরক্ষণ বা শেয়ার করুন"))
        }

        file
    }

    suspend fun restoreDatabaseFromJson(jsonContent: String): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(jsonContent)
            var totalRestored = 0

            // 1. Profile
            if (root.has("madrasaProfile")) {
                val pObj = root.getJSONObject("madrasaProfile")
                val profile = MadrasaProfile(
                    nameBn = pObj.optString("nameBn", "মাযাহিরুল উলুম মাদ্রাসা"),
                    nameEn = pObj.optString("nameEn", "Mazahirul Ulum Madrasa"),
                    address = pObj.optString("address", "বাংলাদেশ"),
                    phone = pObj.optString("phone", ""),
                    email = pObj.optString("email", ""),
                    principalName = pObj.optString("principalName", ""),
                    establishedYear = pObj.optString("establishedYear", "১৯৯৫"),
                    slogan = pObj.optString("slogan", ""),
                    hijriOffsetDays = pObj.optInt("hijriOffsetDays", 0),
                    selectedDistrict = pObj.optString("selectedDistrict", "ঢাকা"),
                    latitude = pObj.optDouble("latitude", 23.8103),
                    longitude = pObj.optDouble("longitude", 90.4125),
                    asrMadhhab = pObj.optString("asrMadhhab", "Hanafi"),
                    themeMode = pObj.optString("themeMode", "SYSTEM"),
                    appLanguage = pObj.optString("appLanguage", "BN")
                )
                database.madrasaProfileDao().insertProfile(profile)
            }

            // 2. Students
            if (root.has("students")) {
                val array = root.getJSONArray("students")
                val list = mutableListOf<Student>()
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    list.add(
                        Student(
                            id = o.optLong("id", 0L),
                            studentId = o.optString("studentId", ""),
                            name = o.optString("name", ""),
                            fatherName = o.optString("fatherName", ""),
                            motherName = o.optString("motherName", ""),
                            dateOfBirth = o.optString("dateOfBirth", ""),
                            phone = o.optString("phone", ""),
                            address = o.optString("address", ""),
                            admissionDate = o.optString("admissionDate", ""),
                            className = o.optString("className", ""),
                            department = o.optString("department", ""),
                            monthlyFee = o.optDouble("monthlyFee", 0.0),
                            status = o.optString("status", "সক্রিয়"),
                            notes = o.optString("notes", ""),
                            createdAt = o.optLong("createdAt", System.currentTimeMillis())
                        )
                    )
                }
                database.studentDao().deleteAllStudents()
                database.studentDao().insertAll(list)
                totalRestored += list.size
            }

            // 3. Teachers
            if (root.has("teachers")) {
                val array = root.getJSONArray("teachers")
                val list = mutableListOf<TeacherStaff>()
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    list.add(
                        TeacherStaff(
                            id = o.optLong("id", 0L),
                            name = o.optString("name", ""),
                            employeeId = o.optString("employeeId", ""),
                            phone = o.optString("phone", ""),
                            address = o.optString("address", ""),
                            joiningDate = o.optString("joiningDate", ""),
                            designation = o.optString("designation", "মুহাদ্দিস"),
                            salary = o.optDouble("salary", 0.0),
                            status = o.optString("status", "সক্রিয়"),
                            notes = o.optString("notes", ""),
                            createdAt = o.optLong("createdAt", System.currentTimeMillis())
                        )
                    )
                }
                database.teacherStaffDao().deleteAllTeachers()
                database.teacherStaffDao().insertTeachers(list)
                totalRestored += list.size
            }

            // 4. Fee Payments
            if (root.has("feePayments")) {
                val array = root.getJSONArray("feePayments")
                val list = mutableListOf<FeePayment>()
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    list.add(
                        FeePayment(
                            id = o.optLong("id", 0L),
                            receiptNo = o.optString("receiptNo", ""),
                            studentDbId = o.optLong("studentDbId", 0L),
                            studentCustomId = o.optString("studentCustomId", ""),
                            studentName = o.optString("studentName", ""),
                            className = o.optString("className", ""),
                            monthYear = o.optString("monthYear", ""),
                            feeAmount = o.optDouble("feeAmount", 0.0),
                            paidAmount = o.optDouble("paidAmount", 0.0),
                            dueAmount = o.optDouble("dueAmount", 0.0),
                            paymentDate = o.optString("paymentDate", ""),
                            paymentMethod = o.optString("paymentMethod", "নগদ"),
                            notes = o.optString("notes", ""),
                            collectedBy = o.optString("collectedBy", "অফিস"),
                            timestamp = o.optLong("timestamp", System.currentTimeMillis())
                        )
                    )
                }
                database.feePaymentDao().deleteAllPayments()
                database.feePaymentDao().insertAll(list)
                totalRestored += list.size
            }

            // 5. Salary Payments
            if (root.has("salaryPayments")) {
                val array = root.getJSONArray("salaryPayments")
                val list = mutableListOf<SalaryPayment>()
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    val salAmt = o.optDouble("salaryAmount", 0.0)
                    val bon = o.optDouble("bonus", 0.0)
                    val ded = o.optDouble("deduction", 0.0)
                    val net = o.optDouble("netPayable", salAmt + bon - ded)
                    val paid = o.optDouble("paidAmount", 0.0)
                    val due = o.optDouble("dueAmount", net - paid)

                    list.add(
                        SalaryPayment(
                            id = o.optLong("id", 0L),
                            voucherNo = o.optString("voucherNo", ""),
                            teacherStaffId = o.optLong("teacherStaffId", 0L),
                            teacherName = o.optString("teacherName", ""),
                            employeeId = o.optString("employeeId", ""),
                            designation = o.optString("designation", ""),
                            monthYear = o.optString("monthYear", ""),
                            salaryAmount = salAmt,
                            bonus = bon,
                            deduction = ded,
                            netPayable = net,
                            paidAmount = paid,
                            dueAmount = due,
                            paymentDate = o.optString("paymentDate", ""),
                            paymentMethod = o.optString("paymentMethod", "নগদ"),
                            notes = o.optString("notes", ""),
                            timestamp = o.optLong("timestamp", System.currentTimeMillis())
                        )
                    )
                }
                database.salaryPaymentDao().deleteAllSalaryPayments()
                database.salaryPaymentDao().insertPayments(list)
                totalRestored += list.size
            }

            // 6. Transactions
            if (root.has("transactions")) {
                val array = root.getJSONArray("transactions")
                val list = mutableListOf<Transaction>()
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    list.add(
                        Transaction(
                            id = o.optLong("id", 0L),
                            type = o.optString("type", "INCOME"),
                            title = o.optString("title", ""),
                            category = o.optString("category", ""),
                            amount = o.optDouble("amount", 0.0),
                            date = o.optString("date", ""),
                            paymentMethod = o.optString("paymentMethod", "নগদ"),
                            voucherNo = o.optString("voucherNo", ""),
                            description = o.optString("description", ""),
                            payeeOrSource = o.optString("payeeOrSource", ""),
                            reference = o.optString("reference", ""),
                            notes = o.optString("notes", ""),
                            timestamp = o.optLong("timestamp", System.currentTimeMillis())
                        )
                    )
                }
                database.transactionDao().deleteAllTransactions()
                database.transactionDao().insertAll(list)
                totalRestored += list.size
            }

            // 7. Loans
            if (root.has("loans")) {
                val array = root.getJSONArray("loans")
                val list = mutableListOf<Loan>()
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    list.add(
                        Loan(
                            id = o.optLong("id", 0L),
                            loanType = o.optString("loanType", "TAKEN"),
                            personName = o.optString("personName", ""),
                            phone = o.optString("phone", ""),
                            totalAmount = o.optDouble("totalAmount", 0.0),
                            paidAmount = o.optDouble("paidAmount", 0.0),
                            remainingAmount = o.optDouble("remainingAmount", 0.0),
                            date = o.optString("date", ""),
                            purpose = o.optString("purpose", ""),
                            status = o.optString("status", "চলমান"),
                            notes = o.optString("notes", ""),
                            timestamp = o.optLong("timestamp", System.currentTimeMillis())
                        )
                    )
                }
                database.loanDao().deleteAllLoans()
                database.loanDao().insertLoans(list)
                totalRestored += list.size
            }

            // 8. Loan Repayments
            if (root.has("loanRepayments")) {
                val array = root.getJSONArray("loanRepayments")
                val list = mutableListOf<LoanRepayment>()
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    list.add(
                        LoanRepayment(
                            id = o.optLong("id", 0L),
                            loanId = o.optLong("loanId", 0L),
                            amount = o.optDouble("amount", 0.0),
                            date = o.optString("date", ""),
                            paymentMethod = o.optString("paymentMethod", "নগদ"),
                            notes = o.optString("notes", ""),
                            timestamp = o.optLong("timestamp", System.currentTimeMillis())
                        )
                    )
                }
                database.loanDao().deleteAllRepayments()
                database.loanDao().insertRepayments(list)
                totalRestored += list.size
            }

            // 9. Attendance
            if (root.has("attendanceRecords")) {
                val array = root.getJSONArray("attendanceRecords")
                val list = mutableListOf<AttendanceRecord>()
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    list.add(
                        AttendanceRecord(
                            id = o.optLong("id", 0L),
                            studentDbId = o.optLong("studentDbId", 0L),
                            date = o.optString("date", ""),
                            status = o.optString("status", "PRESENT"),
                            remarks = o.optString("remarks", ""),
                            timestamp = o.optLong("timestamp", System.currentTimeMillis())
                        )
                    )
                }
                database.attendanceDao().deleteAllAttendance()
                database.attendanceDao().insertAll(list)
                totalRestored += list.size
            }

            Pair(true, "সফলভাবে $totalRestored টি ডাটা রেকর্ড রিস্টোর সম্পন্ন হয়েছে।")
        } catch (e: Exception) {
            Pair(false, "ডাটা রিস্টোর ব্যর্থ হয়েছে: ${e.message}")
        }
    }
}
