package com.example.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class MadrasaNotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent == null) return
        val title = intent.getStringExtra("EXTRA_TITLE") ?: "মাযাহিরুল উলুম মাদ্রাসা"
        val message = intent.getStringExtra("EXTRA_MESSAGE") ?: "একটি গুরুত্বপূর্ণ নোটিফিকেশন"
        val channelId = intent.getStringExtra("EXTRA_CHANNEL_ID") ?: NotificationHelper.MANAGEMENT_CHANNEL_ID
        val targetTab = intent.getStringExtra("EXTRA_TARGET_TAB") ?: "HOME"
        val notificationId = intent.getIntExtra("EXTRA_NOTIFICATION_ID", System.currentTimeMillis().toInt())

        NotificationHelper.showNotification(
            context = context,
            title = title,
            message = message,
            channelId = channelId,
            targetTab = targetTab,
            notificationId = notificationId
        )
    }
}
