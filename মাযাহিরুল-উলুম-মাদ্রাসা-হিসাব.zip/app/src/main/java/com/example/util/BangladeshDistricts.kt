package com.example.util

data class DistrictInfo(
    val nameBn: String,
    val nameEn: String,
    val division: String,
    val latitude: Double,
    val longitude: Double
)

object BangladeshDistricts {
    val districts = listOf(
        DistrictInfo("ঢাকা", "Dhaka", "ঢাকা", 23.8103, 90.4125),
        DistrictInfo("গাজীপুর", "Gazipur", "ঢাকা", 24.0023, 90.4264),
        DistrictInfo("নারায়ণগঞ্জ", "Narayanganj", "ঢাকা", 23.6238, 90.5000),
        DistrictInfo("টাঙ্গাইল", "Tangail", "ঢাকা", 24.2513, 89.9167),
        DistrictInfo("কিশোরগঞ্জ", "Kishoreganj", "ঢাকা", 24.4449, 90.7766),
        DistrictInfo("মানিকগঞ্জ", "Manikganj", "ঢাকা", 23.8644, 90.0047),
        DistrictInfo("মুন্সীগঞ্জ", "Munshiganj", "ঢাকা", 23.5422, 90.5305),
        DistrictInfo("নরসিংদী", "Narsingdi", "ঢাকা", 23.9322, 90.7154),
        DistrictInfo("ফরিদপুর", "Faridpur", "ঢাকা", 23.6071, 89.8429),
        DistrictInfo("গোপালগঞ্জ", "Gopalganj", "ঢাকা", 23.0051, 89.8266),
        DistrictInfo("মাদারীপুর", "Madaripur", "ঢাকা", 23.1641, 90.1897),
        DistrictInfo("রাজবাড়ী", "Rajbari", "ঢাকা", 23.7574, 89.6445),
        DistrictInfo("শরীয়তপুর", "Shariatpur", "ঢাকা", 23.2423, 90.4348),

        DistrictInfo("চট্টগ্রাম", "Chittagong", "চট্টগ্রাম", 22.3569, 91.7832),
        DistrictInfo("কক্সবাজার", "Cox's Bazar", "চট্টগ্রাম", 21.4272, 92.0058),
        DistrictInfo("কুমিল্লা", "Comilla", "চট্টগ্রাম", 23.4682, 91.1788),
        DistrictInfo("ব্রাহ্মণবাড়িয়া", "Brahmanbaria", "চট্টগ্রাম", 23.9571, 91.1119),
        DistrictInfo("চাঁদপুর", "Chandpur", "চট্টগ্রাম", 23.2333, 90.6667),
        DistrictInfo("লক্ষ্মীপুর", "Lakshmipur", "চট্টগ্রাম", 22.9425, 90.8412),
        DistrictInfo("নোয়াখালী", "Noakhali", "চট্টগ্রাম", 22.8696, 91.0998),
        DistrictInfo("ফেনী", "Feni", "চট্টগ্রাম", 23.0186, 91.3966),
        DistrictInfo("বান্দরবান", "Bandarban", "চট্টগ্রাম", 22.1953, 92.2184),
        DistrictInfo("খাগড়াছড়ি", "Khagrachhari", "চট্টগ্রাম", 23.1193, 91.9847),
        DistrictInfo("রাঙ্গামাটি", "Rangamati", "চট্টগ্রাম", 22.6533, 92.1753),

        DistrictInfo("সিলেট", "Sylhet", "সিলেট", 24.8949, 91.8687),
        DistrictInfo("মৌলভীবাজার", "Moulvibazar", "সিলেট", 24.4829, 91.7774),
        DistrictInfo("হবিগঞ্জ", "Habiganj", "সিলেট", 24.3749, 91.4155),
        DistrictInfo("সুনামগঞ্জ", "Sunamganj", "সিলেট", 25.0658, 91.3950),

        DistrictInfo("রাজশাহী", "Rajshahi", "রাজশাহী", 24.3636, 88.6241),
        DistrictInfo("বগুড়া", "Bogra", "রাজশাহী", 24.8465, 89.3770),
        DistrictInfo("পাবনা", "Pabna", "রাজশাহী", 24.0064, 89.2372),
        DistrictInfo("সিরাজগঞ্জ", "Sirajganj", "রাজশাহী", 24.4534, 89.7008),
        DistrictInfo("নাটোর", "Natore", "রাজশাহী", 24.4206, 88.9324),
        DistrictInfo("নওগাঁ", "Naogaon", "রাজশাহী", 24.8103, 88.9416),
        DistrictInfo("চাঁপাইনবাবগঞ্জ", "Chapainawabganj", "রাজশাহী", 24.5965, 88.2775),
        DistrictInfo("জয়পুরহাট", "Joypurhat", "রাজশাহী", 25.0968, 89.0227),

        DistrictInfo("খুলনা", "Khulna", "খুলনা", 22.8456, 89.5403),
        DistrictInfo("যশোর", "Jashore", "খুলনা", 23.1664, 89.2081),
        DistrictInfo("কুষ্টিয়া", "Kushtia", "খুলনা", 23.9013, 89.1205),
        DistrictInfo("সাতক্ষীরা", "Satkhira", "খুলনা", 22.7185, 89.0705),
        DistrictInfo("বাগেরহাট", "Bagerhat", "খুলনা", 22.6516, 89.7859),
        DistrictInfo("ঝিনাইদহ", "Jhenaidah", "খুলনা", 23.5450, 89.1726),
        DistrictInfo("চুয়াডাঙ্গা", "Chuadanga", "খুলনা", 23.6402, 88.8418),
        DistrictInfo("মাগুরা", "Magura", "খুলনা", 23.4873, 89.4198),
        DistrictInfo("মেহেরপুর", "Meherpur", "খুলনা", 23.7745, 88.6318),
        DistrictInfo("নড়াইল", "Narail", "খুলনা", 23.1725, 89.5127),

        DistrictInfo("বরিশাল", "Barisal", "বরিশাল", 22.7010, 90.3535),
        DistrictInfo("পটুয়াখালী", "Patuakhali", "বরিশাল", 22.3596, 90.3299),
        DistrictInfo("ভোলা", "Bhola", "বরিশাল", 22.6859, 90.6481),
        DistrictInfo("পিরোজপুর", "Pirojpur", "বরিশাল", 22.5841, 89.9720),
        DistrictInfo("বরগুনা", "Barguna", "বরিশাল", 22.0953, 90.0768),
        DistrictInfo("ঝালকাঠি", "Jhalokati", "বরিশাল", 22.6406, 90.1987),

        DistrictInfo("রংপুর", "Rangpur", "রংপুর", 25.7439, 89.2752),
        DistrictInfo("দিনাজপুর", "Dinajpur", "রংপুর", 25.6217, 88.6354),
        DistrictInfo("গাইবান্ধা", "Gaibandha", "রংপুর", 25.3288, 89.5407),
        DistrictInfo("কুড়িগ্রাম", "Kurigram", "রংপুর", 25.8054, 89.6362),
        DistrictInfo("নীলফামারী", "Nilphamari", "রংপুর", 25.9318, 88.8560),
        DistrictInfo("লালমনিরহাট", "Lalmonirhat", "রংপুর", 25.9165, 89.4532),
        DistrictInfo("পঞ্চগড়", "Panchagarh", "রংপুর", 26.3411, 88.5542),
        DistrictInfo("ঠাকুরগাঁও", "Thakurgaon", "রংপুর", 26.0337, 88.4617),

        DistrictInfo("ময়মনসিংহ", "Mymensingh", "ময়মনসিংহ", 24.7471, 90.4203),
        DistrictInfo("জামালপুর", "Jamalpur", "ময়মনসিংহ", 24.9375, 89.9378),
        DistrictInfo("নেত্রকোণা", "Netrokona", "ময়মনসিংহ", 24.8709, 90.7279),
        DistrictInfo("শেরপুর", "Sherpur", "ময়মনসিংহ", 25.0205, 90.0153)
    )

    fun findDistrict(name: String): DistrictInfo {
        return districts.find { it.nameBn.equals(name, ignoreCase = true) || it.nameEn.equals(name, ignoreCase = true) }
            ?: districts[0]
    }
}
