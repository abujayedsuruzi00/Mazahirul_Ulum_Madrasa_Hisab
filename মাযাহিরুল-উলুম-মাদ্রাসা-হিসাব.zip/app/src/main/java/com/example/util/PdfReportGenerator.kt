package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.local.entity.MadrasaProfile
import com.example.data.local.entity.Transaction
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfReportGenerator {

    fun generateAndShareFinancialReport(
        context: Context,
        profile: MadrasaProfile,
        reportTitle: String,
        dateRangeStr: String,
        totalIncome: Double,
        totalExpense: Double,
        netBalance: Double,
        transactions: List<Transaction>
    ): Uri? {
        try {
            val pdfDoc = PdfDocument()
            val pageWidth = 595
            val pageHeight = 842
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
            val page = pdfDoc.startPage(pageInfo)
            val canvas = page.canvas

            // Background
            val bgPaint = Paint().apply {
                color = Color.WHITE
                style = Paint.Style.FILL
            }
            canvas.drawRect(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), bgPaint)

            // Header Banner
            val headerPaint = Paint().apply {
                color = Color.parseColor("#064E3B") // Emerald
                style = Paint.Style.FILL
            }
            canvas.drawRect(0f, 0f, pageWidth.toFloat(), 110f, headerPaint)

            val goldPaint = Paint().apply {
                color = Color.parseColor("#D97706") // Gold
                style = Paint.Style.FILL
            }
            canvas.drawRect(0f, 110f, pageWidth.toFloat(), 114f, goldPaint)

            // Title and Info
            val bismillahPaint = Paint().apply {
                color = Color.parseColor("#FEF3C7")
                textSize = 12f
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", pageWidth / 2f, 30f, bismillahPaint)

            val madrasaPaint = Paint().apply {
                color = Color.WHITE
                textSize = 18f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(profile.nameBn, pageWidth / 2f, 58f, madrasaPaint)

            val subPaint = Paint().apply {
                color = Color.parseColor("#D1FAE5")
                textSize = 10f
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("${profile.address} | মোবাইল: ${profile.phone}", pageWidth / 2f, 78f, subPaint)

            val engPaint = Paint().apply {
                color = Color.parseColor("#93C5FD")
                textSize = 9f
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(profile.nameEn, pageWidth / 2f, 96f, engPaint)

            // Report Header
            var curY = 140f
            val repTitlePaint = Paint().apply {
                color = Color.parseColor("#064E3B")
                textSize = 16f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(reportTitle, pageWidth / 2f, curY, repTitlePaint)

            curY += 20f
            val datePaint = Paint().apply {
                color = Color.parseColor("#475569")
                textSize = 11f
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("সময়কাল / ফিল্টার: $dateRangeStr  •  প্রিন্ট তারিখ: ${NumberFormatter.toBanglaDigits(SimpleDateFormat("dd MMMM yyyy, hh:mm a", Locale.getDefault()).format(Date()))}", pageWidth / 2f, curY, datePaint)

            // 3 Summary Cards
            curY += 25f
            val cardW = (pageWidth - 80f) / 3f

            // Card 1: Total Income
            drawSummaryCard(canvas, 30f, curY, cardW, 55f, "মোট আয়", NumberFormatter.formatCurrency(totalIncome), Color.parseColor("#ECFDF5"), Color.parseColor("#059669"))
            // Card 2: Total Expense
            drawSummaryCard(canvas, 30f + cardW + 10f, curY, cardW, 55f, "মোট ব্যয়", NumberFormatter.formatCurrency(totalExpense), Color.parseColor("#FEF2F2"), Color.parseColor("#DC2626"))
            // Card 3: Net Balance
            drawSummaryCard(canvas, 30f + (cardW + 10f) * 2, curY, cardW, 55f, "উদ্বৃত্ত / স্থিতি", NumberFormatter.formatCurrency(netBalance), Color.parseColor("#EFF6FF"), Color.parseColor("#0284C7"))

            // Transactions Table Header
            curY += 75f
            val tableThBg = Paint().apply {
                color = Color.parseColor("#065F46")
                style = Paint.Style.FILL
            }
            canvas.drawRect(30f, curY, pageWidth - 30f, curY + 24f, tableThBg)

            val thText = Paint().apply {
                color = Color.WHITE
                textSize = 10f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            canvas.drawText("তারিখ", 40f, curY + 16f, thText)
            canvas.drawText("ধরণ / খাত", 110f, curY + 16f, thText)
            canvas.drawText("বিবরণ / সূত্র / গ্রহীতা", 220f, curY + 16f, thText)
            canvas.drawText("ভাউচার", 390f, curY + 16f, thText)
            canvas.drawText("টাকা", 480f, curY + 16f, thText)

            curY += 24f
            val trBorder = Paint().apply {
                color = Color.parseColor("#E2E8F0")
                style = Paint.Style.STROKE
                strokeWidth = 0.8f
            }
            val tdText = Paint().apply {
                color = Color.parseColor("#1E293B")
                textSize = 9.5f
            }

            val maxRows = 20
            val displayList = transactions.take(maxRows)

            displayList.forEachIndexed { idx, tx ->
                val rowH = 22f
                val rowBg = if (idx % 2 == 0) Color.WHITE else Color.parseColor("#F8FAFC")
                val bgRowPaint = Paint().apply {
                    color = rowBg
                    style = Paint.Style.FILL
                }
                canvas.drawRect(30f, curY, pageWidth - 30f, curY + rowH, bgRowPaint)
                canvas.drawRect(30f, curY, pageWidth - 30f, curY + rowH, trBorder)

                val amountColor = if (tx.type == "INCOME") Color.parseColor("#059669") else Color.parseColor("#DC2626")
                val amountPaint = Paint().apply {
                    color = amountColor
                    textSize = 9.5f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                }

                val typeLabel = if (tx.type == "INCOME") "[আয়] ${tx.category}" else "[ব্যয়] ${tx.category}"
                val descText = if (tx.payeeOrSource.isNotEmpty()) "${tx.title} (${tx.payeeOrSource})" else tx.title

                canvas.drawText(NumberFormatter.toBanglaDigits(tx.date), 40f, curY + 15f, tdText)
                canvas.drawText(typeLabel.take(18), 110f, curY + 15f, tdText)
                canvas.drawText(descText.take(30), 220f, curY + 15f, tdText)
                canvas.drawText(tx.voucherNo.ifEmpty { "-" }, 390f, curY + 15f, tdText)
                canvas.drawText(NumberFormatter.formatCurrency(tx.amount), 480f, curY + 15f, amountPaint)

                curY += rowH
            }

            // If more rows were truncated
            if (transactions.size > maxRows) {
                curY += 15f
                val notePaint = Paint().apply {
                    color = Color.parseColor("#64748B")
                    textSize = 9f
                    textAlign = Paint.Align.CENTER
                }
                canvas.drawText("... আরও ${NumberFormatter.toBanglaDigits(transactions.size - maxRows)} টি লেনদেন বিদ্যমান ...", pageWidth / 2f, curY, notePaint)
            }

            // Signatures
            val sigY = pageHeight - 80f
            val sigLine = Paint().apply {
                color = Color.parseColor("#94A3B8")
                strokeWidth = 1f
            }
            canvas.drawLine(50f, sigY, 180f, sigY, sigLine)
            canvas.drawLine(pageWidth - 180f, sigY, pageWidth - 50f, sigY, sigLine)

            val sigText = Paint().apply {
                color = Color.parseColor("#475569")
                textSize = 10f
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("হিসাবরক্ষক", 115f, sigY + 15f, sigText)
            canvas.drawText("মুহতামিম / সভাপতি", pageWidth - 115f, sigY + 15f, sigText)

            // Footer
            val footerPaint = Paint().apply {
                color = Color.parseColor("#94A3B8")
                textSize = 9f
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("মাযাহিরুল উলুম মাদ্রাসা হিসাব ও ব্যবস্থাপনা সিস্টেম - ১০০% অফলাইন ও নির্ভরযোগ্য", pageWidth / 2f, pageHeight - 30f, footerPaint)

            pdfDoc.finishPage(page)

            // Save PDF
            val reportsDir = File(context.cacheDir, "reports")
            if (!reportsDir.exists()) reportsDir.mkdirs()
            val fileName = "Report_${System.currentTimeMillis()}.pdf"
            val file = File(reportsDir, fileName)
            val fos = FileOutputStream(file)
            pdfDoc.writeTo(fos)
            fos.close()
            pdfDoc.close()

            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            // Launch share sheet
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "$reportTitle - ${profile.nameBn}")
                putExtra(Intent.EXTRA_TEXT, "${profile.nameBn}\n$reportTitle\nমোট আয়: ${NumberFormatter.formatCurrency(totalIncome)}\nমোট ব্যয়: ${NumberFormatter.formatCurrency(totalExpense)}\nউদ্বৃত্ত: ${NumberFormatter.formatCurrency(netBalance)}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(shareIntent, "রিপোর্ট শেয়ার বা প্রিন্ট করুন")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)

            return uri
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "রিপোর্ট ফাইলে ত্রুটি: ${e.message}", Toast.LENGTH_LONG).show()
            return null
        }
    }

    private fun drawSummaryCard(
        canvas: Canvas,
        x: Float,
        y: Float,
        width: Float,
        height: Float,
        title: String,
        amount: String,
        bgColor: Int,
        textColor: Int
    ) {
        val bgPaint = Paint().apply {
            color = bgColor
            style = Paint.Style.FILL
        }
        val borderPaint = Paint().apply {
            color = Color.parseColor("#CBD5E1")
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }
        val rect = RectF(x, y, x + width, y + height)
        canvas.drawRoundRect(rect, 6f, 6f, bgPaint)
        canvas.drawRoundRect(rect, 6f, 6f, borderPaint)

        val titlePaint = Paint().apply {
            color = Color.parseColor("#475569")
            textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(title, x + width / 2f, y + 20f, titlePaint)

        val valPaint = Paint().apply {
            color = textColor
            textSize = 12f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(amount, x + width / 2f, y + 42f, valPaint)
    }
}
