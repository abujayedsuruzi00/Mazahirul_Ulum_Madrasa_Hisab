package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "students")
data class Student(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val studentId: String, // e.g. "MU-2026-001"
    val name: String,
    val fatherName: String = "",
    val motherName: String = "",
    val dateOfBirth: String = "",
    val phone: String = "",
    val address: String = "",
    val admissionDate: String = "",
    val className: String = "নূরানী", // নূরানী, নাজেরা, হিফজ, কিতাব ১ম বর্ষ, ইত্যাদি
    val department: String = "হিফজ বিভাগ", // হিফজ, কিতাব, নূরানী, জেনারেল
    val monthlyFee: Double = 0.0,
    val status: String = "সক্রিয়", // "সক্রিয়", "নিষ্ক্রিয়"
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
