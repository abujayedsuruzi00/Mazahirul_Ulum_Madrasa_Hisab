package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.SalaryPayment
import kotlinx.coroutines.flow.Flow

@Dao
interface SalaryPaymentDao {
    @Query("SELECT * FROM salary_payments ORDER BY id DESC")
    fun getAllSalaryPayments(): Flow<List<SalaryPayment>>

    @Query("SELECT * FROM salary_payments ORDER BY id DESC")
    suspend fun getAllSalaryPaymentsDirect(): List<SalaryPayment>

    @Query("SELECT * FROM salary_payments WHERE teacherStaffId = :teacherId ORDER BY id DESC")
    fun getPaymentsForTeacher(teacherId: Long): Flow<List<SalaryPayment>>

    @Query("SELECT * FROM salary_payments WHERE monthYear = :monthYear ORDER BY id DESC")
    fun getPaymentsForMonth(monthYear: String): Flow<List<SalaryPayment>>

    @Query("SELECT * FROM salary_payments WHERE teacherStaffId = :teacherId AND monthYear = :monthYear LIMIT 1")
    suspend fun getPaymentForTeacherAndMonth(teacherId: Long, monthYear: String): SalaryPayment?

    @Query("SELECT COALESCE(SUM(paidAmount), 0.0) FROM salary_payments")
    fun getTotalSalaryPaid(): Flow<Double>

    @Query("SELECT COALESCE(SUM(dueAmount), 0.0) FROM salary_payments")
    fun getTotalSalaryDue(): Flow<Double>

    @Query("SELECT COALESCE(SUM(paidAmount), 0.0) FROM salary_payments WHERE monthYear = :monthYear")
    fun getSalaryPaidForMonth(monthYear: String): Flow<Double>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: SalaryPayment): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayments(payments: List<SalaryPayment>)

    @Update
    suspend fun updatePayment(payment: SalaryPayment)

    @Delete
    suspend fun deletePayment(payment: SalaryPayment)

    @Query("DELETE FROM salary_payments WHERE teacherStaffId = :teacherId")
    suspend fun deleteForTeacher(teacherId: Long)

    @Query("DELETE FROM salary_payments")
    suspend fun deleteAllSalaryPayments()
}
