package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: String, // "INCOME" or "EXPENSE"
    val title: String,
    val category: String, // অনুদান, লিল্লাহ ফান্ড, জাকাত, ফিতরা, চামড়া বিক্রয়, ছাত্র বেতন, শিক্ষক বেতন, বোর্ডিং/খাবার, ইউটিলিটি, মেরামত, বিবিধ
    val amount: Double,
    val date: String, // YYYY-MM-DD
    val paymentMethod: String = "নগদ", // নগদ, ব্যাংক, বিকাশ/রকেট
    val voucherNo: String = "",
    val description: String = "",
    val payeeOrSource: String = "", // Source for income, Payee for expense
    val reference: String = "",
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
