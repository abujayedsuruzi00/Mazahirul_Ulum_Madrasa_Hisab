package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "fee_payments")
data class FeePayment(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val receiptNo: String, // e.g. "MU-REC-2026-0001"
    val studentDbId: Long,
    val studentCustomId: String,
    val studentName: String,
    val className: String = "",
    val monthYear: String, // e.g. "জানুয়ারি ২০২৬", "রমজান ১৪৪৭"
    val feeAmount: Double,
    val paidAmount: Double,
    val dueAmount: Double, // feeAmount - paidAmount
    val paymentDate: String,
    val paymentMethod: String = "নগদ", // নগদ, বিকাশ, নগদ MFS, ব্যাংক
    val notes: String = "",
    val collectedBy: String = "অফিস",
    val timestamp: Long = System.currentTimeMillis()
)
