package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.AttendanceDao
import com.example.data.local.dao.FeePaymentDao
import com.example.data.local.dao.LoanDao
import com.example.data.local.dao.MadrasaProfileDao
import com.example.data.local.dao.SalaryPaymentDao
import com.example.data.local.dao.StudentDao
import com.example.data.local.dao.TeacherStaffDao
import com.example.data.local.dao.TransactionDao
import com.example.data.local.entity.AttendanceRecord
import com.example.data.local.entity.FeePayment
import com.example.data.local.entity.Loan
import com.example.data.local.entity.LoanRepayment
import com.example.data.local.entity.MadrasaProfile
import com.example.data.local.entity.SalaryPayment
import com.example.data.local.entity.Student
import com.example.data.local.entity.TeacherStaff
import com.example.data.local.entity.Transaction
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Database(
    entities = [
        Student::class,
        FeePayment::class,
        Transaction::class,
        Loan::class,
        LoanRepayment::class,
        AttendanceRecord::class,
        MadrasaProfile::class,
        TeacherStaff::class,
        SalaryPayment::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun studentDao(): StudentDao
    abstract fun feePaymentDao(): FeePaymentDao
    abstract fun transactionDao(): TransactionDao
    abstract fun loanDao(): LoanDao
    abstract fun attendanceDao(): AttendanceDao
    abstract fun madrasaProfileDao(): MadrasaProfileDao
    abstract fun teacherStaffDao(): TeacherStaffDao
    abstract fun salaryPaymentDao(): SalaryPaymentDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mazahirul_ulum_madrasa_db"
                )
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Populate initial profile & starter data in background
                            CoroutineScope(Dispatchers.IO).launch {
                                val database = getInstance(context)
                                database.madrasaProfileDao().insertProfile(
                                    MadrasaProfile(
                                        id = 1,
                                        nameBn = "মাযাহিরুল উলুম মাদ্রাসা",
                                        nameEn = "Mazahirul Ulum Madrasa",
                                        address = "মাদ্রাসার ঠিকানা, বাংলাদেশ",
                                        phone = "০১৭১১-XXXXXX",
                                        principalName = "মুহতামিম সাহেব",
                                        selectedDistrict = "ঢাকা",
                                        latitude = 23.8103,
                                        longitude = 90.4125
                                    )
                                )

                                val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                                val thisMonth = "সেপ্টেম্বর ২০২৬"

                                // Initial demo students
                                val s1Id = database.studentDao().insertStudent(
                                    Student(
                                        studentId = "MU-2026-001",
                                        name = "মুহাম্মাদ আবদুল্লাহ",
                                        fatherName = "মাওলানা রফিকুল ইসলাম",
                                        phone = "01711223344",
                                        address = "ঢাকা, বাংলাদেশ",
                                        admissionDate = today,
                                        className = "হিফজুল কুরআন",
                                        department = "হিফজ বিভাগ",
                                        monthlyFee = 1500.0,
                                        status = "সক্রিয়"
                                    )
                                )

                                val s2Id = database.studentDao().insertStudent(
                                    Student(
                                        studentId = "MU-2026-002",
                                        name = "মুহাম্মাদ উসমান গনি",
                                        fatherName = "হাফেজ নজরুল ইসলাম",
                                        phone = "01822334455",
                                        address = "নারায়ণগঞ্জ, বাংলাদেশ",
                                        admissionDate = today,
                                        className = "নূরানী ১ম",
                                        department = "নূরানী বিভাগ",
                                        monthlyFee = 1000.0,
                                        status = "সক্রিয়"
                                    )
                                )

                                val s3Id = database.studentDao().insertStudent(
                                    Student(
                                        studentId = "MU-2026-003",
                                        name = "মুহাম্মাদ তালহা",
                                        fatherName = "আব্দুর রহিম",
                                        phone = "01933445566",
                                        address = "গাজীপুর, বাংলাদেশ",
                                        admissionDate = today,
                                        className = "কিতাব ১ম বর্ষ",
                                        department = "কিতাব বিভাগ",
                                        monthlyFee = 1800.0,
                                        status = "সক্রিয়"
                                    )
                                )

                                // Initial Teachers & Staff
                                val t1Id = database.teacherStaffDao().insertTeacher(
                                    TeacherStaff(
                                        name = "মাওলানা মুফতি মাহমূদুল হাসান",
                                        employeeId = "EMP-001",
                                        phone = "01712000001",
                                        address = "ঢাকা",
                                        joiningDate = today,
                                        designation = "মুহতামিম ও শায়খুল হাদিস",
                                        salary = 25000.0,
                                        status = "সক্রিয়",
                                        notes = "প্রধান পরিচালক"
                                    )
                                )

                                val t2Id = database.teacherStaffDao().insertTeacher(
                                    TeacherStaff(
                                        name = "হাফেজ ক্বারী সিরাজুল ইসলাম",
                                        employeeId = "EMP-002",
                                        phone = "01819000002",
                                        address = "ঢাকা",
                                        joiningDate = today,
                                        designation = "হিফজ শিক্ষক",
                                        salary = 16000.0,
                                        status = "সক্রিয়",
                                        notes = "হিফজ বিভাগ প্রধান"
                                    )
                                )

                                val t3Id = database.teacherStaffDao().insertTeacher(
                                    TeacherStaff(
                                        name = "মাওলানা আব্দুল করিম",
                                        employeeId = "EMP-003",
                                        phone = "01911000003",
                                        address = "ঢাকা",
                                        joiningDate = today,
                                        designation = "নূরানী শিক্ষক",
                                        salary = 12000.0,
                                        status = "সক্রিয়",
                                        notes = "নূরানী ১ম শ্রেণি"
                                    )
                                )

                                // Initial transactions
                                database.transactionDao().insertTransaction(
                                    Transaction(
                                        type = "INCOME",
                                        title = "মাসিক সাধারণ অনুদান",
                                        category = "অনুদান",
                                        amount = 15000.0,
                                        date = today,
                                        paymentMethod = "নগদ",
                                        voucherNo = "VOC-101",
                                        payeeOrSource = "হাজী মোহাম্মদ ইউনুস",
                                        reference = "মাসিক ডোনেশন",
                                        description = "মাদ্রাসার নিয়মিত হিতাকাঙ্ক্ষীর এককালীন দান"
                                    )
                                )

                                database.transactionDao().insertTransaction(
                                    Transaction(
                                        type = "EXPENSE",
                                        title = "বোর্ডিং খাবার বাজার",
                                        category = "বোর্ডিং/খাবার",
                                        amount = 4500.0,
                                        date = today,
                                        paymentMethod = "নগদ",
                                        voucherNo = "VOC-102",
                                        payeeOrSource = "কারওয়ান বাজার পাইকারি আড়ত",
                                        reference = "চাল, ডাল, তেল",
                                        description = "ছাত্রদের দৈনিক খাবার খরচ"
                                    )
                                )

                                // Initial Fee Payment & Receipt
                                database.feePaymentDao().insertPayment(
                                    FeePayment(
                                        receiptNo = "MU-REC-20260902-001",
                                        studentDbId = s1Id,
                                        studentCustomId = "MU-2026-001",
                                        studentName = "মুহাম্মাদ আবদুল্লাহ",
                                        className = "হিফজুল কুরআন",
                                        monthYear = thisMonth,
                                        feeAmount = 1500.0,
                                        paidAmount = 1500.0,
                                        dueAmount = 0.0,
                                        paymentDate = today,
                                        paymentMethod = "নগদ",
                                        notes = "সেপ্টেম্বর মাসের সম্পূর্ণ ফি পরিশোধ"
                                    )
                                )

                                // Initial Attendance
                                database.attendanceDao().insertOrUpdate(
                                    AttendanceRecord(studentDbId = s1Id, date = today, status = "PRESENT")
                                )
                                database.attendanceDao().insertOrUpdate(
                                    AttendanceRecord(studentDbId = s2Id, date = today, status = "PRESENT")
                                )
                                database.attendanceDao().insertOrUpdate(
                                    AttendanceRecord(studentDbId = s3Id, date = today, status = "PRESENT")
                                )
                            }
                        }
                    })
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
