package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "loan_repayments")
data class LoanRepayment(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val loanId: Long,
    val amount: Double,
    val date: String,
    val paymentMethod: String = "নগদ",
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
