package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.TeacherStaff
import kotlinx.coroutines.flow.Flow

@Dao
interface TeacherStaffDao {
    @Query("SELECT * FROM teacher_staff ORDER BY id DESC")
    fun getAllTeachers(): Flow<List<TeacherStaff>>

    @Query("SELECT * FROM teacher_staff ORDER BY id DESC")
    suspend fun getAllTeachersDirect(): List<TeacherStaff>

    @Query("SELECT * FROM teacher_staff WHERE id = :id")
    fun getTeacherById(id: Long): Flow<TeacherStaff?>

    @Query("SELECT * FROM teacher_staff WHERE id = :id")
    suspend fun getTeacherByIdDirect(id: Long): TeacherStaff?

    @Query("SELECT COUNT(*) FROM teacher_staff WHERE status = 'সক্রিয়' OR status = 'Active'")
    fun getActiveTeacherCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM teacher_staff")
    fun getTotalTeacherCount(): Flow<Int>

    @Query("SELECT SUM(salary) FROM teacher_staff WHERE status = 'সক্রিয়' OR status = 'Active'")
    fun getTotalMonthlyBudget(): Flow<Double?>

    @Query("""
        SELECT * FROM teacher_staff 
        WHERE (name LIKE '%' || :query || '%' OR employeeId LIKE '%' || :query || '%' OR phone LIKE '%' || :query || '%')
        AND (:designation = '' OR designation = :designation)
        AND (:status = '' OR status = :status)
        ORDER BY id DESC
    """)
    fun searchTeachers(
        query: String,
        designation: String = "",
        status: String = ""
    ): Flow<List<TeacherStaff>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeacher(teacher: TeacherStaff): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeachers(teachers: List<TeacherStaff>)

    @Update
    suspend fun updateTeacher(teacher: TeacherStaff)

    @Delete
    suspend fun deleteTeacher(teacher: TeacherStaff)

    @Query("DELETE FROM teacher_staff")
    suspend fun deleteAllTeachers()
}
