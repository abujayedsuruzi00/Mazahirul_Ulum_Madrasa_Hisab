package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.Loan
import com.example.data.local.entity.LoanRepayment
import kotlinx.coroutines.flow.Flow

@Dao
interface LoanDao {
    @Query("SELECT * FROM loans ORDER BY id DESC")
    fun getAllLoans(): Flow<List<Loan>>

    @Query("SELECT * FROM loans ORDER BY id DESC")
    suspend fun getAllLoansDirect(): List<Loan>

    @Query("SELECT * FROM loan_repayments ORDER BY id DESC")
    suspend fun getAllRepaymentsDirect(): List<LoanRepayment>

    @Query("SELECT * FROM loans WHERE id = :id")
    fun getLoanById(id: Long): Flow<Loan?>

    @Query("SELECT * FROM loans WHERE id = :id")
    suspend fun getLoanByIdDirect(id: Long): Loan?

    @Query("SELECT COALESCE(SUM(remainingAmount), 0.0) FROM loans WHERE loanType = 'TAKEN' AND status = 'চলমান'")
    fun getTotalLoanPayable(): Flow<Double> // মাদ্রাসা পরিশোধ করতে হবে

    @Query("SELECT COALESCE(SUM(remainingAmount), 0.0) FROM loans WHERE loanType = 'GIVEN' AND status = 'চলমান'")
    fun getTotalLoanReceivable(): Flow<Double> // মাদ্রাসা ফেরত পাবে

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLoan(loan: Loan): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLoans(loans: List<Loan>)

    @Update
    suspend fun updateLoan(loan: Loan)

    @Delete
    suspend fun deleteLoan(loan: Loan)

    @Query("DELETE FROM loans WHERE id = :id")
    suspend fun deleteLoanById(id: Long)

    @Query("DELETE FROM loans")
    suspend fun deleteAllLoans()

    // Repayments
    @Query("SELECT * FROM loan_repayments WHERE loanId = :loanId ORDER BY timestamp DESC")
    fun getRepaymentsForLoan(loanId: Long): Flow<List<LoanRepayment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRepayment(repayment: LoanRepayment): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRepayments(repayments: List<LoanRepayment>)

    @Query("DELETE FROM loan_repayments WHERE loanId = :loanId")
    suspend fun deleteRepaymentsForLoan(loanId: Long)

    @Query("DELETE FROM loan_repayments")
    suspend fun deleteAllRepayments()
}
