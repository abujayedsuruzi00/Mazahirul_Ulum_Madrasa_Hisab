package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.Student
import kotlinx.coroutines.flow.Flow

@Dao
interface StudentDao {
    @Query("SELECT * FROM students ORDER BY id DESC")
    fun getAllStudents(): Flow<List<Student>>

    @Query("SELECT * FROM students WHERE id = :id")
    fun getStudentById(id: Long): Flow<Student?>

    @Query("SELECT * FROM students WHERE id = :id")
    suspend fun getStudentByIdDirect(id: Long): Student?

    @Query("""
        SELECT * FROM students 
        WHERE (name LIKE '%' || :query || '%' OR studentId LIKE '%' || :query || '%' OR phone LIKE '%' || :query || '%')
        AND (:className = '' OR className = :className)
        AND (:department = '' OR department = :department)
        AND (:status = '' OR status = :status)
        ORDER BY id DESC
    """)
    fun searchStudents(query: String, className: String, department: String, status: String): Flow<List<Student>>

    @Query("SELECT COUNT(*) FROM students WHERE status = 'সক্রিয়'")
    fun getActiveStudentCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM students")
    fun getTotalStudentCount(): Flow<Int>

    @Query("SELECT * FROM students ORDER BY id DESC")
    suspend fun getAllStudentsDirect(): List<Student>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudent(student: Student): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(students: List<Student>)

    @Update
    suspend fun updateStudent(student: Student)

    @Delete
    suspend fun deleteStudent(student: Student)

    @Query("DELETE FROM students WHERE id = :id")
    suspend fun deleteStudentById(id: Long)

    @Query("DELETE FROM students")
    suspend fun deleteAllStudents()
}
