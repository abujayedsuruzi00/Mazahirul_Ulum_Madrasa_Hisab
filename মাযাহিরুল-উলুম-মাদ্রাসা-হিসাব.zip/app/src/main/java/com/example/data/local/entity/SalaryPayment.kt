package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "salary_payments")
data class SalaryPayment(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val voucherNo: String, // e.g. "SAL-2026-0001"
    val teacherStaffId: Long,
    val teacherName: String,
    val employeeId: String,
    val designation: String = "",
    val monthYear: String, // e.g. "জানুয়ারি ২০২৬"
    val salaryAmount: Double,
    val bonus: Double = 0.0,
    val deduction: Double = 0.0,
    val netPayable: Double, // salaryAmount + bonus - deduction
    val paidAmount: Double,
    val dueAmount: Double, // netPayable - paidAmount
    val paymentDate: String,
    val paymentMethod: String = "নগদ", // নগদ, ব্যাংক, বিকাশ
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
