package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "loans")
data class Loan(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val loanType: String, // "TAKEN" (মাদ্রাসা কর্তৃক গৃহীত ঋণ) or "GIVEN" (মাদ্রাসা কর্তৃক প্রদত্ত ঋণ/করজে হাসানা)
    val personName: String,
    val phone: String = "",
    val totalAmount: Double,
    val paidAmount: Double = 0.0,
    val remainingAmount: Double, // totalAmount - paidAmount
    val date: String,
    val purpose: String = "",
    val status: String = "চলমান", // "চলমান", "পরিশোধিত"
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
