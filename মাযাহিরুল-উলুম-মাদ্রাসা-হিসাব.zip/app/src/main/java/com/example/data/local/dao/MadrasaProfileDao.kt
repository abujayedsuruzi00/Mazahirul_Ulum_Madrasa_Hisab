package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.MadrasaProfile
import kotlinx.coroutines.flow.Flow

@Dao
interface MadrasaProfileDao {
    @Query("SELECT * FROM madrasa_profile WHERE id = 1 LIMIT 1")
    fun getProfile(): Flow<MadrasaProfile?>

    @Query("SELECT * FROM madrasa_profile WHERE id = 1 LIMIT 1")
    suspend fun getProfileDirect(): MadrasaProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: MadrasaProfile)

    @Update
    suspend fun updateProfile(profile: MadrasaProfile)
}
