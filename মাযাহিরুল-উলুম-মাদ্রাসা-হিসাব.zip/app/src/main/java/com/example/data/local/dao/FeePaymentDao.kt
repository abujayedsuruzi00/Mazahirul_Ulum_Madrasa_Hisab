package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.FeePayment
import kotlinx.coroutines.flow.Flow

@Dao
interface FeePaymentDao {
    @Query("SELECT * FROM fee_payments ORDER BY id DESC")
    fun getAllPayments(): Flow<List<FeePayment>>

    @Query("SELECT * FROM fee_payments WHERE studentDbId = :studentId ORDER BY id DESC")
    fun getPaymentsForStudent(studentId: Long): Flow<List<FeePayment>>

    @Query("SELECT * FROM fee_payments ORDER BY id DESC")
    suspend fun getAllPaymentsDirect(): List<FeePayment>

    @Query("SELECT * FROM fee_payments WHERE id = :id")
    suspend fun getPaymentById(id: Long): FeePayment?

    @Query("SELECT * FROM fee_payments WHERE receiptNo = :receiptNo LIMIT 1")
    suspend fun getPaymentByReceiptNo(receiptNo: String): FeePayment?

    @Query("SELECT COALESCE(SUM(paidAmount), 0.0) FROM fee_payments")
    fun getTotalFeeCollection(): Flow<Double>

    @Query("SELECT COALESCE(SUM(dueAmount), 0.0) FROM fee_payments")
    fun getTotalFeeDue(): Flow<Double>

    @Query("SELECT * FROM fee_payments WHERE monthYear = :monthYear ORDER BY id DESC")
    fun getPaymentsByMonth(monthYear: String): Flow<List<FeePayment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: FeePayment): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(payments: List<FeePayment>)

    @Update
    suspend fun updatePayment(payment: FeePayment)

    @Delete
    suspend fun deletePayment(payment: FeePayment)

    @Query("DELETE FROM fee_payments WHERE id = :id")
    suspend fun deletePaymentById(id: Long)

    @Query("DELETE FROM fee_payments")
    suspend fun deleteAllPayments()
}
