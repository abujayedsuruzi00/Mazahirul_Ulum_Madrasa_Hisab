package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "teacher_staff")
data class TeacherStaff(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val employeeId: String, // e.g. "EMP-001"
    val phone: String = "",
    val address: String = "",
    val joiningDate: String = "",
    val designation: String = "হিফজ শিক্ষক", // মুহতামিম, নায়েবে মুহতামিম, শায়খুল হাদিস, হিফজ শিক্ষক, কিতাব শিক্ষক, নূরানী শিক্ষক, খাদেম, হিসাবরক্ষক, বাবুর্চি
    val salary: Double = 0.0,
    val status: String = "সক্রিয়", // "সক্রিয়", "নিষ্ক্রিয়"
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
