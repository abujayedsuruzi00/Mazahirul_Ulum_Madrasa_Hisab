package com.example.data.repository

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.local.dao.*
import com.example.data.local.entity.*
import com.example.util.BackupManager
import com.example.util.NumberFormatter
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.*

class MadrasaRepository(
    private val studentDao: StudentDao,
    private val feePaymentDao: FeePaymentDao,
    private val transactionDao: TransactionDao,
    private val loanDao: LoanDao,
    private val attendanceDao: AttendanceDao,
    private val profileDao: MadrasaProfileDao,
    private val teacherStaffDao: TeacherStaffDao,
    private val salaryPaymentDao: SalaryPaymentDao,
    private val database: AppDatabase,
    private val context: Context
) {
    // --- Students ---
    val allStudents: Flow<List<Student>> = studentDao.getAllStudents()
    val activeStudentCount: Flow<Int> = studentDao.getActiveStudentCount()
    val totalStudentCount: Flow<Int> = studentDao.getTotalStudentCount()

    fun getStudentById(id: Long): Flow<Student?> = studentDao.getStudentById(id)
    suspend fun getStudentByIdDirect(id: Long): Student? = studentDao.getStudentByIdDirect(id)

    fun searchStudents(query: String, className: String = "", department: String = "", status: String = ""): Flow<List<Student>> {
        return studentDao.searchStudents(query, className, department, status)
    }

    suspend fun insertStudent(student: Student): Long {
        return studentDao.insertStudent(student)
    }

    suspend fun updateStudent(student: Student) {
        studentDao.updateStudent(student)
    }

    suspend fun deleteStudent(student: Student) {
        studentDao.deleteStudent(student)
        attendanceDao.deleteForStudent(student.id)
    }

    // --- Teachers & Staff ---
    val allTeachers: Flow<List<TeacherStaff>> = teacherStaffDao.getAllTeachers()
    val activeTeacherCount: Flow<Int> = teacherStaffDao.getActiveTeacherCount()
    val totalTeacherCount: Flow<Int> = teacherStaffDao.getTotalTeacherCount()
    val totalMonthlySalaryBudget: Flow<Double?> = teacherStaffDao.getTotalMonthlyBudget()

    fun getTeacherById(id: Long): Flow<TeacherStaff?> = teacherStaffDao.getTeacherById(id)
    suspend fun getTeacherByIdDirect(id: Long): TeacherStaff? = teacherStaffDao.getTeacherByIdDirect(id)

    fun searchTeachers(query: String, designation: String = "", status: String = ""): Flow<List<TeacherStaff>> {
        return teacherStaffDao.searchTeachers(query, designation, status)
    }

    suspend fun insertTeacher(teacher: TeacherStaff): Long {
        return teacherStaffDao.insertTeacher(teacher)
    }

    suspend fun updateTeacher(teacher: TeacherStaff) {
        teacherStaffDao.updateTeacher(teacher)
    }

    suspend fun deleteTeacher(teacher: TeacherStaff) {
        teacherStaffDao.deleteTeacher(teacher)
        salaryPaymentDao.deleteForTeacher(teacher.id)
    }

    // --- Salary Payments ---
    val allSalaryPayments: Flow<List<SalaryPayment>> = salaryPaymentDao.getAllSalaryPayments()
    val totalSalaryPaid: Flow<Double> = salaryPaymentDao.getTotalSalaryPaid()
    val totalSalaryDue: Flow<Double> = salaryPaymentDao.getTotalSalaryDue()

    fun getSalaryPaymentsForTeacher(teacherId: Long): Flow<List<SalaryPayment>> =
        salaryPaymentDao.getPaymentsForTeacher(teacherId)

    fun getSalaryPaymentsForMonth(monthYear: String): Flow<List<SalaryPayment>> =
        salaryPaymentDao.getPaymentsForMonth(monthYear)

    suspend fun paySalary(
        teacher: TeacherStaff,
        monthYear: String,
        salaryAmount: Double,
        bonus: Double,
        deduction: Double,
        paidAmount: Double,
        paymentDate: String,
        paymentMethod: String,
        notes: String
    ): SalaryPayment {
        require(salaryAmount >= 0) { "বেতনের পরিমাণ ঋণাত্মক হতে পারে না" }
        require(paidAmount >= 0) { "পরিশোধের পরিমাণ ঋণাত্মক হতে পারে না" }
        val netPayable = (salaryAmount + bonus - deduction).coerceAtLeast(0.0)
        require(paidAmount <= netPayable) { "পরিশোধের পরিমাণ সর্বমোট প্রদেয় বেতনের চেয়ে বেশি হতে পারে না" }

        val dueAmount = (netPayable - paidAmount).coerceAtLeast(0.0)
        val voucherCode = "SAL-${System.currentTimeMillis() % 1000000}"
        val voucherNo = "MU-$voucherCode"

        // Check if payment already exists for this teacher & month
        val existing = salaryPaymentDao.getPaymentForTeacherAndMonth(teacher.id, monthYear)
        val paymentToSave = if (existing != null) {
            existing.copy(
                salaryAmount = salaryAmount,
                bonus = bonus,
                deduction = deduction,
                netPayable = netPayable,
                paidAmount = paidAmount,
                dueAmount = dueAmount,
                paymentDate = paymentDate,
                paymentMethod = paymentMethod,
                notes = notes
            )
        } else {
            SalaryPayment(
                voucherNo = voucherNo,
                teacherStaffId = teacher.id,
                teacherName = teacher.name,
                employeeId = teacher.employeeId,
                designation = teacher.designation,
                monthYear = monthYear,
                salaryAmount = salaryAmount,
                bonus = bonus,
                deduction = deduction,
                netPayable = netPayable,
                paidAmount = paidAmount,
                dueAmount = dueAmount,
                paymentDate = paymentDate,
                paymentMethod = paymentMethod,
                notes = notes
            )
        }

        val id = if (existing != null) {
            salaryPaymentDao.updatePayment(paymentToSave)
            existing.id
        } else {
            salaryPaymentDao.insertPayment(paymentToSave)
        }

        // Automated accounting integration: Record as EXPENSE under "শিক্ষক বেতন"
        if (paidAmount > 0) {
            transactionDao.insertTransaction(
                Transaction(
                    type = "EXPENSE",
                    title = "শিক্ষক/স্টাফ বেতন প্রদান (${teacher.name})",
                    category = "শিক্ষক বেতন",
                    amount = paidAmount,
                    date = paymentDate,
                    paymentMethod = paymentMethod,
                    voucherNo = paymentToSave.voucherNo,
                    payeeOrSource = teacher.name,
                    reference = "মাস: $monthYear, পদবী: ${teacher.designation}",
                    description = "বেতন: ${NumberFormatter.formatCurrency(salaryAmount)}, বোনাস: ${NumberFormatter.formatCurrency(bonus)}, কর্তন: ${NumberFormatter.formatCurrency(deduction)}"
                )
            )
        }

        return paymentToSave.copy(id = id)
    }

    suspend fun deleteSalaryPayment(payment: SalaryPayment) {
        salaryPaymentDao.deletePayment(payment)
    }

    // --- Fee Payments ---
    val allPayments: Flow<List<FeePayment>> = feePaymentDao.getAllPayments()
    val totalFeeCollection: Flow<Double> = feePaymentDao.getTotalFeeCollection()
    val totalFeeDue: Flow<Double> = feePaymentDao.getTotalFeeDue()

    fun getPaymentsForStudent(studentId: Long): Flow<List<FeePayment>> =
        feePaymentDao.getPaymentsForStudent(studentId)

    suspend fun collectFee(
        student: Student,
        monthYear: String,
        feeAmount: Double,
        paidAmount: Double,
        paymentMethod: String,
        notes: String
    ): FeePayment {
        require(feeAmount >= 0) { "ফি-এর পরিমাণ ঋণাত্মক হতে পারে না" }
        require(paidAmount >= 0) { "আদায়কৃত পরিমাণ ঋণাত্মক হতে পারে না" }
        require(paidAmount <= feeAmount) { "আদায়কৃত পরিমাণ নির্ধারিত ফি এর চেয়ে বেশি হতে পারে না" }

        val dueAmount = feeAmount - paidAmount
        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val receiptCode = "REC-${System.currentTimeMillis() % 1000000}"
        val receiptNo = "MU-$receiptCode"

        val payment = FeePayment(
            receiptNo = receiptNo,
            studentDbId = student.id,
            studentCustomId = student.studentId,
            studentName = student.name,
            className = student.className,
            monthYear = monthYear,
            feeAmount = feeAmount,
            paidAmount = paidAmount,
            dueAmount = dueAmount,
            paymentDate = todayStr,
            paymentMethod = paymentMethod,
            notes = notes
        )

        val insertedId = feePaymentDao.insertPayment(payment)

        // Also record this fee collection in Transaction table as INCOME
        if (paidAmount > 0) {
            transactionDao.insertTransaction(
                Transaction(
                    type = "INCOME",
                    title = "ছাত্র ফি আদায় (${student.name})",
                    category = "ছাত্র বেতন",
                    amount = paidAmount,
                    date = todayStr,
                    paymentMethod = paymentMethod,
                    voucherNo = receiptNo,
                    payeeOrSource = student.name,
                    reference = "মাস: $monthYear, আইডি: ${student.studentId}",
                    description = "শ্রেণি: ${student.className}, ধার্য: ${NumberFormatter.formatCurrency(feeAmount)}"
                )
            )
        }

        return payment.copy(id = insertedId)
    }

    suspend fun deleteFeePayment(payment: FeePayment) {
        feePaymentDao.deletePayment(payment)
    }

    // --- Transactions & Accounts ---
    val allTransactions: Flow<List<Transaction>> = transactionDao.getAllTransactions()
    val totalIncome: Flow<Double> = transactionDao.getTotalIncome()
    val totalExpense: Flow<Double> = transactionDao.getTotalExpense()

    fun getTodayIncome(date: String): Flow<Double> = transactionDao.getTodayIncome(date)
    fun getTodayExpense(date: String): Flow<Double> = transactionDao.getTodayExpense(date)
    fun getMonthlyIncome(monthPrefix: String): Flow<Double> = transactionDao.getMonthlyIncome(monthPrefix)
    fun getMonthlyExpense(monthPrefix: String): Flow<Double> = transactionDao.getMonthlyExpense(monthPrefix)

    fun searchTransactions(query: String = "", type: String = "", category: String = ""): Flow<List<Transaction>> =
        transactionDao.searchTransactions(query, type, category)

    suspend fun addTransaction(
        type: String, // "INCOME" or "EXPENSE"
        title: String,
        category: String,
        amount: Double,
        date: String,
        paymentMethod: String,
        voucherNo: String,
        description: String,
        payeeOrSource: String = "",
        reference: String = "",
        notes: String = ""
    ): Long {
        require(amount > 0) { "টাকার পরিমাণ ০ এর বেশি হতে হবে" }
        val transaction = Transaction(
            type = type,
            title = title,
            category = category,
            amount = amount,
            date = date,
            paymentMethod = paymentMethod,
            voucherNo = voucherNo,
            description = description,
            payeeOrSource = payeeOrSource,
            reference = reference,
            notes = notes
        )
        return transactionDao.insertTransaction(transaction)
    }

    suspend fun updateTransaction(transaction: Transaction) {
        require(transaction.amount > 0) { "টাকার পরিমাণ ০ এর বেশি হতে হবে" }
        transactionDao.updateTransaction(transaction)
    }

    suspend fun deleteTransaction(transaction: Transaction) {
        transactionDao.deleteTransaction(transaction)
    }

    // --- Loans ---
    val allLoans: Flow<List<Loan>> = loanDao.getAllLoans()
    val totalLoanPayable: Flow<Double> = loanDao.getTotalLoanPayable()
    val totalLoanReceivable: Flow<Double> = loanDao.getTotalLoanReceivable()

    fun getLoanById(id: Long): Flow<Loan?> = loanDao.getLoanById(id)
    fun getRepaymentsForLoan(loanId: Long): Flow<List<LoanRepayment>> = loanDao.getRepaymentsForLoan(loanId)

    suspend fun createLoan(
        loanType: String,
        personName: String,
        phone: String,
        totalAmount: Double,
        date: String,
        purpose: String,
        notes: String
    ): Long {
        require(totalAmount > 0) { "ঋণের পরিমাণ ০ এর চেয়ে বেশি হতে হবে" }
        val loan = Loan(
            loanType = loanType,
            personName = personName,
            phone = phone,
            totalAmount = totalAmount,
            paidAmount = 0.0,
            remainingAmount = totalAmount,
            date = date,
            purpose = purpose,
            status = "চলমান",
            notes = notes
        )
        val loanId = loanDao.insertLoan(loan)

        // Record loan impact on cash transactions
        if (loanType == "TAKEN") {
            // Madrasa borrowed money -> cash received (INCOME)
            transactionDao.insertTransaction(
                Transaction(
                    type = "INCOME",
                    title = "ঋণ গ্রহণ ($personName)",
                    category = "ঋণ/করজ",
                    amount = totalAmount,
                    date = date,
                    paymentMethod = "নগদ",
                    voucherNo = "LN-TK-$loanId",
                    payeeOrSource = personName,
                    reference = "ঋণ গ্রহণ",
                    description = "উদ্দেশ্য: $purpose"
                )
            )
        } else {
            // Madrasa lent money -> cash disbursed (EXPENSE)
            transactionDao.insertTransaction(
                Transaction(
                    type = "EXPENSE",
                    title = "ঋণ প্রদান ($personName)",
                    category = "ঋণ/করজ",
                    amount = totalAmount,
                    date = date,
                    paymentMethod = "নগদ",
                    voucherNo = "LN-GV-$loanId",
                    payeeOrSource = personName,
                    reference = "ঋণ প্রদান",
                    description = "উদ্দেশ্য: $purpose"
                )
            )
        }

        return loanId
    }

    suspend fun addLoanRepayment(
        loanId: Long,
        amount: Double,
        date: String,
        paymentMethod: String,
        notes: String
    ) {
        val loan = loanDao.getLoanByIdDirect(loanId) ?: return
        require(amount > 0) { "পরিশোধের পরিমাণ ০ এর চেয়ে বেশি হতে হবে" }
        require(amount <= loan.remainingAmount) { "পরিশোধের পরিমাণ অবশিষ্ট ঋণের চেয়ে বেশি হতে পারে না" }

        val newPaid = loan.paidAmount + amount
        val newRemaining = (loan.totalAmount - newPaid).coerceAtLeast(0.0)
        val newStatus = if (newRemaining <= 0.0) "পরিশোধিত" else "চলমান"

        loanDao.updateLoan(
            loan.copy(
                paidAmount = newPaid,
                remainingAmount = newRemaining,
                status = newStatus
            )
        )

        loanDao.insertRepayment(
            LoanRepayment(
                loanId = loanId,
                amount = amount,
                date = date,
                paymentMethod = paymentMethod,
                notes = notes
            )
        )

        // Record repayment transaction
        if (loan.loanType == "TAKEN") {
            // Madrasa paid back loan -> EXPENSE
            transactionDao.insertTransaction(
                Transaction(
                    type = "EXPENSE",
                    title = "ঋণ পরিশোধ (${loan.personName})",
                    category = "ঋণ/করজ",
                    amount = amount,
                    date = date,
                    paymentMethod = paymentMethod,
                    voucherNo = "RP-TK-$loanId",
                    payeeOrSource = loan.personName,
                    reference = "ঋণ পরিশোধের কিস্তি",
                    description = "কিস্তি পরিশোধ. নোট: $notes"
                )
            )
        } else {
            // Borrower repaid loan to Madrasa -> INCOME
            transactionDao.insertTransaction(
                Transaction(
                    type = "INCOME",
                    title = "প্রদত্ত ঋণ আদায় (${loan.personName})",
                    category = "ঋণ/করজ",
                    amount = amount,
                    date = date,
                    paymentMethod = paymentMethod,
                    voucherNo = "RP-GV-$loanId",
                    payeeOrSource = loan.personName,
                    reference = "প্রদত্ত ঋণ আদায়ের কিস্তি",
                    description = "কিস্তি আদায়. নোট: $notes"
                )
            )
        }
    }

    suspend fun deleteLoan(loan: Loan) {
        loanDao.deleteLoan(loan)
        loanDao.deleteRepaymentsForLoan(loan.id)
    }

    // --- Attendance ---
    fun getAttendanceForDate(date: String): Flow<List<AttendanceRecord>> =
        attendanceDao.getAttendanceForDate(date)

    fun getAttendanceForMonth(monthPrefix: String): Flow<List<AttendanceRecord>> =
        attendanceDao.getAttendanceForMonth(monthPrefix)

    fun getAttendanceForStudent(studentId: Long): Flow<List<AttendanceRecord>> =
        attendanceDao.getAttendanceForStudent(studentId)

    fun getPresentCountForDate(date: String): Flow<Int> =
        attendanceDao.getPresentCountForDate(date)

    suspend fun markAttendance(studentId: Long, date: String, status: String, remarks: String = "") {
        val existing = attendanceDao.getAttendanceForStudentAndDate(studentId, date)
        if (existing != null) {
            attendanceDao.insertOrUpdate(existing.copy(status = status, remarks = remarks))
        } else {
            attendanceDao.insertOrUpdate(
                AttendanceRecord(
                    studentDbId = studentId,
                    date = date,
                    status = status,
                    remarks = remarks
                )
            )
        }
    }

    suspend fun markAllStudentsPresent(students: List<Student>, date: String) {
        val records = students.map { s ->
            AttendanceRecord(
                studentDbId = s.id,
                date = date,
                status = "PRESENT",
                remarks = "স্বয়ংক্রিয় উপস্থিতি"
            )
        }
        attendanceDao.insertAll(records)
    }

    // --- Madrasa Profile & Settings ---
    val madrasaProfile: Flow<MadrasaProfile?> = profileDao.getProfile()
    suspend fun getProfileDirect(): MadrasaProfile? = profileDao.getProfileDirect()

    suspend fun updateProfile(profile: MadrasaProfile) {
        profileDao.updateProfile(profile)
    }

    suspend fun updateHijriOffset(offset: Int) {
        val current = profileDao.getProfileDirect() ?: MadrasaProfile()
        profileDao.updateProfile(current.copy(hijriOffsetDays = offset))
    }

    suspend fun updateLocation(district: String, lat: Double, lng: Double) {
        val current = profileDao.getProfileDirect() ?: MadrasaProfile()
        profileDao.updateProfile(current.copy(selectedDistrict = district, latitude = lat, longitude = lng))
    }

    suspend fun updateMadhhab(madhhab: String, method: String) {
        val current = profileDao.getProfileDirect() ?: MadrasaProfile()
        profileDao.updateProfile(current.copy(asrMadhhab = madhhab, calculationMethod = method))
    }

    suspend fun updateThemeMode(theme: String) {
        val current = profileDao.getProfileDirect() ?: MadrasaProfile()
        profileDao.updateProfile(current.copy(themeMode = theme))
    }

    suspend fun updateAppLanguage(lang: String) {
        val current = profileDao.getProfileDirect() ?: MadrasaProfile()
        profileDao.updateProfile(current.copy(appLanguage = lang))
    }

    suspend fun updateNotificationSettings(prayer: Boolean, fee: Boolean, salary: Boolean, backup: Boolean) {
        val current = profileDao.getProfileDirect() ?: MadrasaProfile()
        profileDao.updateProfile(
            current.copy(
                prayerNotificationEnabled = prayer,
                feeDueNotificationEnabled = fee,
                salaryNotificationEnabled = salary,
                backupReminderEnabled = backup
            )
        )
    }

    suspend fun updatePrayerAdjustments(fajr: Int, dhuhr: Int, asr: Int, maghrib: Int, isha: Int) {
        val current = profileDao.getProfileDirect() ?: MadrasaProfile()
        profileDao.updateProfile(
            current.copy(
                fajrAdjustment = fajr,
                dhuhrAdjustment = dhuhr,
                asrAdjustment = asr,
                maghribAdjustment = maghrib,
                ishaAdjustment = isha
            )
        )
    }

    // --- Backup & Restore ---
    private val backupManager = BackupManager(context, database)

    suspend fun exportBackupJson(): String {
        return backupManager.createBackupJson()
    }

    suspend fun exportAndShareBackup(): java.io.File {
        return backupManager.exportAndShareBackup(context)
    }

    suspend fun restoreBackupJson(jsonString: String): Pair<Boolean, String> {
        return backupManager.restoreDatabaseFromJson(jsonString)
    }
}
