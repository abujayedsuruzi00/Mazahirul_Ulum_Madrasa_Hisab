package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "madrasa_profile")
data class MadrasaProfile(
    @PrimaryKey
    val id: Int = 1,
    val nameBn: String = "মাযাহিরুল উলুম মাদ্রাসা",
    val nameEn: String = "Mazahirul Ulum Madrasa",
    val address: String = "মাদ্রাসার ঠিকানা, বাংলাদেশ",
    val phone: String = "০১XXXXXXXXX",
    val email: String = "info@mazahirululum.edu",
    val principalName: String = "মুহতামিম সাহেব",
    val establishedYear: String = "১৯৯৫",
    val slogan: String = "ইলম, আমল ও খুলুসিয়্যাতের আলোকবর্তিকা",
    val hijriOffsetDays: Int = 0, // Adjustment for local moon sighting (-2 to +2)
    val selectedDistrict: String = "ঢাকা",
    val latitude: Double = 23.8103,
    val longitude: Double = 90.4125,
    val calculationMethod: String = "Karachi", // Karachi / MWL
    val asrMadhhab: String = "Hanafi", // Hanafi / Shafii
    val themeMode: String = "SYSTEM", // SYSTEM, LIGHT, DARK
    val appLanguage: String = "BN", // BN, EN
    val prayerNotificationEnabled: Boolean = true,
    val feeDueNotificationEnabled: Boolean = true,
    val salaryNotificationEnabled: Boolean = true,
    val backupReminderEnabled: Boolean = true,
    val fajrAdjustment: Int = 0,
    val dhuhrAdjustment: Int = 0,
    val asrAdjustment: Int = 0,
    val maghribAdjustment: Int = 0,
    val ishaAdjustment: Int = 0
)
