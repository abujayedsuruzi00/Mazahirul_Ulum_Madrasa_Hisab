package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.repository.MadrasaRepository
import com.example.util.NotificationHelper

class MadrasaApplication : Application() {
    val database by lazy { AppDatabase.getInstance(this) }
    val repository by lazy {
        MadrasaRepository(
            studentDao = database.studentDao(),
            feePaymentDao = database.feePaymentDao(),
            transactionDao = database.transactionDao(),
            loanDao = database.loanDao(),
            attendanceDao = database.attendanceDao(),
            profileDao = database.madrasaProfileDao(),
            teacherStaffDao = database.teacherStaffDao(),
            salaryPaymentDao = database.salaryPaymentDao(),
            database = database,
            context = this
        )
    }

    override fun onCreate() {
        super.onCreate()
        NotificationHelper.createNotificationChannels(this)
    }
}
